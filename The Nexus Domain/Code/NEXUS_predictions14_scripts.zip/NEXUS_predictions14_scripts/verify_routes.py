"""Independent check of the closed-route and reader-seam claims.
Method differs from the notebook: every dimension is E minus the F2 rank of a stacked constraint system
(no spanning trees, no explicit bases)."""
from math import ceil
from itertools import product

def J(x, L): return int(format(x, f'0{L}b')[::-1], 2)
def C(x, L): return x ^ ((1 << L) - 1)
def pal(x, L): return J(x, L) == x
def P(x, L):
    j = J(x, L)
    return j if j != x else C(x, L)

def rank(rows):
    piv, r = {}, 0
    for x in rows:
        while x:
            h = x.bit_length() - 1
            if h in piv: x ^= piv[h]
            else: piv[h] = x; r += 1; break
    return r

print('1  Closed routes of the wheel B(n) under reversal J and under facing P (contact by contact)')
print('   n  dimZ  dimZ^J  t_J  r_J | formulas        | dimZ^P  t_P  r_P | formulas')
for n in range(1, 11):
    V, E = 1 << n, 1 << (n + 1)
    p, q = 2 ** ceil(n / 2), 2 ** ceil((n + 1) / 2)
    ev = 1 if n % 2 == 0 else 0
    IN = lambda e: e >> 1
    OUT = lambda e: e & (V - 1)
    def bd_rows(img):                      # rows of the boundary of the chain image under edge map img
        rows = [0] * V
        for e in range(E):
            f = img(e)
            rows[IN(f)] ^= 1 << e; rows[OUT(f)] ^= 1 << e
        return rows
    D = bd_rows(lambda e: e)
    DP = bd_rows(lambda e: P(e, n + 1))
    IJ = [(1 << e) | (1 << J(e, n + 1)) for e in range(E) if J(e, n + 1) != e]
    IP = [(1 << e) | (1 << P(e, n + 1)) for e in range(E)]
    dZ = E - rank(D)
    dZJ = E - rank(D + IJ)
    rJ = dZ - dZJ; tJ = dZJ - rJ
    dZP = E - rank(D + DP)
    dZPP = E - rank(D + DP + IP)
    rP = dZP - dZPP; tP = dZPP - rP
    fJ = (V + 1, (V + p + q) // 2, p + q - 1, (V + 2 - p - q) // 2)
    fP = (V - q // 2 + 2 + ev, p + q // 2 - 2 - ev, (V + 2 - p - q) // 2 + 1 + ev)
    assert (dZ, dZJ, tJ, rJ) == fJ and (dZP, tP, rP) == fP, (n, dZ, dZJ, tJ, rJ, dZP, tP, rP)
    print(f'  {n:2d} {dZ:5d} {dZJ:6d} {tJ:4d} {rJ:4d} | match           | {dZP:6d} {tP:4d} {rP:4d} | match')

print('\n2  Facing defect of palindrome contacts: complement pairs, zero-defect pairs, disjoint 4-face supports')
for n in range(1, 15):
    V, E = 1 << n, 1 << (n + 1)
    pairs = {(min(e, C(e, n + 1)), max(e, C(e, n + 1))) for e in range(E) if pal(e, n + 1)}
    zero, supports = 0, []
    for e, _ in pairs:
        u = e >> 1
        orb = {u, J(u, n), C(u, n), C(J(u, n), n)}
        if len(orb) < 4:                    # the defect u + Ju + Cu + CJu vanishes exactly when the orbit collapses
            zero += 1
        else:
            supports.append(orb)
    allv = set().union(*supports) if supports else set()
    assert zero == (2 if n % 2 == 0 else 1) and len(allv) == 4 * len(supports)
print('   n = 1-14: zero-defect pairs 1 (odd n) or 2 (even n); every other pair has its own 4 faces, disjoint from all others')

print('\n3  Circular routes (necklaces) of length L: reversal symmetry, seams, cyclic facing')
print('   L  necklaces  achiral  (p+q)/2  palindrome seam  hinge only  cyclic facing well defined  fixed by cyclic facing')
for L in range(1, 15):
    canon = lambda w: min(w[k:] + w[:k] for k in range(L))
    classes = {}
    for w in product((0, 1), repeat=L):
        classes.setdefault(canon(w), []).append(w)
    p, q = 2 ** ceil(L / 2), 2 ** ceil((L + 1) / 2)
    ach = seam = hinge = fixed = 0
    well = True
    for c, mem in classes.items():
        achiral = canon(c[::-1]) == c
        palrot = {w for w in mem if w[::-1] == w}
        if achiral:
            ach += 1
            if palrot: seam += 1
            else: hinge += 1
            if L % 2: assert len(palrot) == 1                 # odd L: exactly one palindromic rotation
        else:
            assert not palrot
        img = {canon(tuple(1 - b for b in w) if canon(w[::-1]) == canon(w) else w[::-1]) for w in mem}
        well &= len(img) == 1
        fixed += img == {c}
    assert ach == (p + q) // 2 and well
    if L % 2: assert hinge == 0
    print(f'  {L:2d} {len(classes):9d} {ach:8d} {(p + q) // 2:8d} {seam:16d} {hinge:11d} {str(well):>27} {fixed:22d}')
print('ALL CLAIMS CHECKED')
