"""Affine interfaces at LEN 2, 3, 4: conjugacy classes of AGL(L,2) by brute-force union-find under
conjugation by generators (all elementary transvections and one translation), then motion signatures."""
from collections import Counter, defaultdict
import sys

def gl_tables(L):
    N = 1 << L
    out = []
    def rec(cols, span):
        if len(cols) == L:
            tab = [0] * N
            for x in range(N):
                v, i, y = 0, 0, x
                while y:
                    if y & 1: v ^= cols[i]
                    y >>= 1; i += 1
                tab[x] = v
            out.append(tuple(tab)); return
        for c in range(1, N):
            if c not in span:
                rec(cols + [c], span | {s ^ c for s in span})
    rec([], {0})
    return out

def cycle_type(perm):
    seen, out = [False] * len(perm), []
    for i in range(len(perm)):
        if not seen[i]:
            c, j = 0, i
            while not seen[j]: seen[j] = True; j = perm[j]; c += 1
            out.append(c)
    return tuple(sorted(out, reverse=True))

def run(L):
    N = 1 << L
    mats = gl_tables(L); M = len(mats)
    mid = {t: i for i, t in enumerate(mats)}
    inv = [None] * M
    for i, t in enumerate(mats):
        iv = [0] * N
        for x in range(N): iv[t[x]] = x
        inv[i] = mid[tuple(iv)]
    gens = []                                            # elementary transvections: column j gains e_i
    for i in range(L):
        for j in range(L):
            if i != j:
                cols = [1 << k for k in range(L)]; cols[j] ^= 1 << i
                tab = [0] * N
                for x in range(N):
                    v = 0
                    for k in range(L):
                        if (x >> k) & 1: v ^= cols[k]
                    tab[x] = v
                gens.append(mid[tuple(tab)])
    conj = []                                            # index of H A H^-1 for each generator H
    for h in gens:
        H, Hi = mats[h], mats[inv[h]]
        conj.append([mid[tuple(H[A[Hi[x]]] for x in range(N))] for A in mats])
    parent = list(range(M * N))
    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    def union(a, b):
        a, b = find(a), find(b)
        if a != b: parent[a] = b
    for m in range(M):
        A = mats[m]
        for b in range(N):
            g = m * N + b
            for k, h in enumerate(gens):                 # conjugate by H: (H A H^-1, H b)
                union(g, conj[k][m] * N + mats[h][b])
            union(g, m * N + (A[1] ^ b ^ 1))             # conjugate by translation e0: (A, A e0 + b + e0)
    cls = defaultdict(list)
    for g in range(M * N): cls[find(g)].append(g)
    rows = []
    for root, members in cls.items():
        m, b = divmod(members[0], N)
        A = mats[m]
        g = tuple(A[x] ^ b for x in range(N))
        mi = inv[m]; bi = mats[mi][b]                     # g^-1 = (A^-1, A^-1 b)
        inv_root = find(mi * N + bi)
        order, h = 1, g
        while h != tuple(range(N)):
            h = tuple(g[h[x]] for x in range(N)); order += 1
        rows.append(dict(root=root, size=len(members), vc=cycle_type(g), dc=cycle_type(A),
                         order=order, fixed=sum(g[x] == x for x in range(N)), twin=inv_root != root, inv=inv_root))
    return M, rows

for L in (2, 3, 4):
    M, rows = run(L)
    rows.sort(key=lambda r: (r['order'], -r['fixed'], r['vc'], r['dc']))
    twins = [r for r in rows if r['twin']]
    sig = Counter((r['vc'], r['dc']) for r in rows)
    vsig = Counter(r['vc'] for r in rows)
    print(f'\nLEN {L}: {M * (1 << L):,} maps, {len(rows)} interfaces; self-inverse {len(rows) - len(twins)}, '
          f'mirror twins {len(twins)} ({len(twins) // 2} pairs); distinct (g, Dg) signatures {len(sig)}; '
          f'distinct vertex cycle types {len(vsig)}')
    bad = [s for s, c in sig.items() if c > 1 and not all(r['twin'] for r in rows if (r['vc'], r['dc']) == s)]
    print('  signature collisions between non-twins:', bad if bad else 'none')
    if L == 4:
        for i, r in enumerate(rows):
            vc = ','.join(map(str, r['vc'])); dc = ','.join(map(str, r['dc']))
            print(f'  #{i:2d} maps {r["size"]:6d} order {r["order"]:2d} fixed {r["fixed"]:2d}  g: {vc:<34s} Dg: {dc:<26s} {"mirror twin" if r["twin"] else ""}')
