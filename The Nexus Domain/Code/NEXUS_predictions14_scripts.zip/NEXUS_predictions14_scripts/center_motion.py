"""Where does the center's difference go under ring motions? Registers Psi+- at odd LEN n:
equal superposition of palindromes with sign (+-1)^(center bit). Motions act as permutations of words."""
import sys
import numpy as np
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ringops import J, C, P, pal, native_ring

def register(n, sign):
    k = n // 2; v = np.zeros(1 << n)
    for x in range(1 << n):
        if pal(x, n):
            v[x] = -1.0 if (sign < 0 and (x >> (n - 1 - k)) & 1) else 1.0
    return v / np.linalg.norm(v)
def act(v, perm):
    w = np.zeros_like(v); w[np.asarray(perm)] = v; return w
def reduced(v, n, sites):                     # sites = positions from the left
    t = v.reshape([2] * n)
    rest = [i for i in range(n) if i not in sites]
    t = np.transpose(t, sites + rest).reshape(2 ** len(sites), -1)
    return t @ t.T
def tdist(a, b):
    return 0.5 * np.abs(np.linalg.eigvalsh(a - b)).sum()
def motions(n):
    N = 1 << n; R = native_ring(n); loc = {x: a for a, x in enumerate(R)}
    return {'J (reversal)': [J(x, n) for x in range(N)], 'C (NOT)': [C(x, n) for x in range(N)],
            'P (facing)': [P(x, n) for x in range(N)],
            'tau (twisted clock)': [((x << 1) & (N - 1)) | (1 - (x >> (n - 1))) for x in range(N)],
            'T (native successor)': [R[(loc[x] + 1) % N] for x in range(N)]}

print('P14.7  P T P = T^-1 on native rings:')
for n in range(2, 13):
    N = 1 << n; R = native_ring(n); loc = {x: a for a, x in enumerate(R)}
    T = [R[(loc[x] + 1) % N] for x in range(N)]; Ti = [R[(loc[x] - 1) % N] for x in range(N)]
    assert all(P(T[P(x, n)], n) == Ti[x] for x in range(N))
print('  holds for n = 2-12')

for n in (3, 5, 7, 9, 11):
    k = n // 2
    vp, vm = register(n, +1), register(n, -1)
    print(f'\nn = {n} (center site {k})')
    for name, perm in motions(n).items():
        a, b = act(vp, perm), act(vm, perm)
        single = [tdist(reduced(a, n, [i]), reduced(b, n, [i])) for i in range(n)]
        sites = [i for i, d in enumerate(single) if d > 1e-9]
        eig = ''
        if name.startswith(('P', 'C', 'J')):
            eig = f'  Psi+ -> {"+" if np.allclose(a, vp) else "?"}Psi+, Psi- -> {"+" if np.allclose(b, vm) else ("-" if np.allclose(b, -vm) else "?")}Psi-'
        pair = ''
        if name.startswith('T') and n <= 9:
            dmax = max(tdist(reduced(a, n, [i, j]), reduced(b, n, [i, j])) for i in range(n) for j in range(i + 1, n))
            pair = f'  max two-site distance {dmax:.3f}'
        print(f'  {name:22s} sites that distinguish: {sites}  max single-site distance {max(single):.3f}  overlap {abs(a @ b):.1e}{eig}{pair}')
    tau = motions(n)['tau (twisted clock)']
    a, b = vp.copy(), vm.copy(); path = []
    for t in range(1, n + 1):
        a, b = act(a, tau), act(b, tau)
        single = [tdist(reduced(a, n, [i]), reduced(b, n, [i])) for i in range(n)]
        path.append([i for i, d in enumerate(single) if d > 1e-9])
    print(f'  tau^t, t = 1..{n}: distinguishing site {path};  predicted {[[(k - t) % n] for t in range(1, n + 1)]}')
