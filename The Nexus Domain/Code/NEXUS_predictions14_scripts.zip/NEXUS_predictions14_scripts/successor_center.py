"""Which center pairs does the native successor disturb? A pair (w, w+e_k) of palindromes keeps the center's
difference on site k when T(w) and T(w+e_k) still differ only at site k."""
import sys
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ringops import pal, native_ring, b
for n in (3, 5, 7, 9, 11, 13):
    k = n // 2; N = 1 << n; ek = 1 << (n - 1 - k)
    R = native_ring(n); loc = {x: a for a, x in enumerate(R)}
    T = lambda x: R[(loc[x] + 1) % N]
    pairs = [w for w in range(N) if pal(w, n) and not w & ek]
    moved = {}
    for w in pairs:
        d = T(w) ^ T(w | ek)
        moved.setdefault(d, []).append(w)
    keep = len(moved.get(ek, []))
    others = {b(d, n): [b(w, n) for w in ws] for d, ws in moved.items() if d != ek}
    print(f'n={n:2d}: {len(pairs)} center pairs; kept on the center: {keep} (share {keep/len(pairs):.4f} = 1 - 2^-{k}: {1 - 2**-k:.4f}); '
          f'disturbed: {others}')
