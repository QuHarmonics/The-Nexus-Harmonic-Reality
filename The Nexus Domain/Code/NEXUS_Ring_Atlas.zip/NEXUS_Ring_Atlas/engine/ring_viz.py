"""NEXUS Ring Atlas - visual layer (Plotly, dark).  Reads ring_core; never changes it.

Dean A. Kulik, QuHarmonics Research Group, ORCID 0009-0003-3128-8828.
Every figure names what it shows: an exact ring-order diagram, a geometric reading, or a projection.
"""
from __future__ import annotations

import base64
import html as _html
import io
import math
from fractions import Fraction

import numpy as np
import plotly.graph_objects as go
import plotly.io as pio
from plotly.subplots import make_subplots

import ring_core as rc

try:
    from PIL import Image
except Exception:  # pragma: no cover
    Image = None

# ----------------------------------------------------------------------------------------
# Tokens (dark).  Categorical slots: the validated dark set; status colours are reserved.
# ----------------------------------------------------------------------------------------
SURFACE = "#0e1117"
PANEL = "#151b26"
PANEL2 = "#1a2130"
BORDER = "#263042"
GRID = "#1d2533"
INK = "#f0efec"
INK2 = "#c3c2b7"
MUTED = "#8b93a3"
MONO = "JetBrains Mono, Cascadia Code, Consolas, Menlo, monospace"
SANS = "Inter, Segoe UI, system-ui, -apple-system, sans-serif"

BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET, RED = (
    "#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#008300", "#9085e9", "#e66767")
REP, PARTNER, PAL, SEAM, READER = BLUE, ORANGE, VIOLET, YELLOW, AQUA
LIGHT_BIT, GAP_BIT, GREY_BIT = "#ecdfb8", "#1a2232", "#6b7180"
BLUE_RAMP = ["#0d366b", "#104281", "#184f95", "#1c5cab", "#256abf", "#2a78d6", "#3987e5",
             "#5598e7", "#6da7ec", "#86b6ef", "#9ec5f4", "#b7d3f6", "#cde2fb"]
STATUS = {"STANDS": "#0ca30c", "RUNS": "#3987e5", "OPEN": "#fab219", "PULL": "#9085e9",
          "ELSEWHERE": "#ec835a", "FAIL": "#d03b3b", "PASS": "#0ca30c", "SKIP": "#8b93a3"}
ICON = {"STANDS": "✔", "RUNS": "▶", "OPEN": "◌", "PULL": "↗",
        "ELSEWHERE": "↪", "FAIL": "✖", "PASS": "✔", "SKIP": "–"}

CONFIG = dict(displaylogo=False, responsive=True,
              toImageButtonOptions=dict(format="png", scale=2, filename="nexus_ring_atlas"),
              modeBarButtonsToRemove=["select2d", "lasso2d", "autoScale2d"])


def install_theme():
    t = go.layout.Template()
    t.layout = go.Layout(
        paper_bgcolor=SURFACE, plot_bgcolor=SURFACE,
        font=dict(family=SANS, color=INK2, size=13),
        title=dict(font=dict(color=INK, size=17, family=SANS), x=0.012, xanchor="left", y=0.96),
        colorway=[BLUE, ORANGE, AQUA, YELLOW, MAGENTA, GREEN, VIOLET, RED],
        xaxis=dict(gridcolor=GRID, zerolinecolor=GRID, linecolor=BORDER, tickcolor=BORDER,
                   ticks="outside", title=dict(font=dict(color=MUTED, size=12))),
        yaxis=dict(gridcolor=GRID, zerolinecolor=GRID, linecolor=BORDER, tickcolor=BORDER,
                   ticks="outside", title=dict(font=dict(color=MUTED, size=12))),
        legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(color=INK2, size=12), orientation="h",
                    yanchor="bottom", y=1.01, xanchor="right", x=1),
        hoverlabel=dict(bgcolor=PANEL2, bordercolor=BORDER, font=dict(color=INK, family=MONO, size=12)),
        margin=dict(l=60, r=30, t=78, b=52),
        polar=dict(bgcolor=SURFACE),
        scene=dict(bgcolor=SURFACE),
        coloraxis=dict(colorbar=dict(outlinewidth=0, tickfont=dict(color=MUTED))),
    )
    pio.templates["nexus_dark"] = t
    pio.templates.default = "nexus_dark"


install_theme()


def show(fig, height=None):
    if height:
        fig.update_layout(height=height)
    fig.show(config=CONFIG)


def _subtitle(fig, text):
    """Second title line in muted ink (kept inside the title so it never collides with subplot titles)."""
    t = fig.layout.title.text or ""
    fig.update_layout(title=dict(text="%s<br><span style='font-size:12.5px;color:%s'>%s</span>" % (t, MUTED, text),
                                 y=1.0, yanchor="top", yref="container", pad=dict(t=30, l=4)))
    m = fig.layout.margin
    if m.t is None or m.t < 112:
        fig.update_layout(margin=dict(t=112))


def _blank_axes(fig, row=None, col=None, square=True, lim=1.06):
    kw = {} if row is None else dict(row=row, col=col)
    fig.update_xaxes(visible=False, range=[-lim, lim], **kw)
    fig.update_yaxes(visible=False, range=[-lim, lim], **kw)
    if square:
        if row is None:
            fig.update_yaxes(scaleanchor="x", scaleratio=1)


# ----------------------------------------------------------------------------------------
# HTML panels (inline styles, so they survive notebook sanitizers)
# ----------------------------------------------------------------------------------------

def esc(s):
    return _html.escape(str(s))


def chip(status, text=None):
    c = STATUS.get(status, MUTED)
    label = text or status
    return ('<span style="display:inline-block;padding:2px 9px;margin:1px 2px;border-radius:999px;'
            'border:1px solid %s;color:%s;font:600 11px/1.6 %s;letter-spacing:.04em;white-space:nowrap">'
            '%s %s</span>' % (c, INK, SANS, ICON.get(status, ""), esc(label)))


def card(title, body, kicker=None, status=None, accent=None):
    acc = accent or (STATUS.get(status) if status else BLUE)
    kick = ('<div style="color:%s;font:600 11px %s;letter-spacing:.12em;text-transform:uppercase;'
            'margin-bottom:4px">%s</div>' % (MUTED, SANS, esc(kicker))) if kicker else ""
    st = (" " + chip(status)) if status else ""
    return ('<div style="background:%s;border:1px solid %s;border-left:3px solid %s;border-radius:10px;'
            'padding:14px 18px;margin:8px 0;color:%s;font:14px/1.55 %s">%s'
            '<div style="color:%s;font:600 16px %s;margin-bottom:6px">%s%s</div>%s</div>'
            % (PANEL, BORDER, acc, INK2, SANS, kick, INK, SANS, esc(title), st, body))


WIDE_HEADERS = {"statement": 260, "feature": 240, "route in the domain": 280, "shape of the missing piece": 320,
                "earlier sighting": 200, "meaning": 320, "domain element": 300, "word under the reader": 160,
                "scope": 170, "expected": 170, "actual": 190, "source": 170, "physical reading": 140}


def table(headers, rows, mono_cols=(), align=None, max_height=None, status_col=None):
    def thw(h):
        w = WIDE_HEADERS.get(str(h))
        return ("min-width:%dpx;" % w) if w else ""
    th = "".join('<th style="text-align:left;padding:6px 10px;color:%s;font:600 12px %s;%s'
                 'border-bottom:1px solid %s;position:sticky;top:0;background:%s">%s</th>'
                 % (MUTED, SANS, thw(h), BORDER, PANEL, esc(h)) for h in headers)
    trs = []
    for i, r in enumerate(rows):
        tds = []
        for j, v in enumerate(r):
            fam = MONO if j in mono_cols else SANS
            if status_col is not None and j == status_col:
                cell = chip(str(v))
            else:
                cell = v if (isinstance(v, str) and v.startswith("<")) else esc(v)
            tds.append('<td style="text-align:left;padding:5px 10px;border-bottom:1px solid %s;font:13px/1.45 %s;color:%s;'
                       'vertical-align:top;white-space:normal">%s</td>' % (GRID, fam, INK2, cell))
        bg = PANEL if i % 2 == 0 else PANEL2
        trs.append('<tr style="background:%s">%s</tr>' % (bg, "".join(tds)))
    mh = ("max-height:%dpx;overflow:auto;" % max_height) if max_height else "overflow:auto;"
    return ('<div style="%sborder:1px solid %s;border-radius:8px;margin:6px 0">'
            '<table style="border-collapse:collapse;width:100%%;table-layout:auto;margin:0">%s%s</table></div>'
            % (mh, BORDER, "<tr>%s</tr>" % th, "".join(trs)))


def kv(pairs, cols=2):
    cells = []
    for k, v in pairs:
        cells.append('<div style="padding:6px 10px;background:%s;border:1px solid %s;border-radius:8px">'
                     '<div style="color:%s;font:600 11px %s;letter-spacing:.06em;text-transform:uppercase">%s</div>'
                     '<div style="color:%s;font:14px %s;margin-top:2px;word-break:break-all">%s</div></div>'
                     % (PANEL2, BORDER, MUTED, SANS, esc(k), INK, MONO, v if str(v).startswith("<") else esc(v)))
    return ('<div style="display:grid;grid-template-columns:repeat(%d,minmax(0,1fr));gap:8px;margin:6px 0">%s</div>'
            % (cols, "".join(cells)))


def bitspan(s, hi=None, color_one=LIGHT_BIT, color_zero=MUTED):
    """MSB-first bit string with 1s lit; hi = set of string indices to box."""
    hi = hi or set()
    out = []
    for i, ch in enumerate(s):
        col = color_one if ch == "1" else color_zero
        box = ("border:1px solid %s;border-radius:3px;background:rgba(25,158,112,.25);" % READER) if i in hi else ""
        out.append('<span style="color:%s;%spadding:0 1px">%s</span>' % (col, box, ch))
    return '<span style="font:600 14px %s;letter-spacing:.06em">%s</span>' % (MONO, "".join(out))


def hero(title, subtitle, author_line, claim):
    return (
        '<div style="background:radial-gradient(1200px 400px at 15%% 0%%, #1b2a44 0%%, %s 60%%);'
        'border:1px solid %s;border-radius:14px;padding:30px 34px;margin:4px 0 10px 0;color:%s;font:15px/1.6 %s">'
        '<div style="color:%s;font:600 12px %s;letter-spacing:.2em;text-transform:uppercase">NEXUS · QuHarmonics Research Group</div>'
        '<div style="color:%s;font:700 34px/1.15 %s;margin:8px 0 6px 0">%s</div>'
        '<div style="color:%s;font:17px/1.5 %s;max-width:980px">%s</div>'
        '<div style="color:%s;font:13px %s;margin-top:14px">%s</div>'
        '<div style="margin-top:18px;padding:12px 16px;border-left:3px solid %s;background:rgba(57,135,229,.08);'
        'color:%s;font:italic 15px/1.6 %s;max-width:980px">%s</div></div>'
        % (SURFACE, BORDER, INK2, SANS, MUTED, SANS, INK, SANS, esc(title), INK2, SANS, esc(subtitle),
           MUTED, SANS, esc(author_line), YELLOW, INK, SANS, esc(claim)))


def ledger_legend():
    rows = [(chip(s), esc(rc.LEDGER_MEANING[s])) for s in rc.LEDGER]
    return table(["status", "meaning"], rows)


# ----------------------------------------------------------------------------------------
# The nested ring disk (published Figure 1 geometry: radial thickness = word length,
# angle clockwise from the top; ring L = 2^L slots of L slices, MSB first)
# ----------------------------------------------------------------------------------------

def ring_radii(D, thickness="word"):
    if thickness == "word":
        edges = np.cumsum([0] + list(range(1, D + 1))).astype(float)
    else:
        edges = np.arange(D + 1, dtype=float)
    return edges / edges[-1]


def _polar_xy(r, u):
    a = 2 * np.pi * np.asarray(u, dtype=float)
    return np.asarray(r) * np.sin(a), np.asarray(r) * np.cos(a)


def disk_png(D, mode="bits", thickness="word", px=900, ss=2):
    """Raster of rings 1..D.  mode: 'bits' (light 1 / gap 0) or 'merge' (grey where a word and its
    facing partner disagree, slice by slice).  Returns a data URI."""
    S = px * ss
    edges = ring_radii(D, thickness)
    yy, xx = np.mgrid[0:S, 0:S].astype(np.float32)
    c = (S - 1) / 2.0
    X = (xx - c) / c
    Y = (c - yy) / c
    r = np.sqrt(X * X + Y * Y)
    u = (np.arctan2(X, Y) / (2 * np.pi)) % 1.0
    img = np.zeros((S, S, 3), dtype=np.uint8)
    img[:] = np.array([int(SURFACE[i:i + 2], 16) for i in (1, 3, 5)], dtype=np.uint8)
    col_l = np.array([int(LIGHT_BIT[i:i + 2], 16) for i in (1, 3, 5)], dtype=np.uint8)
    col_g = np.array([int(GAP_BIT[i:i + 2], 16) for i in (1, 3, 5)], dtype=np.uint8)
    col_m = np.array([int(GREY_BIT[i:i + 2], 16) for i in (1, 3, 5)], dtype=np.uint8)
    sep = 1.4 / c                                       # thin surface gap between rings
    for L in range(1, D + 1):
        r0, r1 = edges[L - 1], edges[L]
        m = (r >= r0 + (sep if L > 1 else 0)) & (r < r1 - sep)
        if not m.any():
            continue
        N = 1 << L
        sl = np.minimum((u[m] * (L * N)).astype(np.int64), L * N - 1)
        tb = rc.tape_bits(L)
        b = tb[sl]
        out = np.where(b[:, None] == 1, col_l, col_g)
        if mode == "merge":
            slot = sl // L
            j = sl % L
            mate = (N - 1 - slot) * L + j
            dis = tb[mate] != b
            out[dis] = col_m
        img[m] = out
    if Image is None:
        raise RuntimeError("Pillow is required for the ring disk")
    im = Image.fromarray(img)
    if ss > 1:
        im = im.resize((px, px), Image.BOX)
    im = im.quantize(colors=24, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    buf = io.BytesIO()
    im.save(buf, format="PNG", optimize=True)
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def _cell_polygon(r0, r1, u0, u1, k=10):
    us = np.linspace(u0, u1, k)
    xa, ya = _polar_xy(np.full(k, r1), us)
    xb, yb = _polar_xy(np.full(k, r0), us[::-1])
    return np.concatenate([xa, xb, xa[:1]]), np.concatenate([ya, yb, ya[:1]])


def fig_disk(D=8, mode="bits", thickness="word", reader=None, px=900, hover=True, title=None, height=760):
    edges = ring_radii(D, thickness)
    fig = go.Figure()
    fig.add_layout_image(dict(source=disk_png(D, mode, thickness, px), xref="x", yref="y", x=-1, y=1,
                              sizex=2, sizey=2, sizing="stretch", layer="below"))
    if hover and D <= 10:
        xs, ys, tx = [], [], []
        for L in range(1, D + 1):
            N = 1 << L
            rm = (edges[L - 1] + edges[L]) / 2
            R = rc.ring(L)
            pal = rc.pal_table(L)
            for a in range(N):
                x, y = _polar_xy(rm, (a + 0.5) / N)
                w = int(R[a])
                xs.append(float(x))
                ys.append(float(y))
                tx.append("ring %d · slot %d<br>word <b>%s</b><br>partner %s (slot %d)<br>%s%s"
                          % (L, a, rc.bits(w, L), rc.bits(rc.partner(w, L), L), N - 1 - a,
                             "representative face" if a < N // 2 else "partner face",
                             " · palindrome" if pal[w] else ""))
        fig.add_trace(go.Scatter(x=xs, y=ys, mode="markers", marker=dict(size=7, color="rgba(0,0,0,0)"),
                                 hovertemplate="%{text}<extra></extra>", text=tx, showlegend=False))
    # seam marker: the half-turn at angle 1/2 and the start at angle 0
    for uu, lab in ((0.0, "start / end"), (0.5, "seam")):
        x, y = _polar_xy(np.array([0, 1.03]), np.array([uu, uu]))
        fig.add_trace(go.Scatter(x=x, y=y, mode="lines", line=dict(color=SEAM, width=1.2, dash="dot"),
                                 hoverinfo="skip", showlegend=False))
        tx_, ty_ = _polar_xy(1.055, uu)
        fig.add_annotation(x=float(tx_), y=float(ty_), text=lab, showarrow=False,
                           font=dict(color=SEAM, size=11))
    if reader:
        _overlay_reader(fig, reader, edges)
    fig.update_layout(height=height, margin=dict(l=10, r=10, t=86, b=10), showlegend=bool(reader),
                      title=title or ("The nested partner ring, rings 1-%d" % D))
    _subtitle(fig, ("exact ring order · radial thickness = word length · angle clockwise from the top · "
                    + ("light = 1, gap = 0" if mode == "bits" else "merged with the facing partner: grey where they disagree")))
    _blank_axes(fig, lim=1.12)
    return fig


def _overlay_reader(fig, rd, edges):
    kind = rd.get("kind")
    if kind == "radial":
        u = float(rd["u"])
        x, y = _polar_xy(np.array([0, 1.04]), np.array([u, u]))
        fig.add_trace(go.Scatter(x=x, y=y, mode="lines", line=dict(color=INK, width=1.3),
                                 name="radial reader at u = %s" % rd["u"], hoverinfo="skip"))
        cx, cy, tx = [], [], []
        for r in rd["reads"]:
            L = r["ring"]
            N = 1 << L
            for k in range(len(r["read"])):
                g = (r["slot"] * L + r["bit"] + k) % (N * L)
                u0, u1 = g / (N * L), (g + 1) / (N * L)
                px_, py_ = _cell_polygon(edges[L - 1], edges[L], u0, u1)
                fig.add_trace(go.Scatter(x=px_, y=py_, mode="lines", fill="toself", fillcolor="rgba(25,158,112,0.35)",
                                         line=dict(color=READER, width=2), hoverinfo="skip", showlegend=False))
                mx, my = _polar_xy((edges[L - 1] + edges[L]) / 2, (u0 + u1) / 2)
                cx.append(float(mx))
                cy.append(float(my))
                tx.append("ring %d · slot %d · slice %d → <b>%d</b>" % (L, r["slot"], (r["bit"] + k) % L, r["read"][k]))
        fig.add_trace(go.Scatter(x=cx, y=cy, mode="markers", marker=dict(size=8, color=READER, line=dict(color=INK, width=1.2)),
                                 text=tx, hovertemplate="%{text}<extra></extra>", name="slices read"))
    elif kind == "tape":
        L = rd["ring"]
        N = 1 << L
        tot = N * L
        g0 = rd["start"]
        cnt = min(rd["count"], tot)
        sgn = 1 if rd["direction"] == "clockwise" else -1
        a0 = g0 if sgn > 0 else g0 - cnt + 1
        u0, u1 = a0 / tot, (a0 + cnt) / tot
        k = max(8, int(400 * (u1 - u0)) + 2)
        px_, py_ = _cell_polygon(edges[L - 1], edges[L], u0, u1, k=k)
        fig.add_trace(go.Scatter(x=px_, y=py_, mode="lines", fill="toself", fillcolor="rgba(25,158,112,0.22)",
                                 line=dict(color=READER, width=2.5), name="tape reader (%d slices)" % cnt, hoverinfo="skip"))
        w = max(1, rd.get("window", 1))
        tx_, ty_ = [], []
        for j in range(0, cnt + 1, w):
            uu = (g0 + sgn * j) / tot if sgn > 0 else (g0 + 1 - j) / tot
            xa, ya = _polar_xy(np.array([edges[L - 1], edges[L] + 0.015]), np.array([uu, uu]))
            tx_ += list(xa) + [None]
            ty_ += list(ya) + [None]
        if len(tx_) < 3000:
            fig.add_trace(go.Scatter(x=tx_, y=ty_, mode="lines", line=dict(color=INK, width=1), hoverinfo="skip",
                                     name="window boundaries"))
        ue = (g0 + sgn * (cnt - 1) + 0.5) / tot
        ax, ay = _polar_xy(edges[L] + 0.05, ue)
        sx, sy = _polar_xy(edges[L] + 0.05, (g0 + 0.5) / tot)
        fig.add_annotation(x=float(sx), y=float(sy), text="start", showarrow=False, font=dict(color=READER, size=11))
        fig.add_annotation(x=float(ax), y=float(ay), text="end", showarrow=False, font=dict(color=READER, size=11))
    elif kind in ("native", "clock"):
        L = rd["ring"]
        N = 1 << L
        rm = (edges[L - 1] + edges[L]) / 2 if L <= len(edges) - 1 else 1.0
        A = rd["addresses"]
        uu = (np.array(A) + 0.5) / N
        x, y = _polar_xy(np.full(len(uu), rm * 0.98), uu)
        T = len(A)
        fig.add_trace(go.Scatter(x=x, y=y, mode="lines", line=dict(color="rgba(240,239,236,0.55)", width=1.4),
                                 hoverinfo="skip", name="route of p" if kind == "native" else "clock orbit"))
        fig.add_trace(go.Scatter(x=x, y=y, mode="markers",
                                 marker=dict(size=9, color=np.arange(T), colorscale=[[0, BLUE_RAMP[4]], [1, BLUE_RAMP[-1]]],
                                             line=dict(color=SURFACE, width=1.5)),
                                 text=rd.get("labels"), hovertemplate="%{text}<extra></extra>",
                                 showlegend=False))
        fig.add_trace(go.Scatter(x=[x[0]], y=[y[0]], mode="markers",
                                 marker=dict(size=14, symbol="star", color=YELLOW, line=dict(color=SURFACE, width=1.5)),
                                 name="start", hoverinfo="skip"))


# ----------------------------------------------------------------------------------------
# Ring order, comparator, address circuit
# ----------------------------------------------------------------------------------------

def fig_ring_order(n=5, height=640):
    R = rc.ring(n)
    N = 1 << n
    M = N // 2
    pal = rc.pal_table(n)
    a = np.arange(N)
    u = (a + 0.5) / N
    x, y = _polar_xy(np.ones(N), u)
    fig = make_subplots(rows=1, cols=2, column_widths=[0.58, 0.42], horizontal_spacing=0.04,
                        subplot_titles=("ring order (exact) · facing chords", "the ring as a bit table"))
    # facing chords
    cx, cy = [], []
    for i in range(M):
        j = N - 1 - i
        cx += [x[i], x[j], None]
        cy += [y[i], y[j], None]
    fig.add_trace(go.Scatter(x=cx, y=cy, mode="lines", line=dict(color="rgba(195,194,183,0.22)", width=1),
                             hoverinfo="skip", name="facing pair  i ↔ N−1−i"), row=1, col=1)
    if n >= 2:
        fig.add_trace(go.Scatter(x=[x[M - 1], x[M]], y=[y[M - 1], y[M]], mode="lines",
                                 line=dict(color=SEAM, width=2.5), name="seam pair (exchanged)",
                                 hoverinfo="skip"), row=1, col=1)
    face = np.where(a < M, "representative face", "partner face")
    colr = np.where(a < M, REP, PARTNER)
    tx = ["slot %d<br><b>%s</b> (%d)<br>partner %s<br>%s%s" % (i, rc.bits(int(R[i]), n), int(R[i]),
          rc.bits(rc.partner(int(R[i]), n), n), face[i], " · palindrome" if pal[R[i]] else "") for i in range(N)]
    sym = ["diamond" if pal[R[i]] else "circle" for i in range(N)]
    lc = [PAL if pal[R[i]] else SURFACE for i in range(N)]
    fig.add_trace(go.Scatter(x=x, y=y, mode="markers", marker=dict(size=13 if n <= 6 else 8, color=list(colr),
                             symbol=sym, line=dict(color=lc, width=2)), text=tx,
                             hovertemplate="%{text}<extra></extra>", showlegend=False), row=1, col=1)
    for nm, c_, s_ in (("representative face", REP, "circle"), ("partner face", PARTNER, "circle"),
                       ("palindrome (partner = complement)", PAL, "diamond")):
        fig.add_trace(go.Scatter(x=[None], y=[None], mode="markers", marker=dict(size=10, color=c_, symbol=s_),
                                 name=nm), row=1, col=1)
    if n <= 6:
        lx, ly = _polar_xy(np.full(N, 1.16), u)
        fig.add_trace(go.Scatter(x=lx, y=ly, mode="text", text=[rc.bits(int(v), n) for v in R],
                                 textfont=dict(family=MONO, size=10 if n <= 5 else 8, color=INK2),
                                 hoverinfo="skip", showlegend=False), row=1, col=1)
    # bit table
    X = ((R[:, None] >> np.arange(n - 1, -1, -1)[None, :]) & 1)
    fig.add_trace(go.Heatmap(z=X, x=["b%d" % k for k in range(n - 1, -1, -1)], y=list(range(N)),
                             colorscale=[[0, GAP_BIT], [1, LIGHT_BIT]], showscale=False, xgap=1, ygap=1 if N <= 64 else 0,
                             hovertemplate="slot %{y} · %{x} = %{z}<extra></extra>"), row=1, col=2)
    fig.update_yaxes(autorange="reversed", title="slot (address)", row=1, col=2)
    fig.update_xaxes(visible=False, range=[-1.35, 1.35], row=1, col=1)
    fig.update_yaxes(visible=False, range=[-1.35, 1.35], scaleanchor="x", scaleratio=1, row=1, col=1)
    fig.update_layout(height=height, title="R%d: %d words, %d facing pairs" % (n, N, M),
                      legend=dict(orientation="h", y=-0.08, x=0, xanchor="left", yanchor="top"))
    _subtitle(fig, "representatives ascend on the first face · each partner faces its word · the two seam words exchange places")
    return fig


def fig_comparator(n=8, height=420):
    N = 1 << n
    law = rc.comparator_ring_law(n)
    chi = np.where(np.arange(N) < N // 2, 1, -1)
    frac = float((law @ chi) ** 2 / ((law @ law) * N))
    cols = np.where(law > 0, REP, np.where(law < 0, PARTNER, PAL))
    fig = go.Figure()
    fig.add_trace(go.Bar(x=np.arange(N), y=law, marker=dict(color=list(cols), line=dict(width=0)),
                         name="c(R[i]) = sgn(J(x) − x)", hovertemplate="slot %{x}: %{y}<extra></extra>"))
    fig.add_trace(go.Scatter(x=np.arange(N), y=chi, mode="lines", line=dict(color=INK, width=1.4, shape="hv"),
                             name="top address bit (±1)"))
    fig.update_layout(height=height, bargap=0.0 if N > 128 else 0.1,
                      title="The comparator on ring addresses is one address bit",
                      xaxis_title="slot i", yaxis=dict(title="value", tickvals=[-1, 0, 1], range=[-1.35, 1.35]))
    _subtitle(fig, "c_R(i) = χ_top(i)·(1 − pal(i) − 2[i ∈ {M−1, M}]) · energy on the top bit %.4f%% at n = %d" % (100 * frac, n))
    return fig


def fig_borrow(x, n, height=320):
    j = rc.rev(x, n)
    rows = rc.borrow_chain(x, j, n)
    cols = list(range(n - 1, -1, -1))
    names = ["x", "J(x)", "borrow in", "borrow out"]
    Z = np.array([[rows[i][k] for i in cols] for k in (1, 2, 3, 4)])
    fig = go.Figure(go.Heatmap(z=Z, x=list(range(n)), y=list(range(4)), colorscale=[[0, GAP_BIT], [1, LIGHT_BIT]],
                               showscale=False, xgap=2, ygap=2, hoverinfo="skip"))
    tx, ty, tt, tc, th = [], [], [], [], []
    for r_ in range(4):
        for c_ in range(n):
            v_ = int(Z[r_, c_])
            tx.append(c_)
            ty.append(r_)
            tt.append(str(v_))
            tc.append(SURFACE if v_ else INK2)
            th.append("bit %d · %s = %d" % (cols[c_], names[r_], v_))
    fig.add_trace(go.Scatter(x=tx, y=ty, mode="text", text=tt, textfont=dict(family=MONO, size=13, color=tc),
                             customdata=th, hovertemplate="%{customdata}<extra></extra>", showlegend=False))
    lt = rows[-1][4]
    fig.update_layout(height=height, margin=dict(l=110, r=30, b=50),
                      title="Borrow chain for x − J(x): cell β′ = Maj(¬a, b, β), LSB first",
                      xaxis=dict(title="bit position (MSB left)", tickvals=list(range(n)), ticktext=[str(c) for c in cols]),
                      yaxis=dict(autorange="reversed", tickvals=list(range(4)), ticktext=names))
    _subtitle(fig, "x = %s · J(x) = %s · final borrow = [x < J(x)] = %d · c(x) = %+d"
              % (rc.bits(x, n), rc.bits(j, n), lt, rc.comparator(x, n)))
    return fig


# ----------------------------------------------------------------------------------------
# Readings: sphere, Thales, folded square, parabola, depth, rays
# ----------------------------------------------------------------------------------------

def fig_sphere(n=6, height=680):
    s = rc.sphere_coords(n)
    N = 1 << n
    M = N // 2
    pal = rc.pal_table(n)[s["words"]]
    col = np.where(np.arange(N) < M, REP, PARTNER)
    col = np.where(pal, PAL, col)
    tx = ["slot %d · %s<br>wt %d · latitude %+.1f" % (a, rc.bits(int(w), n), int(k), k - n / 2)
          for a, w, k in zip(s["addr"], s["words"], s["wt"])]
    fig = go.Figure()
    # latitude circles
    for k in range(n + 1):
        ct = 1 - 2 * k / n
        st = math.sqrt(max(0, 1 - ct * ct))
        t = np.linspace(0, 2 * np.pi, 120)
        fig.add_trace(go.Scatter3d(x=st * np.cos(t), y=st * np.sin(t), z=np.full(120, ct), mode="lines",
                                   line=dict(color=GRID, width=2), hoverinfo="skip", showlegend=False))
    if n <= 7:
        lx, ly, lz = [], [], []
        for a in range(M):
            b = N - 1 - a
            lx += [s["x"][a], s["x"][b], None]
            ly += [s["y"][a], s["y"][b], None]
            lz += [s["z"][a], s["z"][b], None]
        fig.add_trace(go.Scatter3d(x=lx, y=ly, z=lz, mode="lines", line=dict(color="rgba(195,194,183,0.16)", width=2),
                                   name="partner pairs", hoverinfo="skip"))
    fig.add_trace(go.Scatter3d(x=s["x"], y=s["y"], z=s["z"], mode="markers",
                               marker=dict(size=7 if n <= 7 else 4, color=list(col), line=dict(width=0)),
                               text=tx, hovertemplate="%{text}<extra></extra>", name="words"))
    for nm, c_ in (("representative face", REP), ("partner face", PARTNER), ("palindrome", PAL)):
        fig.add_trace(go.Scatter3d(x=[None], y=[None], z=[None], mode="markers", marker=dict(size=6, color=c_), name=nm))
    ax = dict(visible=False, showbackground=False)
    fig.update_layout(height=height, title="Sphere reading of R%d" % n,
                      scene=dict(xaxis=dict(ax, range=[-1.05, 1.05]), yaxis=dict(ax, range=[-1.05, 1.05]),
                                 zaxis=dict(ax, range=[-1.05, 1.05]), aspectmode="cube", bgcolor=SURFACE,
                                 camera=dict(eye=dict(x=1.05, y=0.95, z=0.55))),
                      margin=dict(l=0, r=0, t=78, b=0))
    _subtitle(fig, "a geometric reading: polar angle cos θ = 1 − 2·wt/n, azimuth = address · non-palindromes reflect (−φ, z), palindromes half-turn (−φ, −z)")
    return fig


def fig_thales(n=4, height=470):
    R = math.sqrt(n) / 2
    fig = go.Figure()
    t = np.linspace(0, np.pi, 200)
    fig.add_trace(go.Scatter(x=R * np.cos(t), y=R * np.sin(t), mode="lines", line=dict(color=GRID, width=2),
                             hoverinfo="skip", showlegend=False))
    fig.add_trace(go.Scatter(x=[-R, R], y=[0, 0], mode="lines", line=dict(color=MUTED, width=1.5),
                             name="the half-turn 0 → u  (Hamming: straight)", hoverinfo="skip"))
    pts = []
    for k in range(n + 1):
        ct = 1 - 2 * k / n
        th = math.acos(ct)
        pts.append((R * math.cos(math.pi - th), R * math.sin(math.pi - th), k, th))
    fig.add_trace(go.Scatter(x=[p[0] for p in pts], y=[p[1] for p in pts], mode="markers+text",
                             marker=dict(size=11, color=BLUE, line=dict(color=SURFACE, width=2)),
                             text=["wt %d" % p[2] for p in pts], textposition="top center",
                             textfont=dict(color=INK2, size=11), hovertemplate="%{text}<extra></extra>",
                             showlegend=False))
    p1 = pts[1]
    fig.add_trace(go.Scatter(x=[-R, p1[0], R], y=[0, p1[1], 0], mode="lines", line=dict(color=YELLOW, width=2.5),
                             name="Pi-Ray: x and its complement (Euclid: right angle at x)", hoverinfo="skip"))
    fig.add_annotation(x=-R, y=0, text="0", showarrow=False, yshift=-14, font=dict(color=INK, family=MONO))
    fig.add_annotation(x=R, y=0, text="u", showarrow=False, yshift=-14, font=dict(color=INK, family=MONO))
    fig.update_layout(height=height, title="The Pi-Ray: wt(x) + wt(u ⊕ x) = n and ‖x‖² + ‖u − x‖² = n",
                      legend=dict(orientation="h", y=-0.05, x=0, yanchor="top", xanchor="left"))
    _subtitle(fig, "n = %d: weights 0..%d at polar angles %s · the one-bit Pi-Ray has Euclidean sides 1, √%d, √%d"
              % (n, n, ", ".join("%d°" % round(math.degrees(p[3])) for p in pts), n - 1, n))
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False, scaleanchor="x", scaleratio=1)
    return fig


def fig_folded_square(n=10, height=620):
    fs = rc.folded_square(n)
    P = rc.partner_table(n)
    w = fs["words"]
    rep = w < P
    pal = rc.pal_table(n)
    col = np.where(pal, PAL, np.where(rep, REP, PARTNER))
    tx = ["%s · (φ, γ) = (%.3f, %.3f)" % (rc.bits(int(v), n), a, b) for v, a, b in zip(w, fs["phi"], fs["gamma"])]
    fig = go.Figure()
    fig.add_trace(go.Scattergl(x=fs["phi"], y=fs["gamma"], mode="markers",
                               marker=dict(size=6 if n <= 8 else 4, color=list(col)), text=tx,
                               hovertemplate="%{text}<extra></extra>", showlegend=False))
    fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", line=dict(color=PAL, width=1, dash="dot"),
                             name="diagonal: palindromes", hoverinfo="skip"))
    for nm, c_ in (("representative", REP), ("partner (mirror cell)", PARTNER)):
        fig.add_trace(go.Scatter(x=[None], y=[None], mode="markers", marker=dict(size=9, color=c_), name=nm))
    for (qx, qy, lab, note) in ((0.25, 0.75, "01", "yes"), (0.75, 0.25, "10", "no"),
                                (0.25, 0.25, "00", "maybe"), (0.75, 0.75, "11", "maybe")):
        fig.add_annotation(x=qx, y=qy, text="<b>%s</b><br><span style='font-size:11px'>%s</span>" % (lab, note),
                           showarrow=False, font=dict(color=INK, size=16, family=MONO), opacity=0.55)
    fig.add_shape(type="line", x0=0.5, x1=0.5, y0=0, y1=1, line=dict(color=BORDER, width=1))
    fig.add_shape(type="line", x0=0, x1=1, y0=0.5, y1=0.5, line=dict(color=BORDER, width=1))
    fig.update_layout(height=height, title="The folded square at width %d" % n,
                      xaxis=dict(title="φ = front half", range=[-0.02, 1.02], constrain="domain"),
                      yaxis=dict(title="γ = reversed back half", range=[-0.02, 1.02], scaleanchor="x", scaleratio=1),
                      legend=dict(orientation="h", y=-0.12, x=0, yanchor="top", xanchor="left"))
    _subtitle(fig, "each word at (front half, reversed back half) · the frame of a word is its quadrant · partner = mirror cell; on the diagonal, the antipode")
    return fig


def fig_parabola(n=14, height=460):
    t, u, res = rc.parabola_residual(n)
    fig = make_subplots(rows=1, cols=2, horizontal_spacing=0.09,
                        subplot_titles=("angle of every representative against its value", "what the parabola leaves × 2^(L/2)"))
    fig.add_trace(go.Scattergl(x=t, y=u, mode="markers", marker=dict(size=2.4, color=REP), name="representatives",
                               hoverinfo="skip"), row=1, col=1)
    tt = np.linspace(0, 1, 300)
    fig.add_trace(go.Scatter(x=tt, y=tt - tt * tt / 2, mode="lines", line=dict(color=INK, width=1.5),
                             name="u = t − t²/2"), row=1, col=1)
    for (xx, yy, lab) in ((0.5, 3 / 8, "frame 11 begins: 3/8"), (1.0, 0.5, "seam: 1/2"),
                          (1 - 2 ** -0.5, 0.25, "quarter turn: t = 1 − 1/√2")):
        fig.add_trace(go.Scatter(x=[xx], y=[yy], mode="markers+text", marker=dict(size=9, color=YELLOW),
                                 text=[lab], textposition="middle right" if xx < 0.9 else "middle left",
                                 textfont=dict(color=INK2, size=11), showlegend=False, hoverinfo="skip"), row=1, col=1)
    sc = 2 ** (n / 2)
    fig.add_trace(go.Scattergl(x=t, y=res * sc, mode="markers", marker=dict(size=2.2, color=AQUA),
                               name="residual × 2^(L/2)", hoverinfo="skip"), row=1, col=2)
    fig.add_trace(go.Scatter(x=tt, y=0.5 * np.minimum(tt, 1 - tt), mode="lines", line=dict(color=INK, width=1.5),
                             name="tent ½·min(t, 1 − t)"), row=1, col=2)
    fig.update_xaxes(title="value t = x/N", row=1, col=1)
    fig.update_yaxes(title="angle u = address/N", row=1, col=1)
    fig.update_xaxes(title="value t", row=1, col=2)
    fig.update_layout(height=height, title="The representative density is the line 1 − t; location is its integral",
                      legend=dict(orientation="h", y=-0.2, x=0, yanchor="top", xanchor="left"))
    _subtitle(fig, "width %d · max |u − (t − t²/2)| = %.3g < 2^(−L/2+1) = %.3g" % (n, np.abs(res).max(), 2 ** (-n / 2 + 1)))
    return fig


def fig_depth(n=14, height=460):
    P = rc.partner_table(n)
    N = 1 << n
    A = rc.address_table(n)
    xs, ds, br = [], [], []
    for x in range(N):
        if x < P[x]:
            d, root, L = rc.depth(x, n)
            xs.append(A[x] / N)
            ds.append(d)
            br.append("complement" if rc.is_pal(x, n) else "reversal")
    xs, ds, br = np.array(xs), np.array(ds), np.array(br)
    fig = make_subplots(rows=1, cols=2, column_widths=[0.62, 0.38], horizontal_spacing=0.1,
                        subplot_titles=("continuation depth of every representative against its angle", "Pr(depth ≥ t) against 4^−t"))
    rng = np.random.default_rng(1)
    jit = rng.uniform(-0.18, 0.18, len(ds))
    for b_, c_ in (("reversal", REP), ("complement", PAL)):
        m = br == b_
        fig.add_trace(go.Scattergl(x=xs[m], y=ds[m] + jit[m], mode="markers",
                                   marker=dict(size=3 if b_ == "reversal" else 7, color=c_),
                                   name="%s branch" % b_, hoverinfo="skip"), row=1, col=1)
    for v, lab in ((0.5, "seam 1/2"), (5 / 18, "5/18")):
        fig.add_vline(x=v, line=dict(color=YELLOW, width=1, dash="dot"), row=1, col=1)
        fig.add_annotation(x=v, y=max(ds) + 0.6, text=lab, showarrow=False, font=dict(color=YELLOW, size=11), row=1, col=1)
    K = (n - 1) // 2
    M = len(ds)
    emp = [float((ds >= t).sum()) / M for t in range(1, K + 1)]
    fig.add_trace(go.Bar(x=list(range(1, K + 1)), y=emp, marker=dict(color=BLUE), name="measured",
                         hovertemplate="t=%{x}: %{y:.6g}<extra></extra>"), row=1, col=2)
    fig.add_trace(go.Scatter(x=list(range(1, K + 1)), y=[4.0 ** -t for t in range(1, K + 1)], mode="lines+markers",
                             marker=dict(size=8, color=INK), line=dict(color=INK, width=1.5, dash="dot"),
                             name="4^−t"), row=1, col=2)
    fig.update_yaxes(type="log", dtick=1, tickformat=".0e", row=1, col=2)
    fig.update_xaxes(title="angle u", row=1, col=1)
    fig.update_yaxes(title="depth (jittered)", row=1, col=1)
    fig.update_xaxes(title="t", row=1, col=2)
    fig.update_layout(height=height, title="Continuation: one provider in four",
                      legend=dict(orientation="h", y=-0.2, x=0, yanchor="top", xanchor="left"))
    mean = float(ds.mean())
    _subtitle(fig, "width %d · roots %d = 3·2^(L−3) · mean depth %.6f = (1 − 4^−%d)/3" % (n, int((ds == 0).sum()), mean, K))
    return fig


def fig_rays(maxw=120, height=400):
    a, w = 0, 2
    W, ev, ea = [], [], []
    for k in range((maxw - 2) // 2):
        a, w = rc.F_step(a, w)
        W.append(w)
        ev.append(abs(float(Fraction(a, 1 << w) - Fraction(1, 3))))
        ea.append(abs(float(Fraction(rc.address(a, w), 1 << w) - Fraction(5, 18))))
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=W, y=ev, mode="lines+markers", marker=dict(size=4), line=dict(color=BLUE, width=2),
                             name="|value − 1/3|"))
    fig.add_trace(go.Scatter(x=W, y=ea, mode="lines+markers", marker=dict(size=4), line=dict(color=MAGENTA, width=2),
                             name="|angle − 5/18|"))
    fig.update_layout(height=height, title="The complement branch compiles toward value 1/3 at angle 5/18",
                      xaxis_title="width", yaxis=dict(type="log", title="distance (exact arithmetic)", dtick=3, tickformat=".0e"))
    _subtitle(fig, "ray of the root 00: 00, 0110, 010010, 01011010, … · φ ↦ (1 − φ)/2 · width %d reads value %.12f, angle %.12f"
              % (W[-1], float(Fraction(a, 1 << w)), float(Fraction(rc.address(a, w), 1 << w))))
    return fig


# ----------------------------------------------------------------------------------------
# Möbius bridge, frames, radial language, witness
# ----------------------------------------------------------------------------------------

def fig_mobius(n=5, height=520):
    r = rc.mobius_check(n)
    mats = [("X: the ring", r["X"]), ("D = (I ⊕ T)X: the XOR stream", r["D"]),
            ("A = MX: Möbius spectrum", r["A"]), ("MD (equals SA)", r["MD"])]
    fig = make_subplots(rows=1, cols=4, horizontal_spacing=0.035, subplot_titles=[m[0] for m in mats])
    for k, (nm, Z) in enumerate(mats):
        Zr = Z[:, ::-1]
        fig.add_trace(go.Heatmap(z=Zr, colorscale=[[0, GAP_BIT], [1, LIGHT_BIT]], showscale=False, xgap=1,
                                 ygap=1 if Z.shape[0] <= 64 else 0, hovertemplate="row %{y} · col %{x} = %{z}<extra></extra>"),
                      row=1, col=k + 1)
        fig.update_yaxes(autorange="reversed", showticklabels=(k == 0), row=1, col=k + 1)
        fig.update_xaxes(showticklabels=False, row=1, col=k + 1)
    fig.update_layout(height=height, title="Boolean Möbius bridge at width %d: MD = SA, and X = M Sᵀ M D" % n)
    _subtitle(fig, "MD = SA: %s · lossless rebuild of X from D: %s · top row of A is zero: %s"
              % (r["ok_bridge"], r["ok_rebuild"], r["top_row_zero"]))
    return fig


def fig_frames(Lmin=4, Lmax=16, height=480):
    rows, Ls = [], list(range(Lmin, Lmax + 1))
    Z = np.full((len(Ls), Lmax), np.nan)
    ok_all = True
    for i, L in enumerate(Ls):
        P = 1 << ((L + 1) // 2)
        for s in range(L):
            lo = rc.frame_loss(L, s)
            Z[i, s] = lo / P
            ok_all &= (lo == rc.frame_law(L, s))
    fig = make_subplots(rows=1, cols=2, column_widths=[0.55, 0.45], horizontal_spacing=0.15,
                        subplot_titles=("words missed by frame s, / number of palindromes", "L = %d: measured and the frame law" % Lmax))
    fig.add_trace(go.Heatmap(z=Z, x=list(range(Lmax)), y=Ls, colorscale=[[0, BLUE_RAMP[0]], [1, BLUE_RAMP[-1]]],
                             zmin=0, zmax=1, colorbar=dict(title=dict(text="loss / P", side="right"), len=0.75, x=0.52, thickness=12),
                             hovertemplate="L=%{y} · s=%{x} · loss/P = %{z:.4f}<extra></extra>", xgap=1, ygap=1),
                  row=1, col=1)
    L = Lmax
    s = list(range(L))
    fig.add_trace(go.Bar(x=s, y=[rc.frame_loss(L, k) for k in s], marker=dict(color=BLUE), name="measured loss"),
                  row=1, col=2)
    fig.add_trace(go.Scatter(x=s, y=[rc.frame_law(L, k) for k in s], mode="lines+markers",
                             marker=dict(size=8, color=INK), line=dict(color=INK, width=1.5, dash="dot"), name="frame law"),
                  row=1, col=2)
    fig.update_xaxes(title="offset s", row=1, col=1)
    fig.update_yaxes(title="width L", row=1, col=1)
    fig.update_xaxes(title="offset s", row=1, col=2)
    fig.update_layout(height=height, title="The tape at every offset: every miss is owned by a palindrome",
                      legend=dict(orientation="h", y=-0.2, x=0.55, yanchor="top", xanchor="left"))
    _subtitle(fig, "frames 0 and 1 are complete at every width; frame 2 is complete for L ≥ 6 · law equals measurement at every cell: %s" % ok_all)
    return fig


def fig_radial_language(Dmax=14, height=420):
    Ds = list(range(2, Dmax + 1))
    R = []
    for D in Ds:
        R.append(rc.radial_language(D)[0])
    deficit = [D - math.log2(r) for D, r in zip(Ds, R)]
    fig = make_subplots(rows=1, cols=2, horizontal_spacing=0.1,
                        subplot_titles=("distinct radial profiles R_D", "bits lost per ring"))
    fig.add_trace(go.Bar(x=Ds, y=R, marker=dict(color=BLUE), name="R_D", hovertemplate="D=%{x}: %{y}<extra></extra>"),
                  row=1, col=1)
    fig.add_trace(go.Scatter(x=Ds, y=[2 ** d for d in Ds], mode="lines", line=dict(color=MUTED, dash="dot"), name="2^D"),
                  row=1, col=1)
    fig.update_yaxes(type="log", dtick=1, row=1, col=1)
    inc = [deficit[i] - deficit[i - 1] for i in range(1, len(deficit))]
    fig.add_trace(go.Scatter(x=Ds[1:], y=inc, mode="lines+markers", line=dict(color=AQUA, width=2), marker=dict(size=7),
                             name="deficit added per ring"), row=1, col=2)
    fig.update_xaxes(title="depth D", row=1, col=1)
    fig.update_xaxes(title="depth D", row=1, col=2)
    fig.update_layout(height=height, title="The radial language: how many words the rings let one ray read",
                      legend=dict(orientation="h", y=-0.22, x=0, yanchor="top", xanchor="left"))
    _subtitle(fig, "exact count on the merged slice grid · growth rate and the limit of R_D / 2^D: OPEN")
    return fig


def fig_witness(D=24, height=None):
    u, p, t = rc.witness_angle(D)
    rd = rc.radial_read(u, D)
    Z = np.full((D, D), np.nan)
    txt = [[""] * D for _ in range(D)]
    for r in rd:
        L = r["ring"]
        s = rc.bits(r["word"], L)
        for k, ch in enumerate(s):
            Z[L - 1, k] = int(ch)
            txt[L - 1][k] = "ring %d · slot %d · slice %d = %s" % (L, r["slot"], k, ch)
    fig = go.Figure(go.Heatmap(z=Z, colorscale=[[0, GAP_BIT], [1, LIGHT_BIT]], showscale=False, xgap=1, ygap=1,
                               text=txt, hovertemplate="%{text}<extra></extra>"))
    for r in rd:
        L = r["ring"]
        fig.add_shape(type="rect", x0=r["bit"] - 0.5, x1=r["bit"] + 0.5, y0=L - 1.5, y1=L - 0.5,
                      line=dict(color=READER, width=2.5))
        fig.add_annotation(x=D + 0.4, y=L - 1, text="<b>%d</b>" % r["read"][0], showarrow=False, xanchor="left",
                           font=dict(color=INK if r["read"][0] else MUTED, family=MONO, size=12))
    fig.update_layout(height=height or max(420, 22 * D + 120),
                      title="One angle for every depth: u_D reads 1 00 1^(D−5) 00 at D = %d" % D,
                      xaxis=dict(title="slice (MSB first)", range=[-0.6, D + 1.6], dtick=2),
                      yaxis=dict(title="ring L", autorange="reversed", tickvals=list(range(0, D, 2)),
                                 ticktext=[str(k + 1) for k in range(0, D, 2)]))
    _subtitle(fig, "u_D = 1/2 + 2^−%d + τ·2^−%d, τ = 2/3 + 1/(4D) · each row is the word under the reader on ring L; the boxed slice is the one read"
              % (p, D - 1))
    return fig


def fig_tape_ribbon(windows, width, title="What the reader read", height=None):
    Z = np.array([[int(c) for c in rc.bits(w, width)] for w in windows]) if windows else np.zeros((1, width))
    fig = go.Figure(go.Heatmap(z=Z, colorscale=[[0, GAP_BIT], [1, LIGHT_BIT]], showscale=False, xgap=1,
                               ygap=1 if len(windows) <= 80 else 0,
                               hovertemplate="read %{y} · bit %{x} = %{z}<extra></extra>"))
    fig.update_layout(height=height or min(640, 120 + 14 * max(1, len(windows))), title=title,
                      xaxis=dict(title="bit (MSB first)", dtick=1 if width <= 24 else 4),
                      yaxis=dict(title="read #", autorange="reversed"))
    return fig


# ----------------------------------------------------------------------------------------
# Clock
# ----------------------------------------------------------------------------------------

def fig_clock_census(nmax=15, height=440):
    xs, ys, ss, tx = [], [], [], []
    for n in range(1, nmax + 1):
        c = rc.orbit_census(n)
        for L, k in sorted(c.items()):
            xs.append(L)
            ys.append(n)
            ss.append(k)
            tx.append("n = %d · orbit length %d · %d orbits%s" % (n, L, k, " · the bare sign" if L == 6 else ""))
    sz = [8 + 5 * math.log2(1 + k) for k in ss]
    col = [YELLOW if L == 6 else (VIOLET if L == 2 else BLUE) for L in xs]
    fig = go.Figure(go.Scatter(x=xs, y=ys, mode="markers", marker=dict(size=sz, color=col, line=dict(color=SURFACE, width=1.5)),
                               text=tx, hovertemplate="%{text}<extra></extra>", showlegend=False))
    for nm, c_ in (("full lap 2n", BLUE), ("bare sign (6)", YELLOW), ("flip pair (2)", VIOLET)):
        fig.add_trace(go.Scatter(x=[None], y=[None], mode="markers", marker=dict(size=10, color=c_), name=nm))
    fig.update_layout(height=height, title="Orbits of the one-inverter clock: lengths 2n/d over odd d | n",
                      xaxis=dict(title="orbit length", type="log", tickvals=[2, 4, 6, 8, 10, 14, 18, 22, 30]),
                      yaxis=dict(title="width n", dtick=1))
    _subtitle(fig, "marker area ~ number of orbits · the six-tick bare sign appears inside a larger lap exactly at n = 3 × odd: 3, 9, 15, …")
    return fig


def fig_nine_modes(height=430):
    orb0 = rc.tau_orbit(0, 9)
    six = next(o for o in (rc.tau_orbit(x, 9) for x in range(512)) if len(o) == 6)
    two = next(o for o in (rc.tau_orbit(x, 9) for x in range(512)) if len(o) == 2)
    panels = [(orb0, 0, "zero point · fundamental mode π/9 (20°)"),
              (six, 1, "bare sign · mode 3π/9 (60°)"),
              (two, 4, "flip pair · mode 9π/9 (180°)")]
    fig = make_subplots(rows=1, cols=3, horizontal_spacing=0.03, subplot_titles=[p[2] for p in panels])
    for k, (orb, mode, _) in enumerate(panels):
        z, lam = rc.mode_projection(orb, 9, mode)
        z = z / abs(z[0])
        z = z * np.exp(1j * (np.pi / 2 - np.angle(z[0])))   # tick 0 at the top
        X, Y = z.real, z.imag
        step = (2 * mode + 1) * 20
        for sdeg in range(0, 360, 20):
            a = math.radians(90 - sdeg)
            fig.add_trace(go.Scatter(x=[0, 1.12 * math.cos(a)], y=[0, 1.12 * math.sin(a)], mode="lines",
                                     line=dict(color=GRID, width=1), hoverinfo="skip", showlegend=False), row=1, col=k + 1)
        fig.add_trace(go.Scatter(x=list(X) + [X[0]], y=list(Y) + [Y[0]], mode="lines",
                                 line=dict(color="rgba(240,239,236,0.35)", width=1), hoverinfo="skip", showlegend=False),
                      row=1, col=k + 1)
        fig.add_trace(go.Scatter(x=X, y=Y, mode="markers+text", text=[str(t) for t in range(len(orb))],
                                 textposition="top center", textfont=dict(color=INK2, size=10, family=MONO),
                                 marker=dict(size=10, color=[YELLOW] + [BLUE] * (len(orb) - 1),
                                             line=dict(color=SURFACE, width=1.5)),
                                 customdata=[rc.bits(v, 9) for v in orb],
                                 hovertemplate="tick %{text}<br>%{customdata}<extra></extra>", showlegend=False),
                      row=1, col=k + 1)
        fig.update_xaxes(visible=False, range=[-1.3, 1.3], row=1, col=k + 1)
        fig.update_yaxes(visible=False, range=[-1.3, 1.3], scaleanchor="x%s" % ("" if k == 0 else k + 1),
                         scaleratio=1, row=1, col=k + 1)
    fig.update_layout(height=height, title="The nine-cell clock read in its own eigenmodes")
    _subtitle(fig, "spokes every 20° · the spin vector projected on the eigenvector of e^{iπ(2k+1)/9} turns by exactly (2k+1)·20° per tick")
    return fig


def fig_eigencircle(n=9, height=360):
    t = np.linspace(0, 2 * np.pi, 361)
    fig = go.Figure(go.Scatter(x=np.cos(t), y=np.sin(t), mode="lines", line=dict(color=GRID, width=1.5),
                               hoverinfo="skip", showlegend=False))
    ev = np.linalg.eigvals(rc.spin_matrix(n))
    fig.add_trace(go.Scatter(x=ev.real, y=ev.imag, mode="markers", marker=dict(size=11, color=BLUE, line=dict(color=SURFACE, width=1.5)),
                             text=["%.0f°" % math.degrees(abs(np.angle(l))) for l in ev],
                             hovertemplate="angle %{text}<extra></extra>", showlegend=False))
    lam = np.exp(1j * np.pi / n)
    fig.add_trace(go.Scatter(x=[0, lam.real], y=[0, lam.imag], mode="lines", line=dict(color=YELLOW, width=2),
                             name="fundamental π/%d" % n, hoverinfo="skip"))
    fig.update_layout(height=height, title="Spin clock at n = %d: eigenvalues are the roots of λⁿ = −1" % n,
                      legend=dict(orientation="h", y=-0.05, x=0, yanchor="top", xanchor="left"))
    fig.update_xaxes(visible=False, range=[-1.25, 1.25])
    fig.update_yaxes(visible=False, range=[-1.25, 1.25], scaleanchor="x", scaleratio=1)
    return fig


def fig_clock_strip(x0, n, height=None):
    orb = []
    y = x0
    for _ in range(2 * n):
        orb.append(y)
        y = rc.tau(y, n)
    Z = np.array([[int(c) for c in rc.bits(v, n)] for v in orb])
    fig = go.Figure(go.Heatmap(z=Z, colorscale=[[0, GAP_BIT], [1, LIGHT_BIT]], showscale=False, xgap=1, ygap=1,
                               x=["b%d" % k for k in range(n - 1, -1, -1)],
                               hovertemplate="tick %{y} · %{x} = %{z}<extra></extra>"))
    fig.add_hline(y=n - 0.5, line=dict(color=YELLOW, width=1.5, dash="dot"))
    fig.add_annotation(x=n - 0.5, y=n - 0.5, text="τⁿ = C: the complement", showarrow=False, xanchor="left",
                       font=dict(color=YELLOW, size=11), xshift=6)
    fig.update_layout(height=height or (140 + 15 * 2 * n), title="One lap of the one-inverter clock from %s" % rc.bits(x0, n),
                      xaxis=dict(side="top"), yaxis=dict(title="tick", autorange="reversed"))
    return fig


# ----------------------------------------------------------------------------------------
# Machine
# ----------------------------------------------------------------------------------------

def fig_route(n, rows, height=560, title=None):
    N = 1 << n
    A = rc.address_table(n) if n <= 16 else None
    ps = [r["p"] for r in rows] + ([rows[-1]["p"] ^ rows[-1]["x"]] if rows else [])
    addr = [int(A[p]) if A is not None else rc.address(p, n) for p in ps]
    u = (np.array(addr) + 0.5) / N
    x, y = _polar_xy(np.ones(len(u)), u)
    fig = go.Figure()
    t = np.linspace(0, 1, 400)
    cx, cy = _polar_xy(np.ones(400), t)
    fig.add_trace(go.Scatter(x=cx, y=cy, mode="lines", line=dict(color=GRID, width=6), hoverinfo="skip", showlegend=False))
    seg_x, seg_y = [], []
    for i in range(len(x) - 1):
        seg_x += [x[i], x[i + 1], None]
        seg_y += [y[i], y[i + 1], None]
    fig.add_trace(go.Scatter(x=seg_x, y=seg_y, mode="lines", line=dict(color="rgba(57,135,229,0.45)", width=1.2),
                             hoverinfo="skip", name="moves p → p ⊕ x"))
    tx = ["tick %d · p = %s (slot %d)" % (i, rc.bits(p, n), a) for i, (p, a) in enumerate(zip(ps, addr))]
    fig.add_trace(go.Scatter(x=x, y=y, mode="markers", marker=dict(size=9, color=np.arange(len(x)),
                             colorscale=[[0, BLUE_RAMP[3]], [1, BLUE_RAMP[-1]]], line=dict(color=SURFACE, width=1.5)),
                             text=tx, hovertemplate="%{text}<extra></extra>", showlegend=False))
    fig.add_trace(go.Scatter(x=[x[0]], y=[y[0]], mode="markers", marker=dict(size=15, symbol="star", color=YELLOW),
                             name="start"))
    fig.update_layout(height=height, title=title or "Route of the reader on R%d" % n,
                      legend=dict(orientation="h", y=-0.04, x=0, yanchor="top", xanchor="left"))
    _subtitle(fig, "positions drawn at their ring addresses · ticks shown %d" % len(rows))
    _blank_axes(fig, lim=1.12)
    return fig


def fig_field(n, D0, rows, height=None, title=None):
    """Kept field over time: one row per cell the reader ever touches, ticks across."""
    D = dict(D0 or {})
    snaps = []
    Pt = [int(v) for v in rc.partner_table(n)]
    p, w = rows[0]["p"], rows[0]["w"]
    touched = set(D)
    for r in rows:
        snaps.append(dict(D))
        touched.add(p)
        p, w, _, _ = rc.step(p, w, D, n, Pt)
    cells = sorted(touched, key=lambda q: int(rc.address_table(n)[q]) if n <= 16 else q)
    Z = np.array([[s.get(q, 0) for s in snaps] for q in cells], dtype=float)
    txt = [["cell %s · tick %d · %s" % (rc.bits(q, n), t, rc.bits(int(z), n) if z else "empty") for t, z in enumerate(row)]
           for q, row in zip(cells, Z)]
    occ = (Z != 0).astype(float)
    fig = go.Figure(go.Heatmap(z=occ, x=list(range(len(rows))), y=[rc.bits(q, n) for q in cells],
                               colorscale=[[0, GAP_BIT], [1, AQUA]], showscale=False, xgap=0, ygap=3,
                               text=txt, hovertemplate="%{text}<extra></extra>"))
    fig.update_layout(height=height or max(260, 150 + 34 * len(cells)), title=title or "The kept field: the reader's own past carries",
                      xaxis_title="tick", yaxis=dict(title="cell", type="category", tickfont=dict(family=MONO)))
    _subtitle(fig, "rows: every cell the reader touches · lit while the cell holds a carry · a cell holds the carry the reader arrived with, complemented, adjusted by one lamp (3.7)")
    return fig


def fig_johnson(height=480):
    V = [(a, b, c) for a in (0, 1) for b in (0, 1) for c in (0, 1)]
    fig = go.Figure()
    ex, ey, ez = [], [], []
    for p in V:
        for q in V:
            if p < q and sum(i != j for i, j in zip(p, q)) == 1:
                ex += [p[0], q[0], None]
                ey += [p[1], q[1], None]
                ez += [p[2], q[2], None]
    fig.add_trace(go.Scatter3d(x=ex, y=ey, z=ez, mode="lines", line=dict(color=BORDER, width=3), hoverinfo="skip",
                               showlegend=False))
    J = rc.JOHNSON + [rc.JOHNSON[0]]
    fig.add_trace(go.Scatter3d(x=[j[0] for j in J], y=[j[1] for j in J], z=[j[2] for j in J], mode="lines+markers+text",
                               line=dict(color=YELLOW, width=7), marker=dict(size=6, color=YELLOW),
                               text=["".join(map(str, j)) for j in J[:-1]] + [""], textfont=dict(color=INK, family=MONO),
                               name="bare sign: Z_t = (p, p⊕w, p⊕w⊕d)"))
    fig.add_trace(go.Scatter3d(x=[0, 1], y=[0, 1], z=[0, 1], mode="lines", line=dict(color=VIOLET, width=3, dash="dash"),
                               name="the −1 axis (complement)"))
    ax = dict(visible=False, showbackground=False)
    fig.update_layout(height=height, title="The bare sign is the clock on three cells: a skew Petrie hexagon of the cube",
                      scene=dict(xaxis=ax, yaxis=ax, zaxis=ax, aspectmode="cube", camera=dict(eye=dict(x=1.6, y=-1.4, z=0.9))),
                      margin=dict(l=0, r=0, t=78, b=0), legend=dict(orientation="h", y=0.02, x=0))
    _subtitle(fig, "000 → 010 → 011 → 111 → 101 → 100 → 000 · centered at (½,½,½) the step is the rotoinversion M, M³ = −I")
    return fig


def fig_event_log(W, q, Wr, n, height=330):
    T = len(W)
    Z = np.array([[int(c) for c in rc.bits(v, n)] for v in W]).T
    Q = np.array([[int(c) for c in rc.bits(v, n)] for v in q]).T
    Zr = np.array([[int(c) for c in rc.bits(v, n)] for v in Wr]).T
    fig = make_subplots(rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.16,
                        subplot_titles=("carry stream w_t", "switch tape q_t = w_t ⊕ w_t+1 ⊕ w_t+2 (the event log)",
                                        "carry stream rebuilt from the tape"))
    for i, M_ in enumerate((Z, Q, Zr)):
        fig.add_trace(go.Heatmap(z=M_, colorscale=[[0, GAP_BIT], [1, LIGHT_BIT]], showscale=False, xgap=0, ygap=1,
                                 hovertemplate="tick %{x} · bit %{y} = %{z}<extra></extra>"), row=i + 1, col=1)
        fig.update_yaxes(showticklabels=False, row=i + 1, col=1)
    fig.update_xaxes(title="tick", row=3, col=1)
    fig.update_layout(height=height + 140, title="Event sourcing the reader: the tape rebuilds the route",
                      margin=dict(t=110))
    return fig


# ----------------------------------------------------------------------------------------
# Collision and ports
# ----------------------------------------------------------------------------------------

def fig_port(rows, height=520, title=None):
    """Two-shell carrier drawn as a 4 x 8 grid of its 32 words; reader paths over the ticks."""
    def pos(w):
        return (w % 8, w // 8)
    fig = go.Figure()
    xs = [pos(w)[0] for w in range(32)]
    ys = [pos(w)[1] for w in range(32)]
    col = [VIOLET if w in rc.FIX1 else (GREEN if w in rc.FIX0 else PANEL2) for w in range(32)]
    lc = [VIOLET if w in rc.FIX1 else BORDER for w in range(32)]
    tx = ["word %d = %s%s" % (w, rc.bits(w, 5), " · Fix₁ (the pair never stands here)" if w in rc.FIX1 else
          (" · Fix₀ (empty-field landing)" if w in rc.FIX0 else "")) for w in range(32)]
    fig.add_trace(go.Scatter(x=xs, y=ys, mode="markers+text", text=[str(w) for w in range(32)],
                             textfont=dict(color=INK, family=MONO, size=11),
                             marker=dict(size=34, symbol="square", color=col, line=dict(color=lc, width=2)),
                             customdata=tx, hovertemplate="%{customdata}<extra></extra>", showlegend=False))
    for key, c_, nm in (("A", BLUE, "reader A"), ("B", ORANGE, "reader B"), ("C", AQUA, "third reader C (the port)")):
        pts = [r[key][0] for r in rows if key in r]
        if not pts:
            continue
        px_ = [pos(p)[0] + {"A": -0.18, "B": 0.0, "C": 0.18}[key] for p in pts]
        py_ = [pos(p)[1] + {"A": 0.2, "B": 0.0, "C": -0.2}[key] for p in pts]
        fig.add_trace(go.Scatter(x=px_, y=py_, mode="lines+markers", line=dict(color=c_, width=2.5),
                                 marker=dict(size=8, color=c_, symbol="circle"),
                                 text=["%s tick %d at %d" % (key, i, p) for i, p in enumerate(pts)],
                                 hovertemplate="%{text}<extra></extra>", name=nm))
        fig.add_annotation(x=px_[-1], y=py_[-1], ax=px_[-2] if len(px_) > 1 else px_[-1], ay=py_[-2] if len(py_) > 1 else py_[-1],
                           xref="x", yref="y", axref="x", ayref="y", showarrow=True, arrowhead=3, arrowsize=1.2,
                           arrowcolor=c_, text="")
    fig.update_layout(height=height, title=title or "The directed port: one aimed write opens a word the pair never reaches",
                      xaxis=dict(visible=False, range=[-0.7, 7.7]), yaxis=dict(visible=False, range=[3.7, -0.7], scaleanchor="x"),
                      legend=dict(orientation="h", y=-0.03, x=0, yanchor="top", xanchor="left"))
    _subtitle(fig, "32 words of the two-shell carrier (eR, eL, oR, oL, u = 1, 2, 4, 8, 16) · violet: Fix₁ = {5, 10, 21, 26} · green: Fix₀")
    return fig


# ----------------------------------------------------------------------------------------
# Read models
# ----------------------------------------------------------------------------------------

def _xpoly_coords():
    # complement pairs of the eight-word carrier (basis a=1, b=2, v=4; u = 7) -> +-e_i in R^4
    pairs = [(0, 7), (1, 6), (2, 5), (3, 4)]
    E = {}
    for i, (x, y) in enumerate(pairs):
        v = np.zeros(4)
        v[i] = 1
        E[x], E[y] = v, -v
    Pm = np.array([[1, 0, 0, 0.45], [0, 1, 0, 0.35], [0, 0, 1, 0.55]])   # oblique projection to 3D
    return {w: Pm @ E[w] for w in range(8)}


def fig_16cell(height=520):
    C = _xpoly_coords()
    names = {0: "0", 7: "u", 1: "a", 6: "u⊕a", 2: "b", 5: "u⊕b", 3: "s", 4: "v"}
    fig = go.Figure()
    ex, ey, ez = [], [], []
    for x in range(8):
        for y in range(x + 1, 8):
            if (x ^ y) != 7:
                assert rc.two_sheet_d2(x, y, 4) == 2
                ex += [C[x][0], C[y][0], None]
                ey += [C[x][1], C[y][1], None]
                ez += [C[x][2], C[y][2], None]
    fig.add_trace(go.Scatter3d(x=ex, y=ey, z=ez, mode="lines", line=dict(color="rgba(57,135,229,0.55)", width=3),
                               name="d*² = 2 (24 edges)", hoverinfo="skip"))
    ax_, ay_, az_ = [], [], []
    for x in (0, 1, 2, 3):
        y = x ^ 7
        ax_ += [C[x][0], C[y][0], None]
        ay_ += [C[x][1], C[y][1], None]
        az_ += [C[x][2], C[y][2], None]
    fig.add_trace(go.Scatter3d(x=ax_, y=ay_, z=az_, mode="lines", line=dict(color=YELLOW, width=2, dash="dash"),
                               name="d*² = 4: complement = antipode", hoverinfo="skip"))
    fig.add_trace(go.Scatter3d(x=[C[w][0] for w in range(8)], y=[C[w][1] for w in range(8)], z=[C[w][2] for w in range(8)],
                               mode="markers+text", text=[names[w] for w in range(8)], textposition="top center",
                               textfont=dict(color=INK, family=MONO, size=14), marker=dict(size=8, color=INK), showlegend=False,
                               hoverinfo="text"))
    ax = dict(visible=False, showbackground=False)
    fig.update_layout(height=height, title="Two-sheet distance at width 4: the carrier is the regular 16-cell",
                      scene=dict(xaxis=ax, yaxis=ax, zaxis=ax, aspectmode="data", camera=dict(eye=dict(x=0.85, y=0.95, z=0.55))),
                      margin=dict(l=0, r=0, t=78, b=0), legend=dict(orientation="h", y=0.02, x=0))
    _subtitle(fig, "projection of the 4-cross-polytope (a picture of the metric (7.5), not a ring order) · a = eR, b = eL, s = a ⊕ b, v = u ⊕ s")
    return fig


def fig_octahedron(height=500):
    C = _xpoly_coords()
    seq = [rc.psi_oct(*z) for z in rc.sign_registers()]
    names = {1: "a", 6: "u⊕a", 2: "b", 5: "u⊕b", 3: "s", 4: "v"}
    six = [1, 2, 3, 4, 5, 6]
    fig = go.Figure()
    ex, ey, ez = [], [], []
    for x in six:
        for y in six:
            if x < y and (x ^ y) != 7:
                ex += [C[x][0], C[y][0], None]
                ey += [C[x][1], C[y][1], None]
                ez += [C[x][2], C[y][2], None]
    fig.add_trace(go.Scatter3d(x=ex, y=ey, z=ez, mode="lines", line=dict(color=BORDER, width=3), hoverinfo="skip",
                               showlegend=False))
    path = seq + [seq[0]]
    fig.add_trace(go.Scatter3d(x=[C[w][0] for w in path], y=[C[w][1] for w in path], z=[C[w][2] for w in path],
                               mode="lines+markers+text", text=[names[w] for w in path[:-1]] + [""],
                               textfont=dict(color=INK, family=MONO), line=dict(color=YELLOW, width=7),
                               marker=dict(size=6, color=YELLOW), name="Ψ_oct: the sign's six-cycle"))
    ax = dict(visible=False, showbackground=False)
    fig.update_layout(height=height, title="The sign walks the octahedron: a Petrie hexagon of the 16-cell's vertex figure",
                      scene=dict(xaxis=ax, yaxis=ax, zaxis=ax, aspectmode="data", camera=dict(eye=dict(x=1.25, y=1.05, z=0.8))),
                      margin=dict(l=0, r=0, t=78, b=0), legend=dict(orientation="h", y=0.02, x=0))
    _subtitle(fig, "v → b⊕v → b → a⊕b → a → a⊕v → v · ticks t and t+3 are complementary (antipodes)")
    return fig


def fig_triangle_census(census, n=4, height=420):
    keys = sorted([k for k in census if isinstance(k, tuple)], key=lambda k: -census[k])
    labels = ["{%s}" % ", ".join(map(str, k)) for k in keys]
    vals = [census[k] for k in keys]
    acute = [k == (2, n - 1, n - 1) for k in keys]
    col = [MAGENTA if a else BLUE for a in acute]
    fig = go.Figure(go.Bar(x=labels, y=vals, marker=dict(color=col), text=["acute" if a else "right" for a in acute],
                           textposition="outside", textfont=dict(color=INK2),
                           hovertemplate="%{x}: %{y:,}<extra></extra>"))
    fig.add_trace(go.Bar(x=["collapsed"], y=[census["collapsed"]], marker=dict(color=MUTED), text=["flat"],
                         textposition="outside", textfont=dict(color=INK2), hovertemplate="collapsed: %{y:,}<extra></extra>"))
    fig.update_layout(height=height, showlegend=False, margin=dict(l=100),
                      title="Step triangles of the two-lap closure at width %d (squared side lengths)" % n,
                      yaxis=dict(title="ticks", tickformat=",", automargin=True))
    _subtitle(fig, "never obtuse · exactly one acute class {2, n−1, n−1} · counts identical at widths 4, 6, 8, 10")
    return fig


def fig_genesis(Dmax=10, px=620, height=700):
    srcs = [disk_png(D, "bits", "word", px, ss=2) for D in range(1, Dmax + 1)]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[None], y=[None], showlegend=False))
    fig.add_layout_image(dict(source=srcs[-1], xref="x", yref="y", x=-1, y=1, sizex=2, sizey=2, sizing="stretch", layer="below"))
    frames = []
    for D in range(1, Dmax + 1):
        img = dict(source=srcs[D - 1], xref="x", yref="y", x=-1, y=1, sizex=2, sizey=2, sizing="stretch", layer="below")
        frames.append(go.Frame(name=str(D), layout=dict(images=[img])))
    fig.frames = frames
    steps = [dict(method="animate", label=str(D), args=[[str(D)], dict(mode="immediate", frame=dict(duration=0, redraw=True),
                                                                        transition=dict(duration=0))]) for D in range(1, Dmax + 1)]
    fig.update_layout(height=height, title="Genesis: rings 1 to %d grow from one bit" % Dmax, margin=dict(l=10, r=10, t=86, b=70),
                      sliders=[dict(active=Dmax - 1, steps=steps, x=0.1, len=0.86, y=0,
                                    currentvalue=dict(prefix="rings nested: ", font=dict(color=INK)),
                                    font=dict(color=MUTED), bgcolor=PANEL2, bordercolor=BORDER, activebgcolor=AQUA)],
                      updatemenus=[dict(type="buttons", x=0.0, y=0, xanchor="left", yanchor="top", showactive=False,
                                        bgcolor=PANEL2, bordercolor=BORDER, font=dict(color=INK, size=13),
                                        buttons=[dict(label="▶ play", method="animate",
                                                      args=[[str(D) for D in range(1, Dmax + 1)],
                                                            dict(frame=dict(duration=650, redraw=True), mode="immediate",
                                                                 fromcurrent=False, transition=dict(duration=0))])])])
    _subtitle(fig, "one bit, one transformation, an exact inverse · ring L carries every L-bit word once, in native partner order · press play or drag the slider")
    _blank_axes(fig, lim=1.06)
    return fig
