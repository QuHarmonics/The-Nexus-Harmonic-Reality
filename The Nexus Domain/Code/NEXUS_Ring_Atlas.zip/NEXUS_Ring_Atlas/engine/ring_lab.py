"""NEXUS Ring Atlas - proof laboratory.  Depends on ring_core only (no graphics).

Dean A. Kulik, QuHarmonics Research Group, ORCID 0009-0003-3128-8828.
Every check returns: expected, actual, scope, ok.  The expectation table is sealed (SHA-256)
before any check runs.  A check is RUNS only when it executed and landed; a cited proof is STANDS.
"""
from __future__ import annotations

import json
import math
import random
import time
from collections import Counter
from fractions import Fraction

import numpy as np

import ring_core as rc

# ----------------------------------------------------------------------------------------
# The sealed expectation table (published values and derived predictions)
# ----------------------------------------------------------------------------------------
EXPECT = {
    "pi64_address": 2427008858123944441,
    "radial_language": {"10": 924, "11": 1827, "12": 3606, "13": 7122, "14": 14087, "15": 27819, "16": 55122},
    "radial_entropy_16": "14.951476",
    "depth_mean_16": "5461/16384",
    "ray_120": {"value": "0.333333333333", "angle": "0.277777777778"},
    "frame_losses_16": [0, 0, 0, 128, 192, 224, 240, 248, 254, 250, 246, 238, 222, 190, 126, 254],
    "comparator_energy_20": "0.9990",
    "centre_of_mass_20": {"reps": "0.333091", "partners": "0.666908"},
    "periods": {"R1": 6, "R2": 132, "R3": 43155322},
    "r3_vacuum": [21577661, 43155322],
    "r3_mean_kept": "6.919906",
    "r3_census": {"collapsed": 14325832, "real": 28829490, "right": 24685355, "acute": 4144135,
                  "pi_ray": 8287912},
    "nine_cell_census": {"18": 28, "6": 1, "2": 1},
    "port": {"seed": [4, 7], "lands": 5, "tick": 3, "null_D10": 10},
    "seam_profiles": {"right": "100111111111111111111111", "left": "000111111111111111111111"},
    "witness": "1 00 1^(D-5) 00 for D >= 13; control tau = 2/3 fails exactly at D = 2 mod 3",
}


def seal() -> str:
    return rc.sha256_text(json.dumps(EXPECT, sort_keys=True))


# ----------------------------------------------------------------------------------------
# Registry
# ----------------------------------------------------------------------------------------
REGISTRY = []


def check(cid, statement, source, chapter, long=False):
    def deco(fn):
        REGISTRY.append(dict(id=cid, statement=statement, source=source, chapter=chapter, fn=fn, long=long))
        return fn
    return deco


RESULTS = {}


def run(ids=None, chapter=None, include_long=True, verbose=False, reuse=True):
    """Run checks (by id list or chapter).  Results are cached by id; reuse=False forces a rerun."""
    out = []
    for t in REGISTRY:
        if ids is not None and t["id"] not in ids:
            continue
        if chapter is not None and t["chapter"] != chapter:
            continue
        if t["long"] and not include_long:
            out.append(dict(id=t["id"], statement=t["statement"], source=t["source"], chapter=t["chapter"],
                            scope="skipped (long run off)", expected="", actual="", ok=None, seconds=0.0))
            continue
        if reuse and t["id"] in RESULTS and RESULTS[t["id"]]["ok"] is not None:
            out.append(RESULTS[t["id"]])
            continue
        t0 = time.time()
        try:
            r = t["fn"]()
        except Exception as e:  # a failing check is reported, never hidden
            r = dict(scope="error", expected="", actual="%s: %s" % (type(e).__name__, e), ok=False)
        r.update(id=t["id"], statement=t["statement"], source=t["source"], chapter=t["chapter"],
                 seconds=round(time.time() - t0, 2))
        RESULTS[t["id"]] = r
        out.append(r)
        if verbose:
            print(r["id"], r["ok"], r["seconds"])
    return out


def status_of(r):
    if r["ok"] is None:
        return "SKIP"
    return "RUNS" if r["ok"] else "FAIL"


def R(scope, expected, actual, ok):
    return dict(scope=scope, expected=expected, actual=actual, ok=bool(ok))


# ----------------------------------------------------------------------------------------
# Chapter 1-3: genesis, partner, ring
# ----------------------------------------------------------------------------------------

@check("G-01", "On one bit the only fixed-point-free bijection is NOT; on two bits 24 of 256 maps are bijective, "
               "9 have no fixed symbol, and exactly one commutes with exchanging the two bits: the complement",
       "One Inverter; (2.1)", 1)
def _g01():
    one = [m for m in [(a, b) for a in (0, 1) for b in (0, 1)] if sorted(m) == [0, 1] and all(m[i] != i for i in (0, 1))]
    maps = [(a, b, c, d) for a in range(4) for b in range(4) for c in range(4) for d in range(4)]
    bij = [m for m in maps if sorted(m) == [0, 1, 2, 3]]
    der = [m for m in bij if all(m[i] != i for i in range(4))]
    sw = {0: 0, 1: 2, 2: 1, 3: 3}
    sym = [m for m in der if all(sw[m[i]] == m[sw[i]] for i in range(4))]
    actual = "1-bit: %s; 2-bit: %d bijective, %d no fixed symbol, symmetric %s" % (one, len(bij), len(der), sym)
    return R("all maps on 1 and 2 bits", "[(1, 0)]; 24; 9; [(3, 2, 1, 0)]", actual,
             one == [(1, 0)] and len(bij) == 24 and len(der) == 9 and sym == [(3, 2, 1, 0)])


@check("R-01", "P is an involution without fixed points; palindromes number 2^ceil(n/2); pairs 2^(n-1)",
       "(1.1)-(1.2)", 2)
def _r01():
    ok = True
    for n in range(1, 17):
        P = rc.partner_table(n)
        w = np.arange(1 << n)
        ok &= bool(np.all(P[P] == w)) and bool(np.all(P != w))
        ok &= int(rc.pal_table(n).sum()) == 1 << ((n + 1) // 2)
    return R("every word, n = 1-16", "P(P(x)) = x, P(x) != x", "holds" if ok else "violated", ok)


@check("R-02", "Facing law R[N-1-i] = P(R[i]); seam R[M-1] = u xor eR, R[M] = u xor eL at even n",
       "(1.3)-(1.4); Retained Continuation", 3)
def _r02():
    ok = True
    for n in range(2, 17):
        R_ = rc.ring(n)
        N = 1 << n
        M = N // 2
        P = rc.partner_table(n)
        ok &= bool(np.all(R_[N - 1 - np.arange(N)] == P[R_]))
        if n % 2 == 0 and n >= 4:
            r = n // 2
            u = N - 1
            ok &= int(R_[M - 1]) == u ^ (1 << (r - 1)) and int(R_[M]) == u ^ (1 << r)
    return R("every slot, n = 2-16", "facing law and seam", "holds" if ok else "violated", ok)


@check("R-03", "The seam word is 1^(floor(n/2)-1) 0 1^(ceil(n/2)) and nests: S(n+2) = 1 S(n) 1",
       "Mapping the Nested Partner Ring §5; Two Laps §135", 3)
def _r03():
    ok = True
    for n in range(2, 17):
        ok &= int(rc.ring(n)[1 << (n - 1)]) == rc.seam_word(n)
        if n + 2 <= 16:
            ok &= rc.seam_word(n + 2) == int("1" + rc.bits(rc.seam_word(n), n) + "1", 2)
    return R("n = 2-16", "R_n[M] = seam word; 1·S·1", "holds" if ok else "violated", ok)


@check("R-04", "Four providers: x = b m c is a representative iff (b,c) = (0,1), or (0,0) with m <= J(m), "
               "or (1,1) with m < J(m); the frame 10 admits nothing", "Where Yes and No Become Maybe, Route 3", 7)
def _r04():
    ok = True
    for n in range(3, 15):
        P = rc.partner_table(n)
        x = np.arange(1 << n)
        b = (x >> (n - 1)) & 1
        c = x & 1
        m = (x >> 1) & ((1 << (n - 2)) - 1)
        jm = rc.rev_vec(m, n - 2)
        pred = ((b == 0) & (c == 1)) | ((b == 0) & (c == 0) & (m <= jm)) | ((b == 1) & (c == 1) & (m < jm))
        ok &= bool(np.array_equal(pred, x < P))
    return R("every word, n = 3-14", "frame law", "holds" if ok else "violated", ok)


@check("R-05", "Tape twist: T[L N - 1 - p] = T[p] xor pal(word holding p)", "Where Yes and No Become Maybe, Route 2", 3)
def _r05():
    ok = True
    for n in range(1, 14):
        tb = rc.tape_bits(n)
        N = 1 << n
        pal = rc.pal_table(n)[rc.ring(n)].astype(np.uint8)
        p = np.arange(n * N)
        ok &= bool(np.array_equal(tb[n * N - 1 - p], tb[p] ^ pal[p // n]))
    return R("every slice, n = 1-13", "palindrome on the tape except on palindromic words", "holds" if ok else "violated", ok)


@check("R-06", "Every ring is half light (L 2^(L-1) ones); the partner half carries 2^ceil(L/2) more ones "
               "than the representative half for L >= 2", "Where Yes and No Become Maybe, Route 8", 3)
def _r06():
    ok = True
    diffs = []
    for n in range(1, 15):
        tb = rc.tape_bits(n)
        N = 1 << n
        ones = int(tb.sum())
        d = int(tb[n * N // 2:].sum()) - int(tb[:n * N // 2].sum())
        diffs.append(d)
        ok &= ones == n * (N // 2)
        if n >= 2:
            ok &= d == 1 << ((n + 1) // 2)
    return R("n = 1-14 (n = 1 differs by %d: owner the 1-bit ring)" % diffs[0], "L·2^(L-1); 2^ceil(L/2)",
             "holds; L=1 imbalance %d" % diffs[0], ok and diffs[0] == 1)


@check("R-07", "Merge accounting: sum over words of wt(x xor P(x)) = floor(L/2) 2^L + L 2^ceil(L/2)",
       "Where Yes and No Become Maybe, Route 8", 3)
def _r07():
    ok = all(rc.merge_grey(n) == (n // 2) * 2 ** n + n * 2 ** ((n + 1) // 2) for n in range(1, 15))
    return R("n = 1-14", "closed form", "holds" if ok else "violated", ok)


# ----------------------------------------------------------------------------------------
# Chapter 4: address
# ----------------------------------------------------------------------------------------

@check("A-01", "Exact address without enumeration equals the ring table; unrank inverts it",
       "(1.6)-(1.7); Only Addressable", 4)
def _a01():
    ok = True
    rng = random.Random(64)
    for n in range(1, 13):
        A = rc.address_table(n)
        words = range(1 << n) if n <= 9 else rng.sample(range(1 << n), 200)
        for x in words:
            ok &= rc.address(x, n) == int(A[x])
        for a in rng.sample(range(1 << n), min(1 << n, 30)):
            ok &= rc.word_at(a, n) == int(rc.ring(n)[a])
    for L, k in ((64, 3), (128, 2), (256, 1)):
        for _ in range(k):
            a = rng.randrange(1 << L)
            ok &= rc.address(rc.word_at(a, L), L) == a
    return R("rank: every word n = 1-9, 200 words at n = 10-12; 30 unranks per width; round trips at 64, 128, 256 bits",
             "rank = table; unrank∘rank = id", "holds" if ok else "violated", ok)


@check("A-02", "The first 64 bits of pi after the binary point sit at address 2,427,008,858,123,944,441 of the 64-bit ring",
       "Against Its Own Reverse (sealed); (1.7)", 4)
def _a02():
    x = rc.pi_fraction_bits(64)
    a = rc.address(x, 64)
    return R("one 64-bit word", "{:,}".format(EXPECT["pi64_address"]), "{:,} (word 0x{:016X})".format(a, x),
             a == EXPECT["pi64_address"])


@check("A-03", "On ring addresses the comparator is one address bit with palindromic zeros and a seam flip; "
               "its energy on the top bit is (N - 2^ceil(n/2) - 4)^2 / (N (N - 2^ceil(n/2)))", "(1.9)", 4)
def _a03():
    ok = True
    for n in range(2, 13):
        R_ = rc.ring(n)
        c = np.array([rc.comparator(int(x), n) for x in R_])
        ok &= bool(np.array_equal(c, rc.comparator_ring_law(n)))
    n = 20
    N = 1 << n
    law = rc.comparator_ring_law(n)
    chi = np.where(np.arange(N) < N // 2, 1, -1)
    e = float((law @ chi) ** 2 / ((law @ law) * N))
    pred = (N - 2 ** ((n + 1) // 2) - 4) ** 2 / (N * (N - 2 ** ((n + 1) // 2)))
    return R("law: every slot n = 2-12; energy at n = 20", "%.4f" % pred, "%.6f" % e, ok and abs(e - pred) < 1e-12)


@check("A-04", "Borrow chain: the final borrow of x - J(x) with cell Maj(not a, b, beta) is [x < J(x)]", "(1.8)", 4)
def _a04():
    ok = True
    for n in range(1, 12):
        for x in range(1 << n):
            j = rc.rev(x, n)
            ok &= rc.borrow_chain(x, j, n)[-1][4] == int(x < j)
    return R("every word, n = 1-11", "[x < J(x)]", "holds" if ok else "violated", ok)


# ----------------------------------------------------------------------------------------
# Chapter 5-7: sphere, folded square, continuation
# ----------------------------------------------------------------------------------------

@check("S-01", "Pi-Ray: wt(x) + wt(u xor x) = n, and |x|^2 + |u - x|^2 = n (right angle at x)", "(7.1)", 5)
def _s01():
    ok = True
    for n in range(1, 15):
        w = np.arange(1 << n)
        a = rc.popcount_vec(w)
        b = rc.popcount_vec(w ^ ((1 << n) - 1))
        ok &= bool(np.all(a + b == n))
    return R("every word, n = 1-14", "n", "holds" if ok else "violated", ok)


@check("S-02", "Partner acts on the sphere as a reflection (-phi, z) off the palindromes and a half-turn (-phi, -z) on them",
       "(1.10)", 5)
def _s02():
    ok = True
    for n in range(2, 13):
        s = rc.sphere_coords(n)
        N = 1 << n
        A = rc.address_table(n)
        P = rc.partner_table(n)
        pal = rc.pal_table(n)
        for a in range(N):
            w = int(s["words"][a])
            b = int(A[P[w]])
            ok &= abs(((s["phi"][a] + s["phi"][b]) % (2 * np.pi))) < 1e-9 or abs(((s["phi"][a] + s["phi"][b]) % (2 * np.pi)) - 2 * np.pi) < 1e-9
            ok &= abs(s["z"][b] - (-s["z"][a] if pal[w] else s["z"][a])) < 1e-12
    return R("every slot, n = 2-12", "(−φ, ±z)", "holds" if ok else "violated", ok)


@check("F-01", "Representatives lie on u = t - t^2/2 within 2^(-L/2+1); what the parabola leaves is the tent: "
               "the column count is Q(f) = f 2^h - f^2/2 + min(f, 2^h - f)/2", "(1.11); Routes 5 and 7", 6)
def _f01():
    ok = True
    worst = []
    for n in range(10, 21):
        t, u, res = rc.parabola_residual(n)
        m = float(np.abs(res).max())
        worst.append(m * 2 ** (n / 2 - 1))
        ok &= m < 2 ** (-n / 2 + 1)
    for h in range(2, 9):
        n = 2 * h
        P = rc.partner_table(n)
        w = np.arange(1 << n)
        reps = w[w < P]
        cnt = np.bincount(reps >> h, minlength=1 << h)
        cum = np.concatenate([[0], np.cumsum(cnt)])
        ok &= all(cum[f] == rc.tent_Q(f, h) for f in range(1 << h))
    return R("parabola n = 10-20; tent identity h = 2-8", "max |res|·2^(L/2-1) < 1", "max %.3f" % max(worst), ok)


@check("F-02", "Centre of mass: representatives 1/3, partners 2/3 (width 20: 0.333091, 0.666908)",
       "Where Yes and No Become Maybe, Route 5", 6)
def _f02():
    n = 20
    N = 1 << n
    P = rc.partner_table(n)
    w = np.arange(N)
    rep = w < P
    cr = float(w[rep].mean() / N)
    cp = float(w[~rep].mean() / N)
    return R("width 20", "0.333091 / 0.666908", "%.6f / %.6f" % (cr, cp),
             "%.6f" % cr == EXPECT["centre_of_mass_20"]["reps"] and "%.6f" % cp == EXPECT["centre_of_mass_20"]["partners"])


@check("C-01", "Continuation depth: Pr(depth >= t) = 4^-t, roots 3·2^(L-3), mean (1 - 4^-floor((L-1)/2))/3; "
               "width 16 mean 5461/16384", "(1.12); Route 6", 7)
def _c01():
    ok = True
    mean16 = None
    for n in range(3, 17):
        P = rc.partner_table(n)
        reps = [x for x in range(1 << n) if x < P[x]]
        ds = [rc.depth(x, n)[0] for x in reps]
        M = len(reps)
        c = Counter(ds)
        K = (n - 1) // 2
        ok &= all(sum(v for d, v in c.items() if d >= t) * 4 ** t == M for t in range(1, K + 1))
        ok &= c[0] == 3 * 2 ** (n - 3)
        mean = Fraction(sum(ds), M)
        ok &= mean == Fraction(1 - Fraction(1, 4 ** K), 3)
        if n == 16:
            mean16 = mean
    return R("every representative, n = 3-16", "5461/16384", str(mean16), ok and str(mean16) == EXPECT["depth_mean_16"])


@check("C-02", "Closed-form codec: every representative is F^k(root); the record (root, k) round-trips", "Route 6", 7)
def _c02():
    ok = True
    for n in range(1, 13):
        P = rc.partner_table(n)
        for x in range(1 << n):
            if x < P[x]:
                d, root, L = rc.depth(x, n)
                ok &= rc.F_power(root, L, d) == (x, n)
    return R("every representative, n = 1-12", "round trip", "holds" if ok else "violated", ok)


@check("C-03", "The complement ray of 00 compiles to value 1/3 at angle 5/18; the 01 ray is the seam word",
       "Route 6, Route 9", 7)
def _c03():
    a, w = 0, 2
    for _ in range(59):
        a, w = rc.F_step(a, w)
    v = "%.12f" % (a / 2 ** w)
    ang = "%.12f" % float(Fraction(rc.address(a, w), 2 ** w))
    b, w2 = 1, 2
    for _ in range(59):
        b, w2 = rc.F_step(b, w2)
    seam_ok = b == rc.seam_word(w2) and rc.address(b, w2) == 1 << (w2 - 1)
    return R("width 120 (exact)", "value 0.333333333333, angle 0.277777777778; 01 ray in slot M",
             "value %s, angle %s; 01 ray slot M: %s" % (v, ang, seam_ok),
             v == EXPECT["ray_120"]["value"] and ang == EXPECT["ray_120"]["angle"] and seam_ok)


# ----------------------------------------------------------------------------------------
# Chapter 8: readers of the fixed mold
# ----------------------------------------------------------------------------------------

@check("D-01", "Frame law: the loss of every L-bit window frame at every offset", "Mapping the Nested Partner Ring §4", 8)
def _d01():
    ok = True
    for L in range(4, 17):
        for s in range(L):
            ok &= rc.frame_loss(L, s) == rc.frame_law(L, s)
    l16 = [rc.frame_loss(16, s) for s in range(16)]
    return R("every cell L = 4-16", str(EXPECT["frame_losses_16"]), str(l16), ok and l16 == EXPECT["frame_losses_16"])


@check("D-02", "Radial language: distinct profiles R_10..R_16 and the angular entropy at 16",
       "Where Yes and No Become Maybe, Route 10", 8)
def _d02():
    got = {}
    H16 = None
    for D in range(10, 17):
        r, H = rc.radial_language(D)
        got[str(D)] = r
        if D == 16:
            H16 = "%.6f" % H
    return R("exact merged grid, D = 10-16", "%s; H16 = %s" % (EXPECT["radial_language"], EXPECT["radial_entropy_16"]),
             "%s; H16 = %s" % (got, H16), got == EXPECT["radial_language"] and H16 == EXPECT["radial_entropy_16"])


@check("D-03", "One angle for every depth: u_D reads 1 00 1^(D-5) 00; the control tau = 2/3 fails exactly at D = 2 (mod 3)",
       "Mapping the Nested Partner Ring, Theorem 2", 8)
def _d03():
    bad = []
    for D in range(13, 41):
        u, p, t = rc.witness_angle(D)
        if rc.profile(u, D) != rc.witness_profile(D):
            bad.append(D)
        uc, _, _ = rc.witness_angle(D, Fraction(2, 3))
        if (rc.profile(uc, D) == rc.witness_profile(D)) != (D % 3 != 2):
            bad.append(("control", D))
    return R("D = 13-40, exact arithmetic (the source runs to 400)", "no failures", "failures %s" % bad, not bad)


@check("D-04", "Two-sided seam: just right reads 1,0,0,1,1,1,...; just left reads 0,0,0,1,1,1,...",
       "Where Yes and No Become Maybe, Route 9", 8)
def _d04():
    e = Fraction(1, 2 ** 40)
    r = rc.profile(Fraction(1, 2) + e, 24)
    l_ = rc.profile(Fraction(1, 2) - e, 24)
    return R("rings 1-24", "%s / %s" % (EXPECT["seam_profiles"]["right"], EXPECT["seam_profiles"]["left"]),
             "%s / %s" % (r, l_), r == EXPECT["seam_profiles"]["right"] and l_ == EXPECT["seam_profiles"]["left"])


@check("D-05", "The front half of the word under the radial reader reads the digits of tau(u) = 1 - sqrt(1 - 2u)",
       "Where Yes and No Become Maybe, Route 7 (sealed threshold 95%)", 8)
def _d05():
    rng = random.Random(2026)
    agree = total = 0
    gaps = []
    B = 256
    while total < 240:
        k = rng.randrange(1, 1 << (B - 1))          # u = k / 2^B < 1/2
        u = Fraction(k, 1 << B)
        L = rng.randrange(24, 65)
        z = u * (1 << L)
        a = z.numerator // z.denominator
        fr = (z - a) * L
        j = fr.numerator // fr.denominator
        if j >= L // 2:
            continue
        word = rc.word_at(a, L)
        bit = (word >> (L - 1 - j)) & 1
        K = j + 1
        S = (1 << B) - 2 * k                        # (1 - 2u) 2^B
        sq = math.isqrt(S << (2 * K + B))            # floor(sqrt(1-2u) 2^(K+B))
        exact = sq * sq == (S << (2 * K + B))
        digit = (((1 << (K + B)) - sq - (0 if exact else 1)) >> B) & 1
        total += 1
        if bit == digit:
            agree += 1
        else:
            gaps.append(L // 2 - j)
    where = ("; every miss sits within %d slices of the word centre (the tent term, order 2^(-L/2))" % max(gaps)) if gaps else ""
    return R("%d sampled front-half readings, L = 24-64" % total, ">= 95%", "%d / %d agree%s" % (agree, total, where),
             agree >= 0.95 * total)


# ----------------------------------------------------------------------------------------
# Chapter 9: Moebius bridge
# ----------------------------------------------------------------------------------------

@check("M-01", "Boolean Moebius bridge MD = SA and lossless rebuild X = M S^T M D", "(1.13); Bicomplex Difference Calculus, Thm 3.4", 9)
def _m01():
    ok = True
    for n in range(1, 15):
        r = rc.mobius_check(n)
        ok &= r["ok_bridge"] and r["ok_rebuild"] and r["top_row_zero"]
    return R("full state matrix, n = 1-14", "MD = SA; X rebuilt", "holds" if ok else "violated", ok)


# ----------------------------------------------------------------------------------------
# Chapter 10: clock
# ----------------------------------------------------------------------------------------

@check("K-01", "tau^n = C, tau^2n = I, and orbit lengths are exactly {2n/d : d odd, d | n}", "(2.1), (2.3)", 10)
def _k01():
    ok = True
    for n in range(1, 15):
        U = rc.umask(n)
        for x in range(1 << n):
            y = x
            for _ in range(n):
                y = rc.tau(y, n)
            ok &= y == x ^ U
        ok &= set(rc.orbit_census(n)) == rc.orbit_law(n)
    return R("every word, n = 1-14", "laws", "hold" if ok else "violated", ok)


@check("K-02", "Inverter parity: rotl1 xor w is conjugate to rotation (a latch) when wt(w) is even and to tau (a clock) when odd",
       "(2.2)", 10)
def _k02():
    ok = True
    for n in range(2, 9):
        U = rc.umask(n)
        rot = rc.orbit_census(n, lambda z: ((z << 1) & U) | (z >> (n - 1)))
        tc = rc.orbit_census(n)
        for w in range(1 << n):
            c = rc.orbit_census(n, lambda z, w=w: (((z << 1) & U) | (z >> (n - 1))) ^ w)
            ok &= c == (rot if rc.wt(w) % 2 == 0 else tc)
    return R("every mask, n = 2-8", "cycle type of rotl1 or of tau", "holds" if ok else "violated", ok)


@check("K-03", "Locks: tau^s(x) = C(x) has 2^s solutions when n/s is odd and none when it is even", "(2.3)", 10)
def _k03():
    ok = True
    for n in range(1, 13):
        for s in range(1, n + 1):
            if n % s == 0:
                k = len(rc.lock_words(n, s))
                ok &= k == (2 ** s if (n // s) % 2 else 0)
    return R("n = 1-12, every divisor s", "2^s or 0", "holds" if ok else "violated", ok)


@check("K-04", "Center reader at even n: y_t = d_(h-1-t) xor [t = h] and the n readings XOR to 1", "(2.4)", 10)
def _k04():
    ok = True
    for n in range(2, 15, 2):
        h = n // 2
        for x in range(1 << n):
            xs = x
            acc = 0
            for t in range(n):
                y = rc.center_reader(xs, n)
                acc ^= y
                j = (h - 1 - t) % n
                dj = ((x >> j) & 1) ^ ((x >> ((j + 1) % n)) & 1)
                ok &= y == dj ^ (1 if t == h else 0)
                xs = rc.tau(xs, n)
            ok &= acc == 1
    return R("every word, even n = 2-14 (odd widths: the innermost pair is not adjacent)", "identity; XOR = 1",
             "holds" if ok else "violated", ok)


@check("K-05", "In spin coordinates tau is the negacyclic shift; its eigenvalues are the n roots of lambda^n = -1, "
               "so one tick turns the fundamental mode by pi/n", "One Inverter; this notebook (spin form)", 10)
def _k05():
    ok = all(rc.eigenangles(n) == [float(k) for k in range(1, n + 1, 2)] for n in range(1, 17))
    orb = rc.tau_orbit(0, 9)
    z, lam = rc.mode_projection(orb, 9, 0)
    rot = np.angle(z[1:] / z[:-1])
    ok &= bool(np.allclose(rot, np.pi / 9))
    return R("n = 1-16; the zero point's lap at n = 9", "angles (2k+1)π/n; 20° per tick at n = 9",
             "%.6f° per tick" % float(np.degrees(rot.mean())), ok)


@check("K-06", "The nine-cell clock: 28 laps of 18 ticks, one bare sign (6), one flip pair (2); the bare sign sits "
               "inside a larger lap exactly at n = 3 x odd", "this notebook; One Inverter (orbit law)", 10)
def _k06():
    c9 = {str(k): v for k, v in sorted(rc.orbit_census(9).items(), reverse=True)}
    widths = [n for n in range(1, 16) if 6 in rc.orbit_census(n)]
    return R("n = 9 census; n = 1-15 search", "%s; [3, 9, 15]" % EXPECT["nine_cell_census"], "%s; %s" % (c9, widths),
             c9 == EXPECT["nine_cell_census"] and widths == [3, 9, 15])


@check("K-07", "The clock flips exactly one bit per tick: |delta wt| = 1 on every tick, weight parity alternates, "
               "and the net change of latitude over a lap is zero", "(2.1); this notebook", 10)
def _k07():
    ok = True
    for n in range(1, 13):
        for x0 in range(1 << n):
            x, net = x0, 0
            for _ in range(2 * n):
                y = rc.tau(x, n)
                dw = rc.wt(y) - rc.wt(x)
                ok &= abs(dw) == 1
                net += dw
                x = y
            ok &= net == 0 and x == x0
    return R("every word, n = 1-12, one full lap", "|Δwt| = 1; net 0", "holds" if ok else "violated", ok)


# ----------------------------------------------------------------------------------------
# Chapter 11: reader-field machine
# ----------------------------------------------------------------------------------------

@check("X-01", "The step and its inverse compose to the identity on populated fields", "(3.1)-(3.2)", 11)
def _x01():
    rng = random.Random(7)
    ok = True
    for n in range(4, 9):
        N = 1 << n
        for _ in range(1000):
            D = {q: v for q in range(N) for v in [rng.randrange(N)] if v}
            p, w = rng.randrange(N), rng.randrange(N)
            D0 = dict(D)
            p2, w2, _, _ = rc.step(p, w, D, n)
            p3, w3 = rc.unstep(p2, w2, D, n)
            ok &= (p3, w3) == (p, w) and D == D0
    return R("5,000 random populated states, n = 4-8", "identity", "holds" if ok else "violated", ok)


@check("X-02", "Class counts: R1 = 2, R2 = 2^(n/2+1) - 2 or 2^((n+1)/2) - 2, R3 = 2^n - 2^floor((n+2)/2); "
               "R1 u R2 = {w : P(w) = C(w)}", "(4.1)", 11)
def _x02():
    ok = True
    for n in range(2, 17):
        U = rc.umask(n)
        c = Counter(rc.carry_class(w, n) for w in range(1 << n))
        ok &= (c[1], c[2], c[3]) == rc.class_counts_formula(n)
        P = rc.partner_table(n)
        ok &= all((rc.carry_class(w, n) < 3) == (int(P[w]) == w ^ U) for w in range(1 << n))
    return R("every carry, n = 2-16", "formula; diagonal identity", "holds" if ok else "violated", ok)


@check("X-03", "From an empty field every R1 carry returns in 6 ticks and every R2 carry in 132, at every width",
       "(4.2)", 11)
def _x03():
    ok = True
    for n in range(4, 11):
        U = rc.umask(n)
        ok &= all(rc.period_from_empty(n, w) == 6 for w in (0, U))
        ok &= all(rc.period_from_empty(n, w) == 132 for w in range(1 << n) if rc.carry_class(w, n) == 2)
    return R("every R1 and R2 carry, n = 4-10", "6; 132", "holds" if ok else "violated", ok)


@check("X-04", "The two-lap closure R3: period 43,155,322 with exactly two empty fields (21,577,661 and the return); "
               "mean kept field 6.919906", "(4.2), (4.4), §4.6", 11, long=True)
def _x04():
    r = _r3_cache()
    return R("one full pass, eight-word carrier (seed eR)", "43,155,322; [21577661, 43155322]; 6.919906",
             "{:,}; {}; {:.6f}".format(r["period"], r["vacuum"], r["mean_kept"]),
             r["period"] == 43155322 and r["vacuum"] == EXPECT["r3_vacuum"] and "%.6f" % r["mean_kept"] == EXPECT["r3_mean_kept"])


@check("X-05", "Half lap: the second lap is the first lap read through G (positions A0 then xor u, carries A0)",
       "(4.3)-(4.4)", 11, long=True)
def _x05():
    m = rc.half_lap_check()
    return R("all 21,577,661 tick pairs", "0 mismatches", "%d mismatches" % m, m == 0)


@check("X-06", "The bare sign walks the three-stage Johnson counter; every step is collapsed; tick 3 is the start moved by u",
       "(4.5)-(4.6)", 11)
def _x06():
    rows = []
    rc.run_carrier(0, 6, observe=lambda t, p, w, d, x, D: rows.append((p, w, d, x)))
    Z = [(int(p != 0), int((p ^ w) != 0), int((p ^ w ^ d) != 0)) for p, w, d, x in rows]
    collapsed = all(rc.step_triangle(d, w) == "collapsed" for p, w, d, x in rows)
    p3, w3, D3 = rc.run_carrier(0, 3)
    return R("R1 from carry 0", "Johnson walk; collapsed; tick 3 = (u, 0, empty)",
             "%s; collapsed %s; tick 3 = (%d, %d, %d)" % (Z, collapsed, p3, w3, D3),
             Z == rc.JOHNSON and collapsed and (p3, w3, D3) == (4, 0, 0))


@check("X-07", "Memory is the reader's own past: overwrite (3.7) and revisit (3.8) on every tick of R1 and R2 runs; "
               "acceleration alpha = d_t xor A(d_t+1) on 200,000 ticks of R3", "(3.7), (3.8), (3.10)", 11)
def _x07():
    ok = True
    for n in (4, 6, 8):
        U = rc.umask(n)
        for w0 in [0, U] + [w for w in range(1 << n) if rc.carry_class(w, n) == 2][:8]:
            rows, _ = rc.run_reader(n, 0, w0, rc.CLASS_PERIOD[rc.carry_class(w0, n)])
            last = {}
            for r in rows:
                sig = rc.partner(r["x"], n) ^ r["x"] ^ U
                ok &= (r["d"] ^ r["w_next"]) == (r["w"] ^ U ^ sig)
                if r["p"] in last:
                    wr, sr = last[r["p"]]
                    ok &= r["w_next"] == r["w"] ^ wr ^ sig ^ sr
                last[r["p"]] = (r["w"], sig)
    A8 = [x ^ 7 if ((x ^ (x >> 1)) & 1) else x for x in range(8)]
    W, Dd = [], []
    rc.run_carrier(1, 200002, observe=lambda t, p, w, d, x, D: (W.append(w), Dd.append(d)))
    bad = sum(1 for t in range(200000) if (W[t] ^ W[t + 2]) != (Dd[t] ^ A8[Dd[t + 1]]))
    return R("R1/R2 full periods at n = 4, 6, 8; 200,000 R3 ticks", "0 errors", "alpha errors %d" % bad, ok and bad == 0)


@check("X-08", "Event log: Q_T = I + S + S^2 is invertible iff 3 does not divide T; the tape rebuilds the carries "
               "(with one seed word when 3 | T); both light seeds emit the same blank tape", "(4.7)-(4.11)", 11)
def _x08():
    ok = all(rc.q_invertible(T) == (T % 3 != 0) for T in range(1, 400))
    for n in (4, 6, 8):
        U = rc.umask(n)
        for w0 in [0, U] + [w for w in range(1 << n) if rc.carry_class(w, n) == 2][:6]:
            rows, _ = rc.run_reader(n, 0, w0, rc.CLASS_PERIOD[rc.carry_class(w0, n)])
            W = [r["w"] for r in rows]
            ok &= rc.rebuild_from_tape(rc.switch_tape(W), seed=w0, n=n) == W
            ps, _ = rc.rebuild_route(W, 0, n)
            ok &= ps[:-1] == [r["p"] for r in rows]
    t0 = rc.switch_tape([r["w"] for r in rc.run_reader(6, 0, 0, 6)[0]])
    tU = rc.switch_tape([r["w"] for r in rc.run_reader(6, 0, 63, 6)[0]])
    ok &= t0 == tU == [0] * 6
    rng = random.Random(5)
    for T in (4, 5, 7, 8, 10, 11, 100, 101, 1000, 1001):
        W = [rng.randrange(256) for _ in range(T)]
        ok &= rc.rebuild_from_tape(rc.switch_tape(W)) == W
    return R("T = 1-399; R1/R2 replay at n = 4, 6, 8; random tapes", "laws", "hold" if ok else "violated", ok)


@check("X-09", "The two-lap closure rebuilds from its switch tape alone (T = 1 mod 3): the closed-form inverse recovers "
               "w_0 and w_1 from the tape, and w_t+2 = q_t xor w_t xor w_t+1 carries the rest", "(4.9)-(4.10), T08a", 11, long=True)
def _x09():
    T = 43155322
    W = bytearray(T)
    p, w, D = 0, 1, 0
    P = rc.P8
    for t in range(T):
        W[t] = w
        sh = 3 * p
        d = (D >> sh) & 7
        x = d ^ w
        w2 = P[x]
        D ^= w2 << sh
        p ^= x
        w = w2
    Wn = np.frombuffer(bytes(W), dtype=np.uint8)
    q = Wn ^ np.roll(Wn, -1) ^ np.roll(Wn, -2)            # the event log
    keep = (np.arange(T) % 3) != 1
    w0 = int(np.bitwise_xor.reduce(q[keep]))
    w1 = int(np.bitwise_xor.reduce(np.roll(q, -1)[keep]))
    return R("all 43,155,322 carries (T mod 3 = %d)" % (T % 3), "w_0 = eR = %d, w_1 = P(eR) = %d" % (W[0], W[1]),
             "rebuilt w_0 = %d, w_1 = %d" % (w0, w1), T % 3 == 1 and w0 == W[0] and w1 == W[1])


_R3 = {}


def _r3_cache():
    if "r" not in _R3:
        _R3["r"] = rc.r3_full_pass()
    return _R3["r"]


# ----------------------------------------------------------------------------------------
# Chapter 12: collision and ports
# ----------------------------------------------------------------------------------------

@check("L-01", "Joint step: exact inverse; Law 3 charge Q' xor Q = ((m mod 2) xor sum l0 l1(x_i)) u; collision cell law",
       "(5.1), (5.2), (5.5)", 12)
def _l01():
    rng = random.Random(11)
    okq = okc = oki = True
    ticks = 0
    for trial in range(200):
        m = 1 + trial % 4
        j = rc.Joint([(rng.randrange(32), rng.randrange(32)) for _ in range(m)])
        if trial % 3 == 0:
            for i in range(1, m):
                j.p[i] = j.p[0]
        if trial % 2:
            j.D = [rng.randrange(32) for _ in range(32)]
        for _ in range(300):
            b = j.copy()
            Q0 = j.charge()
            x = j.step()
            ticks += 1
            kick = m & 1
            for v in x:
                kick ^= rc.l0(v) & rc.l1(v)
            okq &= (j.charge() ^ Q0) == (kick << 4)
            for q in range(32):
                cnt, acc = 0, 0
                for i in range(m):
                    if b.p[i] == q:
                        cnt += 1
                        acc ^= b.w[i] ^ (rc.P5(x[i]) ^ x[i] ^ 16)
                if cnt:
                    okc &= ((0 if cnt & 1 else b.D[q]) ^ (16 if cnt & 1 else 0) ^ acc) == j.D[q]
            c2 = j.copy()
            c2.back()
            oki &= c2.state() == b.state()
    return R("%s random ticks, 1-4 readers, shared starts and populated fields" % "{:,}".format(ticks),
             "inverse; charge law; cell law", "inverse %s · charge %s · cell %s" % (oki, okq, okc), oki and okq and okc)


@check("L-02", "Lamp alignment: aligned readers and cells stay aligned", "(5.7)-(5.8)", 12)
def _l02():
    rng = random.Random(13)
    ok = True
    for trial in range(80):
        m = 1 + trial % 4
        rd = []
        for _ in range(m):
            while True:
                a, b = rng.randrange(32), rng.randrange(32)
                if not rc.lamp_det(a, b):
                    rd.append((a, b))
                    break
        D = []
        for q in range(32):
            while True:
                v = rng.randrange(32)
                if not rc.lamp_det(q, v):
                    D.append(v)
                    break
        j = rc.Joint(rd, D)
        for _ in range(600):
            j.step()
            ok &= all(not rc.lamp_det(j.p[i], j.w[i]) for i in range(m))
            ok &= all(not rc.lamp_det(q, j.D[q]) for q in range(32))
    return R("80 aligned random states x 600 ticks, 1-4 readers", "preserved", "holds" if ok else "violated", ok)


@check("L-03", "Release separation: at every empty field a pair stands at separation r0 or r0 xor u", "(5.6)", 12)
def _l03():
    rng = random.Random(17)
    ok = True
    vac = 0
    for trial in range(120):
        j = rc.Joint([(rng.randrange(32), rng.randrange(32)) for _ in range(2)])
        s0 = j.p[0] ^ j.p[1]
        for _ in range(12000):
            j.step()
            if not any(j.D):
                vac += 1
                s = j.p[0] ^ j.p[1]
                ok &= s in (s0, s0 ^ 16)
    return R("120 random pairs x 12,000 ticks (%s empty-field ticks)" % "{:,}".format(vac), "r0 or r0 ⊕ u",
             "holds" if ok else "violated", ok and vac > 0)


@check("L-04", "Directed port C = (4,7): A lands on 5 at tick 3 and the three steps invert exactly; the symmetric "
               "third reader C = (0,0) writes D[10] = 10 at tick 3", "(5.9), §5.6; GPT seal f5375705", 12)
def _l04():
    rows, inv = rc.port_trace((4, 7), 3)
    rows0, _ = rc.port_trace((0, 0), 3)
    d = rc.derive_port(5, 3)
    return R("Shared Start A = (0, eR), B = (0, oR)", "A at 5 on tick 3; inverse exact; D[10] = 10; derived seed (4, 7)",
             "A at %d; inverse %s; D[10] = %d; derived seed %s" % (rows[-1]["A"][0], inv, rows0[-1]["D"][10], d["seed"]),
             rows[-1]["A"][0] == 5 and inv and rows0[-1]["D"][10] == 10 and tuple(d["seed"]) == (4, 7))


# ----------------------------------------------------------------------------------------
# Chapter 13: read models
# ----------------------------------------------------------------------------------------

@check("V-01", "Step triangles of the two-lap closure: never obtuse, one acute class {2, n-1, n-1}, counts identical at "
               "widths 4, 6, 8, 10", "(7.3)-(7.4), T06", 13, long=True)
def _v01():
    r = _r3_cache()
    ok = True
    ref = None
    for n in (4, 6, 8, 10):
        c = rc.census_from_pairs(r["pairs"], n)
        acute_keys = [k for k in c if isinstance(k, tuple) and k == (2, n - 1, n - 1)]
        sig = (c["collapsed"], c["real"], c["right"], c["acute"], c.get((1, n - 1, n), 0))
        ok &= sig == (14325832, 28829490, 24685355, 4144135, 8287912) and len(acute_keys) == 1
        ref = sig
    return R("all 43,155,322 ticks", "flat 14,325,832 · real 28,829,490 · right 24,685,355 · acute 4,144,135 · Pi-Ray 8,287,912",
             "flat {:,} · real {:,} · right {:,} · acute {:,} · Pi-Ray {:,}".format(*ref), ok)


@check("V-02", "Two-sheet distance at width 4: non-antipodal d*^2 = 2, antipodal 4 (the regular 16-cell)", "(7.5)-(7.6)", 13)
def _v02():
    ok = all(rc.two_sheet_d2(x, y, 4) == (4 if (x ^ y) == 7 else 2) for x in range(8) for y in range(8) if x != y)
    return R("all 56 ordered pairs", "2 / 4", "holds" if ok else "violated", ok)


@check("V-03", "Psi_oct sends the sign's six-cycle onto the six words other than 0 and u; t and t+3 are complementary; "
               "consecutive and two-step pairs are non-antipodal (a Petrie hexagon)", "(7.7)-(7.8)", 13)
def _v03():
    v = [rc.psi_oct(*z) for z in rc.sign_registers()]
    ok = sorted(v) == [1, 2, 3, 4, 5, 6]
    ok &= all(v[t] ^ v[(t + 3) % 6] == 7 for t in range(6))
    ok &= all(v[t] ^ v[(t + 1) % 6] != 7 and v[t] ^ v[(t + 2) % 6] != 7 for t in range(6))
    return R("the bare sign", "v, b⊕v, b, a⊕b, a, a⊕v", str(v), ok and v == [4, 6, 2, 3, 1, 5])


# ----------------------------------------------------------------------------------------
# Legacy routing (sightings from earlier work, read through the ring)
# ----------------------------------------------------------------------------------------

def wheel_fraction(k: int):
    """Fraction of ordered triples on the k-symbol wheel {0..k-1} that form a real (non-flat) triangle."""
    c = 0
    for a in range(1, k):
        for b in range(1, k):
            for d in range(1, k):
                if a + b > d and a + d > b and b + d > a:
                    c += 1
    return Fraction(c, k ** 3)


@check("H-01", "Legacy sighting: H = pi/9 is the tick angle of the nine-cell clock and its lap is 18 ticks (period-18 bridge); "
               "the 260/729 anchor is the k = 9 value of a wheel fraction that crosses pi/9 and tends to 1/2",
       "this notebook; ZPHC gap map A3; Funnel Paper Vol. I §6.2", 10)
def _h01():
    lap = len(rc.tau_orbit(0, 9))
    f9 = wheel_fraction(9)
    f8 = wheel_fraction(8)
    f60 = wheel_fraction(60)
    ok = lap == 18 and f9 == Fraction(260, 729) and f8 < Fraction(math.floor(math.pi / 9 * 10 ** 6), 10 ** 6) < f9
    return R("lap at n = 9; wheel k = 8, 9, 60", "18; 260/729; crossing between k = 8 and 9; → 1/2",
             "%d; %s = %.4f; k=8 %.4f; k=60 %.4f" % (lap, f9, float(f9), float(f8), float(f60)), ok)


# ----------------------------------------------------------------------------------------
# Manifest, OPEN links, legacy routing, adapter readings
# ----------------------------------------------------------------------------------------

MANIFEST = [
    ("Partner: fixed-point-free involution", "(1.1)-(1.2)", "Only Addressable; Retained Continuation", "STANDS · RUNS", "R-01", "Ch 2 · word inspector"),
    ("Ring order, facing law, seam, center carrier", "(1.3)-(1.5)", "Only Addressable; Retained Continuation", "STANDS · RUNS", "R-02 R-03", "Ch 3 · ring explorer"),
    ("Tape twist, light balance, merge accounting", "Routes 2, 8", "Where Yes and No Become Maybe", "RUNS", "R-05 R-06 R-07", "Ch 3 · disks"),
    ("Address as a comparison; exact rank and unrank at any width", "(1.6)-(1.7)", "Against Its Own Reverse; Only Addressable", "STANDS · RUNS", "A-01 A-02", "Ch 4"),
    ("Borrow cell; the comparator is one address bit", "(1.8)-(1.9)", "Against Its Own Reverse", "STANDS · RUNS", "A-03 A-04", "Ch 4"),
    ("Sphere reading; Pi-Ray", "(1.10), (7.1)-(7.2)", "Against Its Own Reverse; The Retained Continuation Domain", "STANDS · RUNS", "S-01 S-02", "Ch 5"),
    ("Folded square; density line; parabola; tent; centres of mass", "(1.11)", "Where Yes and No Become Maybe", "RUNS", "F-01 F-02", "Ch 6"),
    ("Four providers; continuation depth; codec; attractors", "(1.12)", "Where Yes and No Become Maybe", "RUNS", "R-04 C-01 C-02 C-03", "Ch 7"),
    ("Radial reader; frame law; one angle for every depth; seam profiles; square-root front half; radial language",
     "§2, §4, §5", "Mapping the Nested Partner Ring; Where Yes and No Become Maybe", "RUNS", "D-01 D-02 D-03 D-04 D-05", "Ch 8 · the Ring Reader"),
    ("Boolean Möbius bridge MD = SA; lossless rebuild", "(1.13)", "Bicomplex Difference Calculus", "STANDS · RUNS", "M-01", "Ch 9"),
    ("One-inverter clock; inverter parity; orbits; locks; center reader", "(2.1)-(2.4)", "One Inverter", "STANDS · RUNS", "K-01 K-02 K-03 K-04", "Ch 10"),
    ("Spin form; the nine-cell rung; H = π/9 as the tick angle; one bit per tick", "spin form", "this notebook", "STANDS · RUNS",
     "K-05 K-06 K-07 H-01", "Ch 10 · clock explorer"),
    ("Step and exact inverse; carrier; carrier algebra", "(3.1)-(3.6)", "Retained Continuation; Exact Algebra", "STANDS · RUNS", "X-01", "Ch 11"),
    ("Memory is the reader's own past; acceleration; switch", "(3.7)-(3.11)", "Exact Algebra; The Retained Continuation Domain", "STANDS · RUNS", "X-07", "Ch 11"),
    ("Closure classes, counts, periods 6, 132, 43,155,322", "(4.1)-(4.2)", "Retained Continuation", "STANDS · RUNS", "X-02 X-03 X-04", "Ch 11"),
    ("Half lap; bare sign as a Johnson counter; property triangle", "(4.3)-(4.6)", "Exact Algebra; The Retained Continuation Domain", "STANDS · RUNS", "X-05 X-06", "Ch 11"),
    ("Event log: Q_T invertible iff 3 ∤ T; replay with one seed word", "(4.7)-(4.11)", "The Retained Continuation Domain", "STANDS · RUNS", "X-08 X-09", "Ch 11"),
    ("Joint step; collision parity; Law 3", "(5.1)-(5.5)", "Exact Algebra; The Retained Continuation Domain", "STANDS · RUNS", "L-01", "Ch 12"),
    ("Lamp alignment; release separation", "(5.6)-(5.8)", "The Retained Continuation Domain", "STANDS · RUNS", "L-02 L-03", "Ch 12"),
    ("Directed port: a write the reader cannot refuse", "(5.9), (6.1)", "The Retained Continuation Domain (GPT seal f5375705)", "RUNS", "L-04", "Ch 12 · port lab"),
    ("Step triangles; two-sheet distance; 16-cell; octahedron", "(7.3)-(7.8)", "The Retained Continuation Domain", "STANDS · RUNS", "V-01 V-02 V-03", "Ch 13"),
    ("Adapter readings: light, matter, mass, inertia, charge, spin", "§8", "The Retained Continuation Domain", "PULL", "", "Ch 15"),
]

OPEN_LINKS = [
    ("Route-change accounting", "the map from field writes and the acceleration they produce (3.9)-(3.10) to the edit count (3.13)"),
    ("Return depth from the boundary", "the first empty-field tick and its monodromy for Shared Start, read from the initial relative state without executing"),
    ("Chained deposits", "how far one directed write carries: the reachable set of a reader after several aimed writes, as a measured law"),
    ("The nine-cell rung", "what places a system on the clock of nine cells rather than three or twenty-seven"),
    ("The frame law above the middle offset", "the mechanism for h + 1 ≤ s ≤ L − 2 and the seam cells"),
    ("The radial language", "the growth rate of R_D and the limit of R_D / 2^D"),
    ("The lap selector", "which of the 15 short same-carrier pairings close on which lap"),
    ("Physical adapters", "the angular reading of the half-lap sign; the parity break on the weak-side reading"),
    ("Lock families", "entry into and switching between lock families of the clock"),
]

LEGACY = [
    ("H = π/9 (Mark1)", "the tick angle of the nine-cell one-inverter clock: its fundamental eigenmode turns 20° per tick", "STANDS", "K-05 H-01"),
    ("“Period-18 folding” (ZPHC gap map A3)", "the nine-cell lap: τ⁹ = C, τ¹⁸ = I; the 18 spokes of the 20° lattice are the 18 states of one lap", "STANDS", "K-06 H-01"),
    ("260/729 (Mark1 empirical anchor)", "→ the k = 9 value of the wheel triangle fraction, which crosses π/9 between k = 8 and 9 and tends to 1/2", "ELSEWHERE", "H-01"),
    ("H ≈ 0.35 as the setpoint of dH/dt = −k(H − 0.35)", "→ the adapter layer (a controller steering a reader); the domain ticks at π/9 and steers nothing", "ELSEWHERE", ""),
    ("ZPHC: a forced re-evaluation", "the directed port: a write at the address another reader must read next; the read cannot be refused", "RUNS", "L-04"),
    ("ZPHCR: “more returned than injected”", "→ capacity: the reachable set opens (A reaches word 5, outside the pair's confinement); the record is conserved by the exact inverse", "ELSEWHERE", "L-04"),
    ("SILR: drift ≈ 0", "the step is a bijection, so drift is exactly zero; the clock moves latitude by one per tick and nets zero per lap", "STANDS", "X-01 K-07"),
    ("GENLOCK: every clock leaks at one rate", "the one-inverter clock flips exactly one bit per tick at every width", "STANDS", "K-07"),
]

ADAPTER_READINGS = [
    ("Light", "R1: the twist with nothing kept; blank switch tape; collapsed steps"),
    ("Matter", "R3: the twist with memory, off the diagonal"),
    ("Mass", "the kept field k"),
    ("Inertia", "the move price 2k: the cost of moving while keeping one's record"),
    ("Acceleration", "α_t = w_t ⊕ w_t+2 (accounting map OPEN)"),
    ("Spin", "the half-lap sign; two laps to come home (angular adapter OPEN)"),
    ("Charge", "the lamp parities and the charge Q"),
    ("Action and reaction", "Law 3 (5.5), with the complement as the one exchanged bit"),
    ("Confinement", "the cross-shell term ℓ0ℓ1u; the 28-word confinement of the Shared Start pair"),
]
