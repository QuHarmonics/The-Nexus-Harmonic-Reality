"""NEXUS Ring Atlas - interactive explorers (ipywidgets).  Reads ring_core and ring_viz.

Dean A. Kulik, QuHarmonics Research Group, ORCID 0009-0003-3128-8828.
"""
from __future__ import annotations

import math
from fractions import Fraction

import ipywidgets as W
from IPython.display import HTML, display

import ring_core as rc
import ring_lab as lab
import ring_viz as rv

LAYOUT_WIDE = W.Layout(width="100%")


def _panel(html):
    display(HTML(html))


def show_checks(*ids, include_long=True, title="Checks"):
    """Run (or reuse) checks by id and show them with their status."""
    res = lab.run(ids=list(ids), include_long=include_long)
    order = {k: i for i, k in enumerate(ids)}
    res.sort(key=lambda r: order.get(r["id"], 0))
    rows = [(r["id"], lab.status_of(r), r["statement"], r["scope"], r["expected"], r["actual"], r["source"],
             "%.2fs" % r["seconds"]) for r in res]
    display(HTML(rv.table(["id", "status", "statement", "scope", "expected", "actual", "source", "time"], rows,
                          mono_cols=(0,), status_col=1)))


def _parse_angle(s):
    s = str(s).strip().replace(" ", "")
    if not s:
        return Fraction(0)
    if s.endswith("deg"):
        return (Fraction(s[:-3]) / 360) % 1
    total = Fraction(0)
    for part in s.replace("-", "+-").split("+"):
        if part:
            total += Fraction(part)
    return total % 1


def _group_bits(s, k=8):
    if len(s) <= 16:
        return s
    return " ".join(s[i:i + k] for i in range(0, len(s), k))


# ----------------------------------------------------------------------------------------
# Word inspector
# ----------------------------------------------------------------------------------------

def inspect_word_html(x, n):
    N = 1 << n
    M = N >> 1
    j = rc.rev(x, n)
    c = rc.comp(x, n)
    pal = j == x
    p = rc.partner(x, n)
    a = rc.address(x, n)
    face = "representative" if a < M else "partner"
    dseam = (M - 1 - a) if a < M else (a - M)
    w = rc.wt(x)
    z = w - n / 2
    theta = math.degrees(math.acos(max(-1.0, min(1.0, 1 - 2 * w / n))))
    rep = x if x < p else p
    d, root, rw = rc.depth(rep, n)
    cls = rc.carry_class(x, n)
    lamps = "".join(str(((x >> (n - 1 - k)) & 1) ^ ((x >> k) & 1)) for k in range(n // 2))
    pairs = [("width n", n), ("value", "{:,}".format(x) if n <= 64 else "%d digits" % len(str(x))),
             ("hex", "0x" + format(x, "X")), ("weight · latitude z", "%d · %+.1f" % (w, z)),
             ("word (MSB first)", rv.bitspan(rc.bits(x, n)) if n <= 64 else _group_bits(rc.bits(x, n))),
             ("J(x) reversal", _group_bits(rc.bits(j, n))),
             ("C(x) complement", _group_bits(rc.bits(c, n))),
             ("partner P(x)", "%s  (%s)" % (_group_bits(rc.bits(p, n)), "complement: palindrome" if pal else "reversal")),
             ("address on R%d" % n, "{:,}".format(a)), ("face · distance from the seam", "%s · %s" % (face, "{:,}".format(dseam))),
             ("comparator c(x) = sgn(J(x) − x)", "%+d" % rc.comparator(x, n)),
             ("polar angle (sphere reading)", "%.4f°" % theta),
             ("continuation depth · root", "%d · %s (width %d)" % (d, rc.bits(root, rw) if rw else "", rw)),
             ("mirror lift: pair lamps x_j ⊕ x_(n−1−j)", lamps or "(none)"),
             ("as a carry: class · empty-field period", "R%d · %s ticks" % (cls, "{:,}".format(rc.CLASS_PERIOD[cls]))),
             ("as a carry: carrier K(w) size", len(rc.carrier_span(x, n)))]
    if n % 2 == 0 and n <= 64:
        h = n // 2
        f, g = x >> h, x & ((1 << h) - 1)
        pairs.append(("folded square (φ, γ)", "(%.6f, %.6f)" % (f / (1 << h), rc.rev(g, h) / (1 << h))))
    checks = [("P(P(x)) = x", rc.partner(p, n) == x), ("unrank(address) = x", rc.word_at(a, n) == x),
              ("address(P(x)) = N − 1 − address(x)", rc.address(p, n) == N - 1 - a)]
    chk = " ".join(rv.chip("RUNS" if ok else "FAIL", t) for t, ok in checks)
    return rv.card("Word inspector", rv.kv(pairs, cols=2) + '<div style="margin-top:8px">%s</div>' % chk,
                   kicker="exact at any width", accent=rv.BLUE)


def word_inspector(default="0x243F6A8885A308D3"):
    t = W.Text(value=default, description="word", layout=W.Layout(width="60%"), continuous_update=False,
               placeholder="0b1011, 0x2f, 0d47, 1011 (binary), or 47 (decimal)")
    wd = W.Text(value="", description="width", layout=W.Layout(width="22%"), placeholder="blank = from input",
                continuous_update=False)
    b = W.Button(description="inspect", button_style="info", icon="search")
    out = W.Output()

    def go_(*_):
        out.clear_output(wait=True)
        with out:
            try:
                n = int(wd.value) if wd.value.strip() else None
                x, n = rc.parse_word(t.value, n)
                _panel(inspect_word_html(x, n))
                if n <= 24:
                    rv.show(rv.fig_borrow(x, n))
            except Exception as e:
                _panel(rv.card("Input not read", rv.esc(str(e)), status="FAIL"))

    b.on_click(go_)
    t.observe(go_, "value")
    wd.observe(go_, "value")
    display(W.VBox([W.HBox([t, wd, b]), out]))
    go_()


# ----------------------------------------------------------------------------------------
# Ring explorer
# ----------------------------------------------------------------------------------------

def ring_explorer():
    n = W.IntSlider(value=5, min=2, max=9, description="width n", continuous_update=False)
    out = W.Output()

    def go_(*_):
        out.clear_output(wait=True)
        with out:
            rv.show(rv.fig_ring_order(n.value))

    n.observe(go_, "value")
    display(W.VBox([n, out]))
    go_()


# ----------------------------------------------------------------------------------------
# THE RING READER
# ----------------------------------------------------------------------------------------

HELP = {
    "Radial": ("<b>Radial reader</b> (published reader, <i>Mapping the Nested Partner Ring</i> §2). "
               "<b>location</b> = angle u in [0, 1), clockwise from the top (fraction, decimal, or '100deg'); "
               "<b>direction</b> = outward (ring 1 → D) or inward (ring D → 1); "
               "<b>width</b> = aperture: slices read per ring (1 is the published reader). "
               "On ring L it reads slice ⌊L·{2<sup>L</sup>u}⌋ of R<sub>L</sub>[⌊2<sup>L</sup>u⌋]."),
    "Tape": ("<b>Tape reader</b> (the ring's bit stream, <i>Mapping</i> §4). "
             "<b>location</b> = ring:slot:offset (e.g. 8:0:0); <b>direction</b> = clockwise or counterclockwise; "
             "<b>width</b> = window width in bits; <b>steps</b> = windows read. Each window is itself a word, "
             "and the dump gives its address on the ring of its own width."),
    "Native": ("<b>Native reader</b> (the reader–field step (3.1)). Its state is literally width, direction and location: "
               "<b>width</b> = n, <b>carry</b> w (the direction it moves), <b>location</b> p. "
               "Each tick: x = D[p] ⊕ w, p′ = p ⊕ x, w′ = P(x), D[p] ⊕= w′. The field starts empty."),
    "Clock": ("<b>Clock reader</b> (the one-inverter loop (2.1)). <b>width</b> = n cells, <b>location</b> = start word, "
              "<b>direction</b> = forward τ or backward τ⁻¹. The dump gives each word, its ring address and, at even n, "
              "the center reader y<sub>t</sub> (2.4)."),
}

DEFAULTS = {
    "Radial": dict(width=1, location="5/18", direction="outward (ring 1 → D)", steps=32, carry=""),
    "Tape": dict(width=8, location="8:0:0", direction="clockwise", steps=24, carry=""),
    "Native": dict(width=6, location="000000", direction="set by the carry w", steps=132, carry="000101"),
    "Clock": dict(width=9, location="000000000", direction="forward τ", steps=18, carry=""),
}
DIRS = {"Radial": ["outward (ring 1 → D)", "inward (ring D → 1)"], "Tape": ["clockwise", "counterclockwise"],
        "Native": ["set by the carry w"], "Clock": ["forward τ", "backward τ⁻¹"]}


def _dump_block(title, headers, rows, text, mono_cols, summary_pairs):
    return (rv.card(title, rv.kv(summary_pairs, cols=3) + rv.table(headers, rows, mono_cols=mono_cols, max_height=360)
                    + '<details style="margin-top:8px"><summary style="color:%s;cursor:pointer;font:13px %s">plain-text dump</summary>'
                      '<pre style="background:%s;color:%s;border:1px solid %s;border-radius:8px;padding:10px;'
                      'max-height:300px;overflow:auto;font:12px/1.45 %s">%s</pre></details>'
                    % (rv.INK2, rv.SANS, rv.PANEL2, rv.INK2, rv.BORDER, rv.MONO, rv.esc(text)),
                    kicker="what the reader read", accent=rv.READER))


def read_radial(D, u, width, inward):
    reads = rc.radial_read(u, D, width=width)
    order = list(reversed(reads)) if inward else reads
    rows, lines = [], []
    prof = ""
    for r in order:
        L = r["ring"]
        s = rc.bits(r["word"], L)
        hi = set(range(r["bit"], min(L, r["bit"] + width)))
        got = "".join(map(str, r["read"]))
        prof += got
        rows.append((L, r["slot"], rv.bitspan(s, hi), r["bit"], got,
                     "rep" if r["slot"] < (1 << (L - 1)) else "partner"))
        lines.append("ring %2d  slot %6d  word %s  slice %2d  read %s" % (L, r["slot"], s, r["bit"], got))
    summary = [("angle u", "%s ≈ %.9f" % (u, float(u))), ("rings read", "%d (%s)" % (D, "inward" if inward else "outward")),
               ("profile", rv.bitspan(prof) if len(prof) <= 120 else prof[:120] + "…"),
               ("profile as integer", "{:,}".format(int(prof, 2)) if prof else "0"),
               ("ones / zeros", "%d / %d" % (prof.count("1"), prof.count("0"))),
               ("aperture", "%d slice(s) per ring" % width)]
    text = "radial reader  u = %s  D = %d  %s\n" % (u, D, "inward" if inward else "outward") + "\n".join(lines) + "\nprofile " + prof
    block = _dump_block("Radial reading", ["ring", "slot", "word under the reader", "slice", "read", "face"], rows, text, (0, 1, 3, 4), summary)
    overlay = dict(kind="radial", u=u, reads=reads)
    return block, overlay, [int(prof[i:i + 8].ljust(8, "0"), 2) for i in range(0, len(prof), 8)], prof


def read_tape(D, loc, width, ccw, steps):
    parts = [int(v) for v in str(loc).replace(" ", "").split(":")]
    L, a, s = (parts + [0, 0, 0])[:3]
    L = max(1, min(L, 16))
    N = 1 << L
    T = N * L
    tb = rc.tape_bits(L)
    g0 = (a % N) * L + (s % L)
    sgn = -1 if ccw else 1
    rows, lines, wins = [], [], []
    allcells = []
    for k in range(steps):
        cells = [(g0 + sgn * (k * width + i)) % T for i in range(width)]
        allcells += cells
        bits_ = "".join(str(int(tb[c])) for c in cells)
        v = int(bits_, 2)
        wins.append(v)
        addr = rc.address(v, width) if width <= 64 else None
        first = cells[0]
        rows.append((k, "%d:%d" % (first // L, first % L), rv.bitspan(bits_), "{:,}".format(v),
                     "{:,}".format(addr) if addr is not None else "", "palindrome" if rc.is_pal(v, width) else ""))
        lines.append("read %3d  at slot %d slice %d  %s  = %d  address on R%d: %s" % (k, first // L, first % L, bits_, v, width, addr))
    distinct = len(set(wins))
    summary = [("ring · start", "R%d · slot %d · offset %d" % (L, a % N, s % L)), ("direction", "counterclockwise" if ccw else "clockwise"),
               ("window width", width), ("windows read", steps), ("distinct windows", "%d of %d" % (distinct, steps))]
    if width == L and not ccw and steps >= N:
        summary.append(("frame loss (offset %d)" % (s % L), "%d measured · %d by the frame law" % (rc.frame_loss(L, s % L), rc.frame_law(L, s % L))))
    text = "tape reader  R%d  start slot %d offset %d  width %d  %s\n" % (L, a % N, s % L, width, "ccw" if ccw else "cw") + "\n".join(lines)
    block = _dump_block("Tape reading", ["read", "slot:slice", "window", "value", "address on R%d" % width, "note"], rows, text, (0, 1, 3, 4), summary)
    overlay = dict(kind="tape", ring=L, start=g0 if not ccw else g0, direction="counterclockwise" if ccw else "clockwise",
                   count=len(allcells))
    # draw cells in reading order
    overlay["start"] = allcells[0] if allcells else g0
    overlay["count"] = len(allcells)
    overlay["window"] = width
    return block, overlay, wins, L


def read_native(n, p0, w0, ticks):
    rows_, (p, w, Df) = rc.run_reader(n, p0, w0, ticks)
    A = rc.address_table(n) if n <= 16 else None
    W_ = [r["w"] for r in rows_]
    rows, lines = [], []
    home = None
    for i, r in enumerate(rows_):
        q = (W_[i] ^ W_[i + 1] ^ W_[i + 2]) if i + 2 < len(W_) else None
        pa = int(A[r["p"]]) if A is not None else rc.address(r["p"], n)
        rows.append((r["t"], rv.bitspan(rc.bits(r["p"], n)), pa, rc.bits(r["w"], n), rc.bits(r["d"], n), rc.bits(r["x"], n),
                     rc.bits(r["w_next"], n), "" if q is None else rc.bits(q, n), r["kept"], rc.step_triangle(r["d"], r["w"])))
        lines.append("t %4d  p %s (slot %5d)  w %s  d %s  x %s  w' %s  q %s  kept %d" %
                     (r["t"], rc.bits(r["p"], n), pa, rc.bits(r["w"], n), rc.bits(r["d"], n), rc.bits(r["x"], n),
                      rc.bits(r["w_next"], n), "-" * n if q is None else rc.bits(q, n), r["kept"]))
    # home?
    D = {}
    pp, ww = p0, w0
    Pt = [int(v) for v in rc.partner_table(n)]
    for t in range(1, ticks + 1):
        pp, ww, _, _ = rc.step(pp, ww, D, n, Pt)
        if pp == p0 and ww == w0 and not D:
            home = t
            break
    cls = rc.carry_class(w0, n)
    summary = [("width · start", "n = %d · p = %s · w = %s" % (n, rc.bits(p0, n), rc.bits(w0, n))),
               ("carry class", "R%d (%s)" % (cls, {1: "the bare sign", 2: "one-lap closure", 3: "two-lap closure"}[cls])),
               ("period from the empty field", "{:,} ticks (STANDS, every width)".format(rc.CLASS_PERIOD[cls])),
               ("carrier K(w)", "%d words" % len(rc.carrier_span(w0, n))),
               ("returned home", ("at tick %d" % home) if home else "not within %d ticks" % ticks),
               ("kept cells at the end", len(Df))]
    text = "native reader  n = %d  p0 = %s  w0 = %s\n" % (n, rc.bits(p0, n), rc.bits(w0, n)) + "\n".join(lines)
    block = _dump_block("Native reading", ["t", "p (location)", "slot", "w (carry)", "d = D[p]", "x = d ⊕ w", "w′ = P(x)",
                                           "q (switch)", "kept", "step triangle"], rows, text, (0, 2, 3, 4, 5, 6, 7, 8), summary)
    addrs = [row[2] for row in rows] + [int(A[p]) if A is not None else rc.address(p, n)]
    labels = ["tick %d · %s" % (i, rc.bits(r["p"], n)) for i, r in enumerate(rows_)] + ["tick %d · %s" % (ticks, rc.bits(p, n))]
    overlay = dict(kind="native", ring=n, addresses=addrs, labels=labels)
    return block, overlay, [r["x"] for r in rows_], n


def read_clock(n, x0, ticks, backward):
    f = (lambda z: rc.tau_inv(z, n)) if backward else (lambda z: rc.tau(z, n))
    A = rc.address_table(n)
    orb = [x0]
    for _ in range(ticks):
        orb.append(f(orb[-1]))
    rows, lines = [], []
    for t, v in enumerate(orb[:-1]):
        y = rc.center_reader(v, n) if n % 2 == 0 else ""
        rows.append((t, rv.bitspan(rc.bits(v, n)), int(A[v]), rc.wt(v), "%+.1f" % (rc.wt(v) - n / 2), rc.wt(v) % 2, y))
        lines.append("t %3d  %s  slot %5d  wt %d  y %s" % (t, rc.bits(v, n), int(A[v]), rc.wt(v), y))
    L = len(rc.tau_orbit(x0, n))
    lockinfo = []
    for s in range(1, n + 1):
        if n % s == 0:
            y = x0
            for _ in range(s):
                y = rc.tau(y, n)
            if y == x0 ^ rc.umask(n):
                lockinfo.append(s)
    summary = [("width · start", "n = %d · %s" % (n, rc.bits(x0, n))), ("orbit length", "%d (lap 2n = %d)" % (L, 2 * n)),
               ("tick angle", "π/%d = %.4f° (fundamental mode)" % (n, 180 / n)),
               ("locks τ^s(x) = C(x)", ", ".join("s = %d" % s for s in lockinfo) or "none"),
               ("direction", "backward τ⁻¹" if backward else "forward τ")]
    if n % 2 == 0:
        acc = 0
        y = x0
        for _ in range(n):
            acc ^= rc.center_reader(y, n)
            y = rc.tau(y, n)
        summary.append(("XOR of n center readings", acc))
    text = "clock reader  n = %d  x0 = %s\n" % (n, rc.bits(x0, n)) + "\n".join(lines)
    block = _dump_block("Clock reading", ["t", "word", "slot", "wt", "latitude", "parity", "center reader"], rows, text,
                        (0, 2, 3, 4, 5, 6), summary)
    overlay = dict(kind="clock", ring=n, addresses=[int(A[v]) for v in orb],
                   labels=["tick %d · %s" % (t, rc.bits(v, n)) for t, v in enumerate(orb)])
    return block, overlay, orb[:-1], n


def ring_reader(height=760):
    rings = W.IntSlider(value=8, min=1, max=10, description="rings to nest", continuous_update=False,
                        style=dict(description_width="110px"), layout=W.Layout(width="420px"))
    kind = W.ToggleButtons(options=["Radial", "Tape", "Native", "Clock"], value="Radial", description="reader",
                           style=dict(description_width="110px", button_width="92px"))
    width = W.IntSlider(value=1, min=1, max=24, description="width", continuous_update=False,
                        style=dict(description_width="110px"), layout=W.Layout(width="420px"))
    direction = W.Dropdown(options=DIRS["Radial"], value=DIRS["Radial"][0], description="direction",
                           style=dict(description_width="110px"), layout=W.Layout(width="420px"))
    location = W.Text(value="5/18", description="location", style=dict(description_width="110px"), layout=W.Layout(width="420px"),
                      continuous_update=False)
    carry = W.Text(value="", description="carry w", style=dict(description_width="110px"), layout=W.Layout(width="420px"),
                   placeholder="Native reader only", continuous_update=False)
    steps = W.IntSlider(value=32, min=1, max=512, description="steps", continuous_update=False,
                        style=dict(description_width="110px"), layout=W.Layout(width="420px"))
    view = W.ToggleButtons(options=["bits", "merge"], value="bits", description="disk view",
                           style=dict(description_width="110px", button_width="70px"))
    runb = W.Button(description="read", button_style="info", icon="play")
    helpbox = W.HTML()
    out = W.Output()
    busy = {"v": False}

    def set_kind(*_):
        busy["v"] = True
        k = kind.value
        d = DEFAULTS[k]
        direction.options = DIRS[k]
        direction.value = DIRS[k][0]
        width.max = 24 if k in ("Radial", "Tape") else (10 if k == "Native" else 12)
        width.min = 1 if k in ("Radial", "Tape") else 2
        width.value = d["width"]
        location.value = d["location"]
        carry.value = d["carry"]
        carry.disabled = k != "Native"
        steps.value = d["steps"]
        helpbox.value = ('<div style="background:%s;border:1px solid %s;border-radius:8px;padding:8px 12px;color:%s;'
                         'font:13px/1.5 %s">%s</div>' % (rv.PANEL, rv.BORDER, rv.INK2, rv.SANS, HELP[k]))
        busy["v"] = False
        go_()

    def go_(*_):
        if busy["v"]:
            return
        out.clear_output(wait=True)
        with out:
            try:
                k = kind.value
                D = rings.value
                if k == "Radial":
                    u = _parse_angle(location.value)
                    block, ov, ribbon, prof = read_radial(D, u, width.value, direction.value.startswith("inward"))
                    fig = rv.fig_disk(D, view.value, reader=ov, title="Radial reader at u = %s on rings 1-%d" % (u, D), height=height)
                    rv.show(fig)
                    _panel(block)
                elif k == "Tape":
                    block, ov, wins, L = read_tape(D, location.value, width.value, direction.value == "counterclockwise", steps.value)
                    Dd = max(D, L)
                    fig = rv.fig_disk(Dd, view.value, reader=ov, title="Tape reader on ring %d (rings 1-%d)" % (L, Dd), height=height)
                    rv.show(fig)
                    _panel(block)
                    rv.show(rv.fig_tape_ribbon(wins, width.value, title="Windows read (rows) · bits (columns)"))
                elif k == "Native":
                    n = width.value
                    p0, _ = rc.parse_word(location.value, n)
                    w0, _ = rc.parse_word(carry.value or "0", n)
                    block, ov, xs, n = read_native(n, p0, w0, steps.value)
                    Dd = max(D, n)
                    fig = rv.fig_disk(Dd, view.value, reader=ov, title="Native reader on ring %d: route of p" % n, height=height)
                    rv.show(fig)
                    _panel(block)
                else:
                    n = width.value
                    x0, _ = rc.parse_word(location.value, n)
                    block, ov, orb, n = read_clock(n, x0, steps.value, direction.value.startswith("backward"))
                    Dd = max(D, n) if n <= 10 else D
                    if n <= 10:
                        fig = rv.fig_disk(Dd, view.value, reader=ov, title="Clock reader on ring %d" % n, height=height)
                        rv.show(fig)
                    _panel(block)
                    rv.show(rv.fig_clock_strip(x0, n))
            except Exception as e:
                _panel(rv.card("Reader input not read", rv.esc("%s: %s" % (type(e).__name__, e)), status="FAIL"))

    kind.observe(set_kind, "value")
    for wdg in (rings, width, direction, view, steps, location, carry):
        wdg.observe(go_, "value")
    runb.on_click(go_)
    controls = W.VBox([kind, helpbox, W.HBox([W.VBox([rings, width, direction, steps]), W.VBox([location, carry, view, runb])])])
    display(W.VBox([controls, out]))
    set_kind()


# ----------------------------------------------------------------------------------------
# Clock explorer and port lab
# ----------------------------------------------------------------------------------------

def clock_explorer():
    n = W.IntSlider(value=9, min=2, max=14, description="width n", continuous_update=False)
    x = W.Text(value="0", description="start word", continuous_update=False)
    k = W.IntSlider(value=0, min=0, max=4, description="mode k", continuous_update=False)
    out = W.Output()

    def go_(*_):
        out.clear_output(wait=True)
        with out:
            try:
                nn = n.value
                k.max = (nn - 1) // 2
                x0, _ = rc.parse_word(x.value.strip() or "0", nn)
                orb = rc.tau_orbit(x0, nn)
                z, lam = rc.mode_projection(orb, nn, k.value)
                ang = (2 * k.value + 1) * 180 / nn
                c = rc.orbit_census(nn)
                _panel(rv.card("Clock at n = %d" % nn, rv.kv([
                    ("orbit of %s" % rc.bits(x0, nn), "%d ticks" % len(orb)),
                    ("census", ", ".join("%d × %d" % (v, L) for L, v in sorted(c.items(), reverse=True))),
                    ("mode k = %d" % k.value, "turns %.4f° per tick" % ang),
                    ("|projection|", "%.4f" % abs(z[0]))], cols=4), kicker="one-inverter loop", accent=rv.YELLOW))
                rv.show(rv.fig_clock_strip(x0, nn))
            except Exception as e:
                _panel(rv.card("Input not read", rv.esc(str(e)), status="FAIL"))

    for wdg in (n, k):
        wdg.observe(go_, "value")
    x.observe(go_, "value")
    display(W.VBox([W.HBox([n, x, k]), out]))
    go_()


def port_lab():
    tgt = W.IntSlider(value=5, min=0, max=31, description="target word", continuous_update=False)
    tick = W.IntSlider(value=3, min=3, max=8, description="landing tick", continuous_update=False)
    out = W.Output()

    def go_(*_):
        out.clear_output(wait=True)
        with out:
            r = rc.derive_port(tgt.value, tick.value)
            st = "RUNS" if r["ok"] else "ELSEWHERE"
            msg = ("A lands on %d at tick %d." % (r["landed"], tick.value)) if r["ok"] else (
                "A lands on %d, not %d. Owner: interference: the depositor's own route or writes cross the pair before the "
                "landing, so the single-reader inversion used for its prior state does not hold. "
                "The derivation is exact when the depositor's path stays off the pair's cells." % (r["landed"], tgt.value))
            body = rv.kv([("destination", "%d = %s" % (tgt.value, rc.bits(tgt.value, 5))),
                          ("required read cell", r["cell"]), ("required deposit D[cell]", r["deposit"]),
                          ("derived third reader C₀", "(%d, %d)" % r["seed"]), ("seal (SHA-256, before the run)", r["seal"][:24] + "…"),
                          ("landed", r["landed"])], cols=3)
            _panel(rv.card("Reverse the gap: destination → read → deposit → depositor", body + "<p>%s</p>" % rv.esc(msg),
                           status=st))
            j = rc.Joint([(0, 1), (0, 4), r["seed"]])
            rows = [dict(t=0, A=(j.p[0], j.w[0]), B=(j.p[1], j.w[1]), C=(j.p[2], j.w[2]))]
            for t in range(1, tick.value + 1):
                j.step()
                rows.append(dict(t=t, A=(j.p[0], j.w[0]), B=(j.p[1], j.w[1]), C=(j.p[2], j.w[2])))
            rv.show(rv.fig_port(rows, title="Derived port: target %d at tick %d" % (tgt.value, tick.value)))

    tgt.observe(go_, "value")
    tick.observe(go_, "value")
    display(W.VBox([W.HBox([tgt, tick]), out]))
    go_()
