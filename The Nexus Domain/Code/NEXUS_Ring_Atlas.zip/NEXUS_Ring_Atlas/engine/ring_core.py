"""NEXUS Ring Atlas - mathematical core.

Dean A. Kulik, QuHarmonics Research Group, ORCID 0009-0003-3128-8828.
Pure Python + numpy. No graphics: every function here runs with the plotting layer switched off.

Conventions
  A word x of width n is an integer; bit i is the coefficient of 2**i; words are written MSB first.
  J = reversal, C = complement, u = 2**n - 1, N = 2**n, M = N // 2.
  P(x) = J(x) if J(x) != x else C(x)                      (the native partner)
  R_n: representatives (x < P(x)) ascend in slots 0..M-1, P(R_n[i]) sits in slot N-1-i,
       slots M-1 and M are exchanged (n >= 2).  The slot of x is its address.
"""
from __future__ import annotations

import hashlib
import json
import math
import random
from collections import Counter
from fractions import Fraction
from functools import lru_cache

import numpy as np

__version__ = "1.0.0"

# Ledger words.  ELSEWHERE replaces the older DEAD END: the computation ran and landed,
# and the landing belongs to a named owner.  Rename here and every panel follows.
STANDS, RUNS, OPEN, PULL, ELSEWHERE = "STANDS", "RUNS", "OPEN", "PULL", "ELSEWHERE"
LEDGER = (STANDS, RUNS, OPEN, PULL, ELSEWHERE)
LEDGER_MEANING = {
    STANDS: "proved, or supplied by a cited theorem",
    RUNS: "an executed readout landed where the derivation placed it; scope stated",
    OPEN: "the shape of the missing link is fixed; the link is not yet written",
    PULL: "a reading of the domain at a physical or human location, held as a comparator",
    ELSEWHERE: "the computation ran and landed; the landing belongs to the named owner (arrow)",
}

# ----------------------------------------------------------------------------------------
# 1. Words
# ----------------------------------------------------------------------------------------

def umask(n: int) -> int:
    return (1 << n) - 1


def rev(x: int, n: int) -> int:
    """J: reverse the n bits of x (exact at any width)."""
    if n <= 0:
        return 0
    return int(format(x, "0%db" % n)[::-1], 2)


def comp(x: int, n: int) -> int:
    """C: complement."""
    return x ^ umask(n)


def is_pal(x: int, n: int) -> bool:
    return rev(x, n) == x


def partner(x: int, n: int) -> int:
    """P: reversal off the palindromes, complement on them."""
    j = rev(x, n)
    return (x ^ umask(n)) if j == x else j


def wt(x: int) -> int:
    return bin(x).count("1")


def bits(x: int, n: int) -> str:
    """MSB-first bit string."""
    return format(x, "0%db" % n) if n > 0 else ""


def parse_word(s, n=None):
    """Accept an int or a string: '0b1011', '0x2f', '0d47', plain binary ('1011'), or decimal ('47').
    A string of 0s and 1s is read as binary; its width is its length unless n is given.
    Returns (x, n)."""
    if isinstance(s, (int, np.integer)):
        x = int(s)
        if n is None:
            n = max(1, x.bit_length())
        if x >= (1 << n) or x < 0:
            raise ValueError("value %d does not fit in %d bits" % (x, n))
        return x, n
    t = str(s).strip().replace("_", "").replace(" ", "").lower()
    if t.startswith("0b"):
        body = t[2:]
        x = int(body, 2)
        w = len(body)
    elif t.startswith("0x"):
        body = t[2:]
        x = int(body, 16)
        w = 4 * len(body)
    elif t.startswith("0d"):
        x = int(t[2:])
        w = max(1, x.bit_length())
    elif t and set(t) <= {"0", "1"}:
        x = int(t, 2)
        w = len(t)
    else:
        x = int(t)
        w = max(1, x.bit_length())
    if n is None:
        n = w
    if x >= (1 << n):
        raise ValueError("value does not fit in %d bits" % n)
    return x, n


def rev_vec(a, n: int):
    a = np.asarray(a, dtype=np.int64)
    r = np.zeros_like(a)
    for i in range(n):
        r |= ((a >> i) & 1) << (n - 1 - i)
    return r


def popcount_vec(a):
    a = np.asarray(a, dtype=np.int64)
    c = np.zeros_like(a)
    while np.any(a):
        c += a & 1
        a = a >> 1
    return c


@lru_cache(maxsize=64)
def partner_table(n: int) -> np.ndarray:
    N = 1 << n
    w = np.arange(N, dtype=np.int64)
    j = rev_vec(w, n)
    t = np.where(j == w, w ^ (N - 1), j)
    t.setflags(write=False)
    return t


@lru_cache(maxsize=64)
def pal_table(n: int) -> np.ndarray:
    w = np.arange(1 << n, dtype=np.int64)
    t = rev_vec(w, n) == w
    t.setflags(write=False)
    return t


# ----------------------------------------------------------------------------------------
# 2. The ring
# ----------------------------------------------------------------------------------------

@lru_cache(maxsize=64)
def ring(n: int) -> np.ndarray:
    """R_n as an int64 array (n <= 26)."""
    if n < 1:
        raise ValueError("width must be >= 1")
    N = 1 << n
    M = N // 2
    w = np.arange(N, dtype=np.int64)
    p = partner_table(n)
    reps = w[w < p]
    R = np.empty(N, dtype=np.int64)
    R[:M] = reps
    R[N - 1 - np.arange(M)] = p[reps]
    if n >= 2:
        a, b = int(R[M - 1]), int(R[M])
        R[M - 1], R[M] = b, a
    R.setflags(write=False)
    return R


@lru_cache(maxsize=64)
def address_table(n: int) -> np.ndarray:
    R = ring(n)
    A = np.empty_like(R)
    A[R] = np.arange(len(R), dtype=np.int64)
    A.setflags(write=False)
    return A


@lru_cache(maxsize=64)
def tape_bits(n: int) -> np.ndarray:
    """T_n as a uint8 array of n * 2**n slices: ring words in slot order, each MSB first."""
    R = ring(n)
    sh = np.arange(n - 1, -1, -1, dtype=np.int64)
    t = ((R[:, None] >> sh[None, :]) & 1).astype(np.uint8).reshape(-1)
    t.setflags(write=False)
    return t


def seam_word(n: int) -> int:
    """R_n[M] = 1^(floor(n/2)-1) 0 1^(ceil(n/2)) for n >= 2 (Mapping the Nested Partner Ring, §5)."""
    a, b = n // 2 - 1, (n + 1) // 2
    return int("1" * a + "0" + "1" * b, 2)


# ---- exact address at any width (digit DP over mirror pairs, outside in) ----------------

def _sgn(a: int, b: int) -> int:
    return (a > b) - (a < b)


def _dp_counts(p: int, n: int, pal_only: bool) -> int:
    """pal_only=False: #{x : x < p <= J(x)} (= Delta(p));  pal_only=True: #{palindromes x < p}."""
    h = n // 2
    pb = [(p >> i) & 1 for i in range(n)]
    states = {(0, 0, 0, 0): 1}
    for k in range(h):
        P_hi = pb[n - 1 - k]
        P_lo = pb[k]
        new = {}
        pairs = ((0, 0), (1, 1)) if pal_only else ((0, 0), (0, 1), (1, 0), (1, 1))
        for (hx, hj, lx, lj), cnt in states.items():
            for a, b in pairs:          # a = x_{n-1-k}, b = x_k
                nhx = hx if hx else _sgn(a, P_hi)
                if nhx > 0:
                    continue
                nlx = lx if b == P_lo else _sgn(b, P_lo)
                if nhx < 0:
                    nlx = 0
                if pal_only:
                    key = (nhx, 0, nlx, 0)
                else:
                    nhj = hj if hj else _sgn(b, P_hi)
                    if nhj < 0:
                        continue
                    nlj = lj if a == P_lo else _sgn(a, P_lo)
                    if nhj > 0:
                        nlj = 0
                    key = (nhx, nhj, nlx, nlj)
                new[key] = new.get(key, 0) + cnt
        states = new
    total = 0
    mids = (0, 1) if n % 2 else (None,)
    for (hx, hj, lx, lj), cnt in states.items():
        for c in mids:
            cm = 0 if c is None else _sgn(c, pb[h])
            cx = hx or cm or lx
            if pal_only:
                if cx < 0:
                    total += cnt
            else:
                cj = hj or cm or lj
                if cx < 0 and cj >= 0:
                    total += cnt
    return total


def pal_below(p: int, n: int) -> int:
    """pi(p): palindromes below p."""
    return _dp_counts(p, n, True)


def delta(p: int, n: int) -> int:
    """Delta(p) = sum_{x<p} sgn(J(x) - x) = #{x : x < p <= J(x)}   (Against Its Own Reverse)."""
    return _dp_counts(p, n, False)


def reps_below(p: int, n: int) -> int:
    """rank(p) = (p - pi(p) + Delta(p))/2 + min(pi(p), 2^(ceil(n/2)-1))   (1.7)."""
    pi = pal_below(p, n)
    d = delta(p, n)
    return (p - pi + d) // 2 + min(pi, 1 << ((n + 1) // 2 - 1))


def address(x: int, n: int) -> int:
    """Exact slot of x on R_n at any width (Python integers)."""
    N = 1 << n
    M = N >> 1
    px = partner(x, n)
    a = reps_below(x, n) if x < px else N - 1 - reps_below(px, n)
    if n >= 2 and a in (M - 1, M):
        a = 2 * M - 1 - a
    return a


def word_at(a: int, n: int) -> int:
    """Inverse of address: R_n[a] at any width."""
    N = 1 << n
    M = N >> 1
    if not 0 <= a < N:
        raise ValueError("address out of range")
    if n >= 2 and a in (M - 1, M):
        a = 2 * M - 1 - a
    if a >= M:
        return partner(word_at_pre(N - 1 - a, n), n)
    return word_at_pre(a, n)


def word_at_pre(a: int, n: int) -> int:
    """a-th representative in ascending order (before the seam exchange)."""
    lo, hi = 0, (1 << n) - 1
    while lo < hi:                       # largest p with reps_below(p) <= a
        mid = (lo + hi + 1) >> 1
        if reps_below(mid, n) <= a:
            lo = mid
        else:
            hi = mid - 1
    return lo


def ring_word(a: int, n: int) -> int:
    """R_n[a]: table lookup when small, exact unrank when large."""
    if n <= 16:
        return int(ring(n)[a])
    return word_at(a, n)


def face(a: int, n: int) -> int:
    return int(a >= (1 << (n - 1)))


def comparator(x: int, n: int) -> int:
    """c(x) = sgn(J(x) - x)."""
    return _sgn(rev(x, n), x)


def borrow_chain(a: int, b: int, n: int):
    """Subtract b from a bit by bit, LSB first, with the borrow cell beta' = Maj(not a_i, b_i, beta).
    Returns rows (i, a_i, b_i, beta_in, beta_out); the final beta_out is [a < b]."""
    rows = []
    beta = 0
    for i in range(n):
        ai, bi = (a >> i) & 1, (b >> i) & 1
        na = 1 - ai
        out = (na & bi) | (na & beta) | (bi & beta)
        rows.append((i, ai, bi, beta, out))
        beta = out
    return rows


def comparator_ring_law(n: int) -> np.ndarray:
    """c_R(i) = chi_top(i) * (1 - pal(i) - 2[i in {M-1, M}])   (1.9)."""
    N = 1 << n
    M = N // 2
    R = ring(n)
    pal = pal_table(n)[R].astype(np.int64)
    chi = np.where(np.arange(N) < M, 1, -1)
    seam = np.zeros(N, dtype=np.int64)
    if n >= 2:
        seam[[M - 1, M]] = 1
    return chi * (1 - pal - 2 * seam)


# ----------------------------------------------------------------------------------------
# 3. Geometry readings of the ring: sphere, folded square, parabola, depth, merge
# ----------------------------------------------------------------------------------------

def sphere_coords(n: int):
    """Azimuth of the address, polar angle from weight: cos(theta) = 1 - 2 wt/n  (1.10, 7.2)."""
    R = ring(n)
    N = len(R)
    a = np.arange(N)
    phi = 2 * np.pi * (a + 0.5) / N
    w = popcount_vec(R)
    cos_t = 1 - 2 * w / n
    sin_t = np.sqrt(np.clip(1 - cos_t ** 2, 0, None))
    return dict(x=sin_t * np.cos(phi), y=sin_t * np.sin(phi), z=cos_t, phi=phi, wt=w, words=R, addr=a)


def folded_square(n: int):
    """Even n = 2h: x = f || g  ->  (f / 2^h, J(g) / 2^h).  Partner = mirror across the diagonal."""
    if n % 2:
        raise ValueError("folded square: use an even width (odd widths carry two sheets)")
    h = n // 2
    w = np.arange(1 << n, dtype=np.int64)
    f = w >> h
    g = w & ((1 << h) - 1)
    jg = rev_vec(g, h)
    return dict(phi=f / (1 << h), gamma=jg / (1 << h), words=w)


def parabola_residual(n: int):
    """Representatives at (t = value/N, u = address/N); returns t, u, residual u - (t - t^2/2)."""
    N = 1 << n
    A = address_table(n)
    p = partner_table(n)
    w = np.arange(N, dtype=np.int64)
    reps = w[w < p]
    t = reps / N
    u = A[reps] / N
    return t, u, u - (t - t * t / 2)


def tent_Q(f: int, h: int) -> Fraction:
    """Q(f) = f 2^h - f^2/2 + (1/2) min(f, 2^h - f)  (Where Yes and No Become Maybe, Route 7)."""
    H = 1 << h
    return Fraction(f * H) - Fraction(f * f, 2) + Fraction(min(f, H - f), 2)


def depth(x: int, n: int):
    """Continuation depth of a representative: strip F-frames from the outside.
    F(a) = min(1a1, P(1a1)): reversal branch 1a1 (a non-palindromic rep),
    complement branch 0C(a)0 (a palindromic rep).  Returns (depth, root, root_width)."""
    d, L = 0, n
    while L >= 3:
        b = (x >> (L - 1)) & 1
        c = x & 1
        m = (x >> 1) & umask(L - 2)
        if b == 1 and c == 1:
            jm = rev(m, L - 2)
            if jm != m and m < jm:
                x, L, d = m, L - 2, d + 1
                continue
        elif b == 0 and c == 0:
            if rev(m, L - 2) == m and (m >> (L - 3)) & 1:
                x, L, d = m ^ umask(L - 2), L - 2, d + 1
                continue
        break
    return d, x, L


def F_power(root: int, w: int, k: int):
    """Closed-form continuation codec: F^k(rho).  Non-palindromic root -> 1^k rho 1^k;
    palindromic root -> a_k X a_k^R with a_k = first k bits of 0101..., X = rho (k even) or C(rho) (k odd)."""
    if rev(root, w) != root:
        s = "1" * k + bits(root, w) + "1" * k
    else:
        ak = ("01" * (k // 2 + 1))[:k]
        X = root if k % 2 == 0 else comp(root, w)
        s = ak + bits(X, w) + ak[::-1]
    return int(s, 2), w + 2 * k


def F_step(a: int, w: int):
    x = int("1" + bits(a, w) + "1", 2)
    return min(x, partner(x, w + 2)), w + 2


def merge_grey(n: int) -> int:
    """Sum over all words of wt(x xor P(x))."""
    w = np.arange(1 << n, dtype=np.int64)
    return int(popcount_vec(w ^ partner_table(n)).sum())


# ----------------------------------------------------------------------------------------
# 4. Readers of the fixed mold: radial reader, tape frames, radial language, witness angle
# ----------------------------------------------------------------------------------------

def radial_read(u, D: int, width: int = 1, start_ring: int = 1):
    """Radial reader (Mapping the Nested Partner Ring, §2): on ring L read slice floor(L {2^L u})
    of R_L[floor(2^L u)], counted from the MSB.  width > 1 reads that many consecutive slices of
    the ring's tape (crossing into the next word when needed).  u is a Fraction (exact)."""
    u = Fraction(u) % 1
    out = []
    for L in range(start_ring, D + 1):
        z = u * (1 << L)
        slot = z.numerator // z.denominator
        fr = z - slot
        y = fr * L
        bitpos = y.numerator // y.denominator
        read = []
        s, b = slot, bitpos
        N = 1 << L
        for _ in range(width):
            word = ring_word(s, L)
            read.append((word >> (L - 1 - b)) & 1)
            b += 1
            if b == L:
                b, s = 0, (s + 1) % N
        word0 = ring_word(slot, L)
        out.append(dict(ring=L, slot=slot, bit=bitpos, word=word0, read=read))
    return out


def tape_windows(L: int, s: int, width: int = None):
    """w_i(s) = (R[i] mod 2^(L-s)) 2^s + floor(R[i+1] / 2^(L-s)): the L-bit window s slices into slot i."""
    R = ring(L).astype(np.int64)
    if width is None or width == L:
        nxt = np.roll(R, -1)
        return (R & ((1 << (L - s)) - 1)) * (1 << s) + (nxt >> (L - s))
    t = tape_bits(L)
    T = len(t)
    idx = (np.arange(1 << L)[:, None] * L + s + np.arange(width)[None, :]) % T
    sh = np.arange(width - 1, -1, -1)
    return (t[idx].astype(np.int64) << sh).sum(axis=1)


def frame_loss(L: int, s: int) -> int:
    w = tape_windows(L, s)
    return (1 << L) - len(np.unique(w))


def frame_law(L: int, s: int) -> int:
    """Loss of frame s (Mapping the Nested Partner Ring, §4)."""
    h = L // 2
    P = 1 << ((L + 1) // 2)
    if s <= 1:
        return 0
    if 2 <= s <= h - 1:
        return P - (P >> (s - 2))          # P (1 - 2^(2-s))
    if s == h:
        return P - 2 if L % 2 == 0 else P - 6
    if h + 1 <= s <= L - 2:
        return P - 2 - (1 << (s - h + 1))
    return P - 2                           # s = L - 1


def radial_language(D: int):
    """Distinct radial profiles R_D and the angular entropy, by merging every slice boundary of
    rings 1..D on one integer grid (exact).  D <= 16."""
    if D > 16:
        raise ValueError("D <= 16 keeps the integer grid inside int64")
    G = math.lcm(*range(1, D + 1)) * (1 << D)
    bnds = [np.arange(L * (1 << L), dtype=np.int64) * (G // (L * (1 << L))) for L in range(1, D + 1)]
    b = np.unique(np.concatenate(bnds + [np.array([G], dtype=np.int64)]))
    left = b[:-1]
    meas = np.diff(b)
    key = np.zeros(len(left), dtype=np.int64)
    for L in range(1, D + 1):
        sl = (left * (L * (1 << L))) // G
        key |= tape_bits(L)[sl].astype(np.int64) << (L - 1)
    uk, inv = np.unique(key, return_inverse=True)
    mass = np.bincount(inv, weights=meas.astype(np.float64)) / G
    H = float(-(mass * np.log2(mass)).sum())
    return len(uk), H


def witness_angle(D: int, tau=None):
    """Theorem 2 (Mapping the Nested Partner Ring): u_D = 1/2 + 2^-p + tau 2^-(D-1), t = floor((D-2)/3),
    p = 2t + 3, tau in [2/3 + 1/(6D), 2/3 + 1/(3D)).  Default tau: the middle of that window."""
    t = (D - 2) // 3
    p = 2 * t + 3
    if tau is None:
        tau = Fraction(2, 3) + Fraction(1, 4 * D)
    return Fraction(1, 2) + Fraction(1, 1 << p) + Fraction(tau) / (1 << (D - 1)), p, t


def witness_profile(D: int) -> str:
    return "1" + "00" + "1" * (D - 5) + "00"


def profile(u, D: int) -> str:
    return "".join(str(r["read"][0]) for r in radial_read(u, D))


# ----------------------------------------------------------------------------------------
# 5. Boolean Moebius bridge  MD = SA,  X = M S^T M D   (Bicomplex Difference Calculus)
# ----------------------------------------------------------------------------------------

def state_matrix(n: int) -> np.ndarray:
    """X: N x n bit table of the ring, row k = R_n[k], column j = bit j (LSB = column 0)."""
    R = ring(n)
    return ((R[:, None] >> np.arange(n)[None, :]) & 1).astype(np.uint8)


def mobius(X: np.ndarray) -> np.ndarray:
    """(M X)_u = XOR over v subset of u of X_v (self-inverse over GF(2))."""
    A = X.copy()
    N = A.shape[0]
    cols = A.shape[1] if A.ndim == 2 else 1
    A2 = A.reshape(N, cols)
    b = 1
    while b < N:
        V = A2.reshape(N // (2 * b), 2, b, cols)
        V[:, 1] ^= V[:, 0]
        b <<= 1
    return A2.reshape(X.shape)


def diff_stream(X: np.ndarray) -> np.ndarray:
    """D_k = X_k xor X_{k+1 mod N}."""
    return X ^ np.roll(X, -1, axis=0)


def shift_up(A: np.ndarray) -> np.ndarray:
    """(S a)_u = a_{u+1}, (S a)_{N-1} = 0."""
    out = np.zeros_like(A)
    out[:-1] = A[1:]
    return out


def shift_down(B: np.ndarray) -> np.ndarray:
    """S^T: (S^T b)_u = b_{u-1}, (S^T b)_0 = 0."""
    out = np.zeros_like(B)
    out[1:] = B[:-1]
    return out


def mobius_check(n: int):
    X = state_matrix(n)
    Dm = diff_stream(X)
    A = mobius(X)
    MD = mobius(Dm)
    SA = shift_up(A)
    Xr = mobius(shift_down(mobius(Dm)))
    return dict(X=X, D=Dm, A=A, MD=MD, SA=SA, ok_bridge=bool(np.array_equal(MD, SA)),
                ok_rebuild=bool(np.array_equal(Xr, X)), top_row_zero=bool(not A[0].any()))


# ----------------------------------------------------------------------------------------
# 6. The one-inverter clock  tau(x) = rotl1(x) xor 1   (One Inverter)
# ----------------------------------------------------------------------------------------

def tau(x: int, n: int) -> int:
    U = umask(n)
    return ((x << 1) & U) | (1 ^ (x >> (n - 1)))


def tau_inv(y: int, n: int) -> int:
    b0 = (y & 1) ^ 1
    return (y >> 1) | (b0 << (n - 1))


def tau_orbit(x: int, n: int):
    out = [x]
    y = tau(x, n)
    while y != x:
        out.append(y)
        y = tau(y, n)
    return out


def orbit_census(n: int, f=None) -> Counter:
    N = 1 << n
    f = f or (lambda z: tau(z, n))
    seen = bytearray(N)
    c = Counter()
    for x0 in range(N):
        if seen[x0]:
            continue
        L, x = 0, x0
        while True:
            seen[x] = 1
            x = f(x)
            L += 1
            if x == x0:
                break
        c[L] += 1
    return c


def orbit_law(n: int) -> set:
    """|orbit| = 2n/d over odd d | n   (2.3)."""
    return {2 * n // d for d in range(1, n + 1, 2) if n % d == 0}


def spin_matrix(n: int) -> np.ndarray:
    """tau in spin coordinates s_i = (-1)^(x_i): the negacyclic shift N, N^n = -I."""
    Nm = np.zeros((n, n))
    for i in range(n - 1):
        Nm[i + 1, i] = 1.0
    Nm[0, n - 1] = -1.0
    return Nm


def spins(x: int, n: int) -> np.ndarray:
    return np.array([1.0 - 2.0 * ((x >> i) & 1) for i in range(n)])


def eigenangles(n: int):
    """Eigenangles of the spin clock in units of pi/n: the odd integers 1, 3, ..., (2n-1) folded to [0, n]."""
    ev = np.linalg.eigvals(spin_matrix(n))
    return sorted(set(round(abs(np.angle(l)) / np.pi * n, 6) for l in ev))


def mode_projection(orbit, n: int, k: int):
    """Project the spin vectors of an orbit onto the eigenvector with eigenvalue e^{i pi (2k+1)/n}.
    Under tau the projection rotates by exactly (2k+1) pi / n per tick."""
    lam = np.exp(1j * np.pi * (2 * k + 1) / n)
    # eigenvector of N for lam: v_j = lam^{-j}  (N v = lam v for the negacyclic shift)
    v = np.array([lam ** (-j) for j in range(n)]) / np.sqrt(n)
    return np.array([np.vdot(v, spins(x, n)) for x in orbit]), lam


def center_reader(x: int, n: int) -> int:
    """r(x) = x_{h-1} xor x_{n-h}, h = floor(n/2): the innermost mirror lamp (2.4).
    At even n, under tau it reads y_t = d_{(h-1-t) mod n} xor [t = h] with d_j = x_j xor x_{j+1 mod n}
    (bit i = coefficient of 2^i; the source writes the same law with the opposite index direction),
    and the n readings XOR to 1."""
    h = n // 2
    return ((x >> (h - 1)) & 1) ^ ((x >> (n - h)) & 1)


def lock_words(n: int, s: int):
    """Words with tau^s(x) = C(x); they exist iff q = n/s is odd   (2.3)."""
    U = umask(n)
    out = []
    for x in range(1 << n):
        y = x
        for _ in range(s):
            y = tau(y, n)
        if y == x ^ U:
            out.append(x)
    return out


# ----------------------------------------------------------------------------------------
# 7. The reader-field machine  (Retained Continuation; Exact Algebra)
# ----------------------------------------------------------------------------------------

def carry_class(w: int, n: int) -> int:
    """R1 = {0, u}; R2 = palindromes and anti-palindromes (J w = w or J w = C w); R3 = the rest."""
    U = umask(n)
    if w in (0, U):
        return 1
    j = rev(w, n)
    if j == w or j == w ^ U:
        return 2
    return 3


CLASS_PERIOD = {1: 6, 2: 132, 3: 43_155_322}


def class_counts_formula(n: int):
    r2 = (1 << (n // 2 + 1)) - 2 if n % 2 == 0 else (1 << ((n + 1) // 2)) - 2
    r3 = (1 << n) - (1 << ((n + 2) // 2))
    return 2, r2, r3


def carrier_span(w0: int, n: int):
    """K(w0) = span{u, w0, J(w0)}   (3.3)."""
    gens = [umask(n), w0, rev(w0, n)]
    span = {0}
    for g in gens:
        span |= {s ^ g for s in span}
    return sorted(span)


def step(p: int, w: int, D: dict, n: int, Pt=None):
    """One step (3.1), in place on D.  Returns (p', w', d, x)."""
    d = D.get(p, 0)
    x = d ^ w
    w2 = int(Pt[x]) if Pt is not None else partner(x, n)
    nv = d ^ w2
    if nv:
        D[p] = nv
    else:
        D.pop(p, None)
    return p ^ x, w2, d, x


def unstep(p: int, w: int, D: dict, n: int, Pt=None):
    """Exact inverse (3.2), in place on D.  Returns (p_prev, w_prev)."""
    x = int(Pt[w]) if Pt is not None else partner(w, n)
    p0 = p ^ x
    nv = D.get(p0, 0) ^ w
    if nv:
        D[p0] = nv
    else:
        D.pop(p0, None)
    return p0, x ^ D.get(p0, 0)


def run_reader(n: int, p0: int, w0: int, T: int, D0=None, record=True):
    """Run the single reader from (p0, w0, D0) for T ticks.  Returns the trace (one row per tick)
    and the final state.  Each row: t, p, w, d, x, w_next, kept (cells nonzero before the step)."""
    Pt = [int(v) for v in partner_table(n)] if n <= 20 else None
    D = dict(D0 or {})
    p, w = p0, w0
    rows = []
    for t in range(T):
        kept = len(D)
        p2, w2, d, x = step(p, w, D, n, Pt)
        if record:
            rows.append(dict(t=t, p=p, w=w, d=d, x=x, w_next=w2, kept=kept))
        p, w = p2, w2
    return rows, (p, w, D)


def period_from_empty(n: int, w0: int, p0: int = 0, max_ticks: int = 1_000_000):
    Pt = [int(v) for v in partner_table(n)]
    D = {}
    p, w = p0, w0
    for t in range(1, max_ticks + 1):
        p, w, _, _ = step(p, w, D, n, Pt)
        if p == p0 and w == w0 and not D:
            return t
    return None


def switch_tape(W):
    T = len(W)
    return [W[t] ^ W[(t + 1) % T] ^ W[(t + 2) % T] for t in range(T)]


def _gf2_mulmod(a: int, b: int, T: int) -> int:
    """(a * b) mod (z^T + 1) over GF(2); polynomials as bit masks."""
    r = 0
    while b:
        if b & 1:
            r ^= a
        b >>= 1
        a <<= 1
        if a >> T & 1:
            a ^= (1 << T) | 1
    return r


def _gf2_inv_q(T: int):
    """Inverse of 1 + z + z^2 modulo z^T + 1 over GF(2), or None (exactly when 3 | T)."""
    # extended Euclid in GF(2)[z]
    def deg(a):
        return a.bit_length() - 1
    def divmod2(a, b):
        q = 0
        db = deg(b)
        while a and deg(a) >= db:
            s = deg(a) - db
            q ^= 1 << s
            a ^= b << s
        return q, a
    def mul(a, b):
        r = 0
        while b:
            if b & 1:
                r ^= a
            b >>= 1
            a <<= 1
        return r
    m = (1 << T) | 1
    q0 = 0b111 if T > 2 else None
    if q0 is None:
        # tiny periods: reduce 1+z+z^2 mod z^T+1 first
        q0 = 0b111
        _, q0 = divmod2(q0, m)
    r0, r1 = m, q0
    s0, s1 = 0, 1
    while r1:
        qq, rr = divmod2(r0, r1)
        r0, r1 = r1, rr
        s0, s1 = s1, s0 ^ mul(qq, s1)
    if r0 != 1:
        return None
    _, inv = divmod2(s0, m)
    return inv


def q_invertible(T: int) -> bool:
    return _gf2_inv_q(T) is not None


def rebuild_from_tape(q, seed=None, n=None):
    """Rebuild the carry stream from the switch tape.  3 does not divide T: from the tape alone
    (w = Q_T^{-1} q).  3 | T: from the tape plus one seed word, w1 = P(w0)   (4.9)-(4.11)."""
    T = len(q)
    inv = _gf2_inv_q(T)
    if inv is not None:
        supp = [j for j in range(T) if inv >> j & 1]
        return [_xor_all(q[(t + j) % T] for j in supp) for t in range(T)]
    if seed is None or n is None:
        raise ValueError("3 | T: the tape needs the seed carry (and the width)")
    w = [seed, partner(seed, n)]
    for t in range(T - 2):
        w.append(q[t] ^ w[t] ^ w[t + 1])
    return w


def _xor_all(it):
    r = 0
    for v in it:
        r ^= v
    return r


def rebuild_route(Wc, p0: int, n: int):
    """Positions and field from the carry stream (4.10): x_t = P(w_{t+1}), p_{t+1} = p_t xor x_t,
    D_{t+1}[p_t] = D_t[p_t] xor w_{t+1}."""
    T = len(Wc)
    p = p0
    D = {}
    ps = [p]
    for t in range(T):
        wn = Wc[(t + 1) % T]
        x = partner(wn, n)
        D[p] = D.get(p, 0) ^ wn
        if not D[p]:
            del D[p]
        p ^= x
        ps.append(p)
    return ps, D


# ---- the eight-word carrier (bit0 = eR, bit1 = eL, bit2 = u)  — fast path for long runs ----

P8 = [(x ^ 3) if ((x ^ (x >> 1)) & 1) else (x ^ 4) for x in range(8)]


def run_carrier(seed_w: int, ticks: int, observe=None):
    """Eight-word carrier step on a 24-bit packed field (identical to nexus_suite.c step8).
    observe(t, p, w, d, x, D) is called before each step when given.  Returns final (p, w, D)."""
    p, w, D = 0, seed_w, 0
    P = P8
    for t in range(ticks):
        sh = 3 * p
        d = (D >> sh) & 7
        x = d ^ w
        if observe is not None:
            observe(t, p, w, d, x, D)
        w2 = P[x]
        D ^= w2 << sh
        p ^= x
        w = w2
    return p, w, D


def carrier_period(seed_w: int, max_ticks: int = 50_000_000):
    """Return (period, empty-field ticks) for a carrier seed from the empty field.  R3 (seed eR = 1):
    43,155,322 ticks; pure Python takes roughly half a minute to a few minutes."""
    p, w, D = 0, seed_w, 0
    P = P8
    vac = []
    for t in range(1, max_ticks + 1):
        sh = 3 * p
        d = (D >> sh) & 7
        x = d ^ w
        w2 = P[x]
        D ^= w2 << sh
        p ^= x
        w = w2
        if D == 0:
            vac.append(t)
            if p == 0 and w == seed_w:
                return t, vac
    return None, vac


# ----------------------------------------------------------------------------------------
# 8. Collision on the two-shell carrier (bit0 eR, bit1 eL, bit2 oR, bit3 oL, bit4 u)
# ----------------------------------------------------------------------------------------

def J5(x: int) -> int:
    return (x & 16) | ((x & 1) << 1) | ((x >> 1) & 1) | ((x & 4) << 1) | ((x >> 1) & 4)


def P5(x: int) -> int:
    j = J5(x)
    return x ^ 16 if j == x else j


def l0(x: int) -> int:
    return (x ^ (x >> 1)) & 1


def l1(x: int) -> int:
    return ((x >> 2) ^ (x >> 3)) & 1


def A5(x: int) -> int:
    return J5(x) ^ ((l0(x) ^ l1(x)) << 4)


def lamp_det(a: int, b: int) -> int:
    return (l0(a) & l1(b)) ^ (l1(a) & l0(b))


FIX0 = (0, 15, 16, 31)
FIX1 = (5, 10, 21, 26)


class Joint:
    """m readers on one shared field of 32 cells; the atomic order-free step (5.1)."""

    def __init__(self, readers, D=None):
        self.p = [int(a) for a, _ in readers]
        self.w = [int(b) for _, b in readers]
        self.D = list(D) if D is not None else [0] * 32

    def copy(self):
        j = Joint([(0, 0)])
        j.p, j.w, j.D = list(self.p), list(self.w), list(self.D)
        return j

    def step(self):
        m = len(self.p)
        x = [self.D[self.p[i]] ^ self.w[i] for i in range(m)]
        o = [P5(v) for v in x]
        for i in range(m):
            self.D[self.p[i]] ^= o[i]
        for i in range(m):
            self.p[i] ^= x[i]
            self.w[i] = o[i]
        return x

    def back(self):
        m = len(self.p)
        x = [P5(self.w[i]) for i in range(m)]
        q = [self.p[i] ^ x[i] for i in range(m)]
        for i in range(m):
            self.D[q[i]] ^= self.w[i]
        for i in range(m):
            self.w[i] = x[i] ^ self.D[q[i]]
            self.p[i] = q[i]

    def charge(self) -> int:
        b = 0
        for v in self.D:
            b ^= v
        r = 0
        for v in self.p:
            r ^= v
        return b ^ A5(r)

    def state(self):
        return (tuple(self.p), tuple(self.w), tuple(self.D))


def port_trace(C=(4, 7), ticks=3):
    """Shared Start A = (0, eR), B = (0, oR) with a third reader C; returns rows and inverse check."""
    j = Joint([(0, 1), (0, 4), C])
    s0 = j.state()
    rows = [dict(t=0, A=(j.p[0], j.w[0]), B=(j.p[1], j.w[1]), C=(j.p[2], j.w[2]), D=list(j.D))]
    for t in range(1, ticks + 1):
        j.step()
        rows.append(dict(t=t, A=(j.p[0], j.w[0]), B=(j.p[1], j.w[1]), C=(j.p[2], j.w[2]), D=list(j.D)))
    for _ in range(ticks):
        j.back()
    return rows, j.state() == s0


def derive_port(target: int, land_tick: int, base=((0, 1), (0, 4))):
    """Reverse the gap: land reader A on `target` at tick `land_tick` with one third reader.
    destination -> required read -> required deposit -> depositor's prior state (6.1, 5.9).
    The derivation is sealed before the forward run; the run then reports where A landed."""
    T = land_tick
    if T < 3:
        raise ValueError("landing tick >= 3 (the depositor needs one tick to arrive and one to write)")
    j = Joint(list(base))
    hist = [j.copy()]
    for _ in range(T - 1):
        j.step()
        hist.append(j.copy())
    sA = hist[T - 1]                      # state before A's landing step
    c = sA.p[0]
    x_need = c ^ target
    d_need = x_need ^ sA.w[0]
    s2 = hist[T - 2]
    others = 0
    for i in range(len(s2.p)):
        if s2.p[i] == c:
            others ^= P5(s2.D[c] ^ s2.w[i])
    delta = s2.D[c] ^ d_need ^ others      # what the depositor must write at cell c on tick T-2
    xC = P5(delta)
    wC = s2.D[c] ^ xC                      # depositor's carry when it stands on c at tick T-2
    pC, w = c, wC
    for k in range(T - 2, 0, -1):          # step the depositor back alone through the base field
        sk = hist[k - 1]
        x = P5(w)
        pC = pC ^ x
        w = x ^ sk.D[pC]
    seed = (pC, w)
    seal = hashlib.sha256(("port target=%d tick=%d seed=%s" % (target, T, seed)).encode()).hexdigest()
    jj = Joint(list(base) + [seed])
    for _ in range(T):
        jj.step()
    return dict(seed=seed, seal=seal, landed=jj.p[0], ok=jj.p[0] == target, cell=c, deposit=d_need)


# ----------------------------------------------------------------------------------------
# 9. Read models
# ----------------------------------------------------------------------------------------

WT4 = [0, 1, 1, 2, 2, 3, 3, 4]       # carrier basis a = eR, b = eL, v = u xor s at width 4


def A0_basis(z: int) -> int:
    return z ^ 7 if ((z ^ (z >> 1)) & 1) else z


def two_sheet_d2(x: int, y: int, n: int = 4) -> Fraction:
    """d*^2 = (wt(z) + wt(A0 z)) / 2 on the carrier, block weights (1, 1, n-2)   (7.5)."""
    def wtn(z):
        return (z & 1) + ((z >> 1) & 1) + ((z >> 2) & 1) * (n - 2)
    z = x ^ y
    return Fraction(wtn(z) + wtn(A0_basis(z)), 2)


def psi_oct(p: int, w: int, d: int) -> int:
    """Psi_oct (7.7): a = 1, b = 2, v = 4 in the carrier basis."""
    return (p * 1) ^ ((p ^ w) * 2) ^ ((p ^ w ^ d ^ 1) * 4)


JOHNSON = [(0, 0, 0), (0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 0, 1), (1, 0, 0)]   # Z_t = (p, p^w, p^w^d)


def sign_registers():
    """The bare sign's registers (p, w, d) per tick, reading 0, u as 0, 1 (R1 from carry 0, empty field)."""
    regs = []
    run_carrier(0, 6, observe=lambda t, p, w, d, x, D: regs.append((int(p != 0), int(w != 0), int(d != 0))))
    return regs


def step_triangle(d: int, w: int):
    """Sides d, w, x = d xor w; squared Euclidean lengths are Hamming weights (7.3)."""
    x = d ^ w
    if not d or not w or not x:
        return "collapsed"
    if not (d & w) or not (d & x) or not (w & x):
        return "right"
    return "acute"


# ----------------------------------------------------------------------------------------
# 10. Small utilities
# ----------------------------------------------------------------------------------------

def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def pi_fixed(prec: int) -> int:
    """floor(pi * 2^prec) by Machin's formula (exact integer arithmetic, small guard)."""
    g = prec + 32
    def arctan_inv(k):
        s, t, i, sign = 0, (1 << g) // k, 1, 1
        k2 = k * k
        while t:
            s += sign * (t // i)
            t //= k2
            i += 2
            sign = -sign
        return s
    return (4 * (4 * arctan_inv(5) - arctan_inv(239))) >> 32


def pi_fraction_bits(n: int = 64) -> int:
    """The first n bits of pi after the binary point: pi = 11.0010 0100 0011 1111 ...  (0x243F6A88...)."""
    return pi_fixed(n) - (3 << n)


# ---- R3 full pass on the eight-word carrier (period, empty fields, census, mean kept field) ----

_K12 = [sum(1 for c in range(4) if (v >> (3 * c)) & 7) for v in range(4096)]


def r3_full_pass(seed_w: int = 1, max_ticks: int = 50_000_000):
    """One pass over the two-lap closure from (0, eR, empty).  Returns period, empty-field ticks,
    the (d, w) pair counts (for the step-triangle census) and the mean kept field.
    Pure Python: about 10-25 seconds."""
    p, w, D = 0, seed_w, 0
    P = P8
    K = _K12
    pairs = [0] * 64
    kept = 0
    vac = []
    t = 0
    while t < max_ticks:
        sh = 3 * p
        d = (D >> sh) & 7
        pairs[(d << 3) | w] += 1
        kept += K[D & 4095] + K[D >> 12]
        x = d ^ w
        w2 = P[x]
        D ^= w2 << sh
        p ^= x
        w = w2
        t += 1
        if D == 0:
            vac.append(t)
            if p == 0 and w == seed_w:
                break
    return dict(period=t, vacuum=vac, pairs=pairs, mean_kept=kept / t)


def blocks8(x: int):
    """Carrier word -> block indicator (eR, eL, v = u xor s) used for widths n >= 4."""
    a, b, c = x & 1, (x >> 1) & 1, (x >> 2) & 1
    return (a ^ c, b ^ c, c)


def census_from_pairs(pairs, n: int):
    """Step-triangle census at width n from the (d, w) counts of the carrier run (7.2, 7.4)."""
    def wtn(z):
        a, b, v = blocks8(z)
        return a + b + v * (n - 2)
    out = Counter()
    for d in range(8):
        for w in range(8):
            c = pairs[(d << 3) | w]
            if not c:
                continue
            x = d ^ w
            if not d or not w or not x:
                out["collapsed"] += c
                continue
            bd, bw, bx = blocks8(d), blocks8(w), blocks8(x)
            dis = lambda s, t: not any(i & j for i, j in zip(s, t))
            right = dis(bd, bw) or dis(bd, bx) or dis(bw, bx)
            out["right" if right else "acute"] += c
            out["real"] += c
            key = tuple(sorted((wtn(d), wtn(w), wtn(x))))
            out[key] += c
    return out


def half_lap_check(seed_w: int = 1, half: int = 21_577_661):
    """Second lap = G(first lap): positions A0 then xor u, carries A0, cells A0 at A0(q) xor u  (4.3-4.4).
    Runs both laps side by side; about 15-30 seconds in pure Python."""
    A0 = [z ^ 4 if ((z ^ (z >> 1)) & 1) else z for z in range(8)]
    P = P8
    pa, wa, Da = 0, seed_w, 0
    pb, wb, Db = run_carrier(seed_w, half)
    mism = 0
    for _ in range(half):
        if pb != (A0[pa] ^ 4) or wb != A0[wa]:
            mism += 1
        sh = 3 * pa
        d = (Da >> sh) & 7
        x = d ^ wa
        w2 = P[x]
        Da ^= w2 << sh
        pa ^= x
        wa = w2
        sh = 3 * pb
        d = (Db >> sh) & 7
        x = d ^ wb
        w2 = P[x]
        Db ^= w2 << sh
        pb ^= x
        wb = w2
    return mism
