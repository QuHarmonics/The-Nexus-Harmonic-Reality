# The NEXUS Ring Atlas

An executable observatory of the native binary rings, from one bit to the retained continuation domain.

Dean A. Kulik · QuHarmonics Research Group · ORCID 0009-0003-3128-8828 · November 2026

## Open it

1. Open `NEXUS_Ring_Atlas.ipynb` in JupyterLab, Jupyter Notebook 7, VS Code or Google Colab.
2. Run **Restart Kernel and Run All**. The first cell installs any missing package (`numpy`, `plotly`, `ipywidgets`, `pillow`).
3. With `RUN_LONG = True` (the default) the notebook takes about two minutes: the two-lap closure runs in full, 43,155,322 ticks, in pure Python. Set it to `False` for a quick pass.

The notebook is self-contained: the four engine modules are embedded in it. The copies in `engine/` are the same files, for running the mathematics without a notebook:

```
cd engine
python -c "import ring_lab as l; r = l.run(include_long=False); print(sum(x['ok'] for x in r), 'of', len(r), 'checks run and landed')"
```

## Layers

| module | what it holds | depends on |
|---|---|---|
| `ring_core.py` | the mathematics: partner, ring, exact address, readers, Möbius bridge, clock, reader–field machine, collision, ports, read models | numpy |
| `ring_lab.py` | the proof laboratory: sealed expectation table, every check with scope, the source manifest | ring_core |
| `ring_viz.py` | the dark visual layer (Plotly) | ring_core |
| `ring_ui.py` | the explorers (ipywidgets): word inspector, ring explorer, the Ring Reader, clock explorer, port lab | all of the above |

The mathematics never depends on the graphics: `ring_core` and `ring_lab` run with no plotting library installed.

## Status words

STANDS (proved, or supplied by a cited theorem) · RUNS (executed and landed inside its stated scope) · OPEN (the shape of the missing link is fixed) · PULL (a reading at a physical location, held as a comparator) · ELSEWHERE (the computation ran and landed; the landing belongs to the named owner).

## Output

Running the laboratory (Chapter 14) writes `nexus_ring_atlas_report.json` beside the notebook: the SHA-256 seal of the expectation table, every check with its scope, expected and actual values, and timing.
