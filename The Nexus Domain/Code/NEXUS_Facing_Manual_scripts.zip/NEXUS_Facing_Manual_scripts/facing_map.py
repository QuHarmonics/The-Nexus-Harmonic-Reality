"""Map the facing relation and its compositions across LEN. Interface side only: no values, no outside data.

face(w): read w backward; if that changes nothing (palindrome), take its NOT.
IN(w) = all but the last bit (interface contact), OUT(w) = all but the first bit (implementation contact).
"""
import itertools, math
import numpy as np

def words(L): return [tuple(b) for b in itertools.product((0, 1), repeat=L)]
rev = lambda w: w[::-1]
neg = lambda w: tuple(1 - b for b in w)
pal = lambda w: rev(w) == w
def face(w):
    r = rev(w)
    return r if r != w else neg(w)
IN = lambda w: w[:-1]
OUT = lambda w: w[1:]
def alternating(L): return {tuple((i + s) % 2 for i in range(L)) for s in (0, 1)}
def constant(L): return {(0,) * L, (1,) * L}

print('LEN  facing pairs  NOT-faced  NOT share | ordered chains of a contact with its partner -> LEN+1')
print('                                         |  from direction pairs   from NOT pairs   self-closing pairs')
for L in range(1, 15):
    W = words(L)
    assert all(face(face(w)) == w and face(w) != w for w in W)               # fixed-point-free involution
    npal = sum(pal(w) for w in W)
    assert npal == 2 ** math.ceil(L / 2)
    if L >= 2:                                                                # what facing does to the two contacts
        for w in W:
            p = face(w)
            if pal(w): assert IN(p) == neg(IN(w)) and OUT(p) == neg(OUT(w))  # NOT-faced: both ends negated
            else:      assert IN(p) == rev(OUT(w)) and OUT(p) == rev(IN(w))  # direction-faced: interface <-> implementation
    pairs = {frozenset((w, face(w))) for w in W}
    dchains, nchains, closers = [], [], []
    for pr in pairs:
        a, b = sorted(pr)
        hits = [x + (y[-1],) for x, y in ((a, b), (b, a)) if OUT(x) == IN(y)]
        (nchains if pal(a) else dchains).extend(hits)
        if len(hits) == 2: closers.append(a)
    # direction pairs chain exactly into the non-constant palindromes one level up, each exactly once
    assert sorted(dchains) == sorted(set(w for w in words(L + 1) if pal(w)) - constant(L + 1))
    # NOT pairs chain only on the alternating contact (odd LEN), into the alternating words one level up
    assert set(nchains) == (alternating(L + 1) if L % 2 == 1 else set()) and len(nchains) == len(set(nchains))
    for c in nchains: assert rev(c) == neg(c)                                  # backward reading = NOT
    # the only pair that closes into a ring by itself is the alternating one
    assert len(closers) == 1 and closers[0] in alternating(L)
    print(f'{L:3d}  {len(pairs):12d}  {npal // 2:9d}  {npal / 2 ** L:8.4f} | {len(dchains):14d}   {len(nchains):14d}   {len(closers):10d} (alternating)')
print('all identities hold for LEN 1-14')

# The register that pairs every contact with its own backward reading: sum over x of |x>|rev x>.
# It is the equal superposition of all palindromes. Read it out in order and record what has left.
def palindrome_state(n):
    v = np.zeros(2 ** n)
    for w in words(n):
        if pal(w): v[int(''.join(map(str, w)), 2)] = 1.0
    return v / np.linalg.norm(v)
def ent_bits(v, n, k):
    if k in (0, n): return 0.0
    s = np.linalg.svd(v.reshape(2 ** k, 2 ** (n - k)), compute_uv=False) ** 2
    s = s[s > 1e-14]
    return float(-(s * np.log2(s)).sum())
def page_bits(n, k):                                   # Page (1993) average over random pure states
    a, b = sorted((2 ** k, 2 ** (n - k)))
    return (sum(1.0 / j for j in range(b + 1, a * b + 1)) - (a - 1) / (2 * b)) / math.log(2)
for n in (12, 13):
    v = palindrome_state(n)
    S = [ent_bits(v, n, k) for k in range(n + 1)]
    assert all(abs(S[k] - min(k, n - k)) < 1e-9 for k in range(n + 1))   # min(k, n-k), even and odd n
    print(f'\nn = {n}: bits shared between the read-out part (first k) and the rest')
    print('  k      ' + ' '.join(f'{k:5d}' for k in range(n + 1)))
    print('  ring   ' + ' '.join(f'{x:5.2f}' for x in S))
    print('  random ' + ' '.join(f'{page_bits(n, k):5.2f}' for k in range(n + 1)))
np.save('S12.npy',
        np.array([[ent_bits(palindrome_state(12), 12, k), page_bits(12, k)] for k in range(13)]))
