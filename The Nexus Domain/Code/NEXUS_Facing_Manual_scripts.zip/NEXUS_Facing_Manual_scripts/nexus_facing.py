#!/usr/bin/env python3
"""Facing, composition and the center in native binary rings: reference implementation.

Dean A. Kulik, QuHarmonics Research Group (ORCID 0009-0003-3128-8828), 5 November 2026.
Standard library only. A word is a tuple of bits, position 0 on the left.
Run:  python3 nexus_facing.py   (about half a minute; every check is exhaustive in its range)
"""
from itertools import product
from math import ceil


# ------------------------------------------------------------------ types and operators
def words(n):
    return [tuple(w) for w in product((0, 1), repeat=n)]

def J(w):            return w[::-1]                      # read backward (reversal)
def C(w):            return tuple(1 - b for b in w)      # NOT every bit (complement)
def is_pal(w):       return J(w) == w                    # reads the same both ways
def P(w):            return C(w) if is_pal(w) else J(w)  # facing (native partner)
def facing_type(w):  return 'NOT' if is_pal(w) else 'direction'
def IN(e):           return e[:-1]                       # offset model: face received
def OUT(e):          return e[1:]                        # offset model: face handed on
def chains(e, f):    return OUT(e) == IN(f)
def chain(e, f):     return e + f[-1:]


# ------------------------------------------------------------------ native ring
def native_ring(n):
    """Native Binary Rings, eqs. 2-4: representatives in order, seam, partners mirrored."""
    reps = sorted(w for w in words(n) if w < P(w))       # smaller member of each pair
    tail = [P(w) for w in reversed(reps[:-1])]
    return reps[:-1] + [P(reps[-1]), reps[-1]] + tail


# ------------------------------------------------------------------ §181 model: a->b->c is a|b|b|c
def whole_face(a, b, c):
    n = len(a)
    F = P(a + b + b + c)
    return F[:n], F[n:2 * n], F[2 * n:3 * n], F[3 * n:]

def parts_face(a, b, c):
    """Face each transition separately, then reverse their order."""
    n = len(a)
    PU, PV = P(a + b), P(b + c)
    return PV[:n], PV[n:], PU[:n], PU[n:]


# ------------------------------------------------------------------ the center
def word_center(n):
    """Odd LEN: the middle position. Even LEN: None (a seam between n/2-1 and n/2)."""
    return (n - 1) // 2 if n % 2 else None

def ring_seam(n):
    R = native_ring(n)
    m = len(R) // 2
    return R[m - 1], R[m]


# ------------------------------------------------------------------ self-test
def check(label, ok):
    print(f'  {"PASS" if ok else "FAIL"}  {label}')
    assert ok

def test_facing():
    check('facing is a fixed-point-free involution, LEN 1-12',
          all(P(P(w)) == w and P(w) != w for n in range(1, 13) for w in words(n)))
    ok = True
    for n in range(2, 13):
        R = native_ring(n)
        ok &= all(R[2 ** n - 1 - a] == P(R[a]) for a in range(2 ** n))
    check('native ring address law R[N-1-a] = P(R[a]), n = 2-12', ok)
    ok = True
    for n in range(1, 12):
        for e in words(n + 1):
            p = P(e)
            if is_pal(e):
                ok &= (IN(p), OUT(p)) == (C(IN(e)), C(OUT(e)))
            else:
                ok &= (IN(p), OUT(p)) == (J(OUT(e)), J(IN(e)))
    check('exchange: direction-faced partner has IN = J(OUT), OUT = J(IN); '
          'NOT-faced negates both, LEN 2-12', ok)
    check('NOT faces a share 2^(ceil(n/2)-n) of contacts, LEN 1-12',
          all(sum(map(is_pal, words(n))) == 2 ** ceil(n / 2) for n in range(1, 13)))

def test_composition():
    ok = True
    for L in range(1, 12):
        pairs = {frozenset((w, P(w))) for w in words(L)}
        dch, nch, closers = [], [], 0
        for pr in pairs:
            a, b = sorted(pr)
            hits = [chain(x, y) for x, y in ((a, b), (b, a)) if chains(x, y)]
            (nch if is_pal(a) else dch).extend(hits)
            closers += len(hits) == 2
        const = {(0,) * (L + 1), (1,) * (L + 1)}
        nonconst_pal = {w for w in words(L + 1) if is_pal(w)} - const
        alt = {tuple((i + s) % 2 for i in range(L + 1)) for s in (0, 1)}
        ok &= sorted(dch) == sorted(nonconst_pal)
        ok &= set(nch) == (alt if L % 2 else set()) and closers == 1
    check('a contact chained with its own backward reading reads the same both ways; '
          'one-to-one with non-constant palindromes one level up; NOT pairs chain only '
          'on the alternating word; one self-closing pair, LEN 1-11', ok)
    ok = True
    for n in range(2, 5):
        N, r = 2 ** n, 2 ** ceil(n / 2)
        seams = breaks = lone = differ = 0
        for a, b, c in product(words(n), repeat=3):
            wf, pf = whole_face(a, b, c), parts_face(a, b, c)
            sW, sU, sV = is_pal(a + b + b + c), is_pal(a + b), is_pal(b + c)
            ok &= wf[1] == wf[2] and sW == (a == J(c) and b == J(b))
            ok &= (pf[1] == pf[2]) == (sU == sV)
            seams += sW
            breaks += pf[1] != pf[2]
            lone += sW and not sU and not sV
            differ += pf != wf
        expected = (r * N, 2 * N * (N - 1), r * (N - 1), 2 * N * (N - 1) + r * (N - 1) + N - r)
        ok &= (seams, breaks, lone, differ) == expected
    check('whole versus parts (§181 model): whole facing keeps the middle matched; parts '
          'compose iff their facing types agree; counts rN, 2N(N-1), r(N-1), '
          '2N(N-1)+r(N-1)+N-r, n = 2-4', ok)
    ok = all(chains(P(OUT(c)), P(IN(c))) == (is_pal(IN(c)) == is_pal(OUT(c)))
             for L in range(2, 12) for c in words(L + 1))
    check('whole versus parts (offset model): faced parts chain iff their facing types '
          'agree, LEN 2-11', ok)

def test_center():
    ok = True
    for n in range(1, 14, 2):
        k = word_center(n)
        pals = [w for w in words(n) if is_pal(w)]
        ok &= sum(w[k] for w in pals) == len(pals) // 2            # the center is free
        flip = lambda w: w[:k] + (1 - w[k],) + w[k + 1:]
        ok &= all(is_pal(w) == is_pal(flip(w)) for w in words(n))  # and outside the selector
    check('odd LEN: the center is free (0 or 1) and never enters the facing selector; '
          'even LEN: a seam, LEN 1-13', ok)
    ok = True
    for n in range(2, 13):
        left, right = ring_seam(n)
        rstar = (1,) * (n // 2 - 1) + (0,) + (1,) * (n - n // 2)
        edge = left + right
        ok &= right == rstar and left == J(rstar) and is_pal(edge) and P(edge) == C(edge)
    check('ring center: the seam holds J(r*) | r*, r* all ones with one 0 just left of '
          'center; the edge across it reads the same both ways and is faced by NOT, '
          'n = 2-12', ok)

def test_count():
    ok = True
    for n in range(1, 11):
        ok &= len({P(w) for w in words(n)}) == 2 ** n
        ok &= all(sum(1 for e in words(n + 1) if IN(e) == f) == 2 for f in words(n))
    check('facing keeps the count; the offset maps two contacts onto each face '
          '(one bit per LEN step), LEN 1-10', ok)

def main():
    print('Native binary ring facing: self-test')
    test_facing()
    test_composition()
    test_center()
    test_count()
    print('ALL CHECKS PASS')


if __name__ == '__main__':
    main()
