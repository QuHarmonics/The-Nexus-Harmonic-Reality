"""Audit for the facing manual. Interface side only: every statement is checked on every word in range.

A  native ring R_n (Dean's construction) and its address law, n = 2..14; the center of the ring
B  whole versus parts, juxtaposition model (§181: transition x->y is the 2n-bit word x|y), n = 2..6
C  whole versus parts, offset model (contact of LEN L+1 runs IN -> OUT), L = 1..14
D  the center of a word: odd/even LEN, free bit, partner after one offset, quantum center state
E  native successor facing exceptions (§181 section B), n = 2..12
"""
import math
import numpy as np

from ringops import J, C, pal, P, native_ring, b

print('A  native ring: address law R[N-1-a] = P(R[a]); the ring center')
for n in range(2, 15):
    R = native_ring(n); N = 1 << n; m = N // 2
    assert all(R[N - 1 - a] == P(R[a], n) for a in range(N))
    assert not any(a == N - 1 - a for a in range(N))                       # no address is its own mirror
    s0, s1 = R[m - 1], R[m]
    assert P(s0, n) == s1                                                  # the seam holds one facing pair
    kind = 'NOT-faced' if pal(s1, n) else 'direction-faced'
    if n <= 6 or n == 14:
        print(f'  n={n:2d}  law holds on all {N} addresses; seam R[{m-1}] | R[{m}] = {b(s0, n)} | {b(s1, n)}  ({kind})')
print('  R_2 =', ' | '.join(b(x, 2) for x in native_ring(2)), '   R_3 =', ' | '.join(b(x, 3) for x in native_ring(3)))

print('\nB  juxtaposition model: path a->b->c is W = a|b|b|c (LEN 4n)')
print('   n   paths   whole seams  rN   parts break  2N(N-1)  seam without lower seam  r(N-1)  whole != parts  formula')
for n in range(2, 7):
    N = 1 << n; r = 2 ** math.ceil(n / 2); mask = N - 1
    seams = breaks = lone = differ = 0
    for a in range(N):
        for bb in range(N):
            U = (a << n) | bb
            sU = pal(U, 2 * n); PU = P(U, 2 * n)
            for c in range(N):
                W = (a << 3 * n) | (bb << 2 * n) | (bb << n) | c
                PW = P(W, 4 * n)
                assert (PW >> 2 * n) & mask == (PW >> n) & mask              # whole facing keeps the middle matched
                sW = pal(W, 4 * n)
                assert sW == (a == J(c, n) and bb == J(bb, n))               # collective selector
                V = (bb << n) | c
                sV = pal(V, 2 * n); PV = P(V, 2 * n)
                ok = (PV & mask) == (PU >> n)                                # parts faced separately, order reversed
                assert ok == (sU == sV)
                parts = (PV << 2 * n) | PU
                seams += sW; breaks += not ok; lone += sW and not sU and not sV; differ += parts != PW
    assert seams == r * N and breaks == 2 * N * (N - 1) and lone == r * (N - 1)
    assert differ == 2 * N * (N - 1) + r * (N - 1) + (N - r)
    print(f'  {n:2d}  {N**3:7d}  {seams:11d}  {r*N:4d}  {breaks:11d}  {2*N*(N-1):7d}  {lone:22d}  {r*(N-1):6d}  {differ:14d}  {2*N*N-N+r*N-2*r:7d}')

print('\nC  offset model: contact c of LEN L+1 runs x = IN(c) -> y = OUT(c); parts faced separately, order reversed')
print('   L  contacts  parts break  4r-2b  whole reads same both ways, parts do not  r(L+1)-2  whole != parts')
for L in range(1, 15):
    rL = 2 ** math.ceil(L / 2); both = 4 if L % 2 else 2
    breaks = seams = differ = 0
    for c in range(1 << (L + 1)):
        x, y = c >> 1, c & ((1 << L) - 1)
        px, py = P(x, L), P(y, L)
        ok = (py & ((1 << (L - 1)) - 1)) == (px >> 1) if L > 1 else True
        assert ok == (pal(x, L) == pal(y, L))
        whole = P(c, L + 1)
        partsword = ((py << 1) | (px & 1)) if ok else None
        breaks += not ok
        seams += pal(c, L + 1) and not pal(x, L) and not pal(y, L)
        differ += partsword != whole
    assert breaks == 4 * rL - 2 * both and seams == 2 ** math.ceil((L + 1) / 2) - 2
    print(f'  {L:2d}  {1 << (L + 1):8d}  {breaks:11d}  {4*rL-2*both:5d}  {seams:41d}  {2**math.ceil((L+1)/2)-2:8d}  {differ:14d}')

print('\nD  the center of a word')
for L in range(1, 16):
    fixed = [i for i in range(L) if i == L - 1 - i]
    assert len(fixed) == (L % 2)
    if L % 2:
        k = L // 2
        c0 = sum(1 for x in range(1 << L) if pal(x, L) and not (x >> (L - 1 - k)) & 1)
        c1 = sum(1 for x in range(1 << L) if pal(x, L) and (x >> (L - 1 - k)) & 1)
        assert c0 == c1 == 2 ** k                                           # center free: 0 or 1
        assert (L + 1) - 1 - k == k + 1                                      # grown forward: partner is the bit after
        assert (L + 1) - 1 - (k + 1) == k                                    # grown backward: partner is the bit before (old k-1, shifted)
print('  odd LEN: exactly one position is its own mirror; palindromes split evenly on its value (0 or 1)')
print('  even LEN: no position is its own mirror; the center is the seam between the innermost pair')
print('  one offset later the odd center gains a partner: the bit after it (grown forward) or the bit before it (grown backward)')
def palreg(n):
    v = np.zeros(1 << n)
    for x in range(1 << n):
        if pal(x, n): v[x] = 1.0
    return v / np.linalg.norm(v)
def reduced(v, n, keep):
    t = v.reshape([2] * n); rest = [i for i in range(n) if i not in keep]
    t = np.transpose(t, keep + rest).reshape(2 ** len(keep), -1)
    return t @ t.T
Xop = np.array([[0, 1], [1, 0]]); Zop = np.diag([1, -1])
n = 13; rho = reduced(palreg(n), n, [6])
ev = np.linalg.eigvalsh(rho)
print(f'  register n={n}: center qubit rho = {np.round(rho, 6).tolist()}; <NOT> = {np.trace(rho @ Xop):.6f}; '
      f'<value> = {np.trace(rho @ Zop):.6f}; purity = {np.trace(rho @ rho):.6f}; entropy = {-sum(e*np.log2(e) for e in ev if e > 1e-12):.6f} bits')
n = 12; r5 = reduced(palreg(n), n, [5]); r56 = reduced(palreg(n), n, [5, 6])
e5 = np.linalg.eigvalsh(r5); e56 = np.linalg.eigvalsh(r56)
print(f'  register n={n}: innermost qubit alone entropy = {-sum(e*np.log2(e) for e in e5 if e > 1e-12):.6f} bits; '
      f'innermost pair together entropy = {-sum(e*np.log2(e) for e in e56 if e > 1e-12):.6f} bits')

print('\nE  native successor edges x->T(x) whose facing (in the 2n-bit table) is not a successor edge')
for n in range(2, 13):
    R = native_ring(n); N = 1 << n; loc = {v: i for i, v in enumerate(R)}
    bad = []
    for i, x in enumerate(R):
        y = R[(i + 1) % N]; f = P((x << n) | y, 2 * n); xp, yp = f >> n, f & (N - 1)
        if R[(loc[xp] + 1) % N] != yp: bad.append(i)
    pred = {i for i, x in enumerate(R) if pal(x, n) or pal(R[(i + 1) % N], n)} | {N // 2 - 1}
    assert len(bad) == 2 * 2 ** math.ceil(n / 2) and set(bad) == pred
print('  n = 2..12: exceptions = 2 * 2^ceil(n/2), exactly the edges touching a palindrome plus the seam edge')
print('\nALL ASSERTIONS PASS')
