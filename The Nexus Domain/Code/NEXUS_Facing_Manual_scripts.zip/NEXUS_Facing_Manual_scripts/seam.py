"""The ring's center: the two words at the seam and the edge across it."""
from ringops import J, C, P, pal, native_ring
for n in range(2, 17):
    R = native_ring(n); N = 1 << n; m = N // 2
    left, right = R[m - 1], R[m]
    k = n // 2 - 1
    rstar = ((1 << n) - 1) ^ (1 << (n - 1 - k))          # all ones, single 0 at index floor(n/2)-1 from the left
    assert right == rstar and left == J(rstar, n) and left == P(right, n)
    edge = (left << n) | right
    assert pal(edge, 2 * n) and P(edge, 2 * n) == C(edge, 2 * n)   # the edge across the center reads the same both ways
print('n = 2..16: seam = J(r*) | r*, r* = ones with one 0 just left of the word center; the edge across it is a 2n-bit palindrome, faced by NOT')
