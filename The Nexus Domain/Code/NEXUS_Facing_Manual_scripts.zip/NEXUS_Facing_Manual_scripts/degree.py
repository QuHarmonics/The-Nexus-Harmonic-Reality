"""Algebraic degree of the facing map P_n (max over output bits of the ANF degree), and where the center bit enters."""
import numpy as np
from ringops import P, pal
def anf_degree(bits, n):
    a = np.array(bits, dtype=np.uint8)
    for i in range(n):
        a = a.reshape(-1, 2, 1 << i); a[:, 1, :] ^= a[:, 0, :]; a = a.reshape(-1)
    w = np.array([bin(i).count('1') for i in range(1 << n)])
    nz = np.nonzero(a)[0]
    return int(w[nz].max()) if len(nz) else -1
for n in range(1, 13):
    tab = [P(x, n) for x in range(1 << n)]
    deg = max(anf_degree([(t >> b) & 1 for t in tab], n) for b in range(n))
    sel = anf_degree([int(pal(x, n)) for x in range(1 << n)], n)
    transl = all(tab[x] == x ^ ((1 << n) - 1) for x in range(1 << n))
    affine = all(tab[x ^ y ^ z] == tab[x] ^ tab[y] ^ tab[z] for x in range(1 << min(n, 6)) for y in range(1 << min(n, 6)) for z in (0, 1)) if n <= 6 else False
    center_free = True
    if n % 2:
        k = n // 2; bit = 1 << (n - 1 - k)
        center_free = all(pal(x, n) == pal(x ^ bit, n) for x in range(1 << n))
    print(f'n={n:2d}  facing degree {deg}  selector degree {sel}  floor(n/2)={n//2}  pure NOT (translation by 1^n): {transl}  affine: {affine if n<=6 else "no"}  center bit absent from selector: {center_free}')
