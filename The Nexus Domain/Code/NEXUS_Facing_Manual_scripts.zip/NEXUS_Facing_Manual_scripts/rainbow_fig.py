import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Arc

S = np.load('S12.npy')
n = 12
fig, (a1, a2) = plt.subplots(1, 2, figsize=(10.2, 3.5), dpi=220, gridspec_kw={'width_ratios': [1.3, 1]})

# left: every position paired with its mirror (bit i with bit n+1-i): the palindrome register
cols = plt.cm.Blues(np.linspace(0.95, 0.45, n // 2))
for i in range(1, n // 2 + 1):
    j = n + 1 - i
    a1.add_patch(Arc(((i + j) / 2, 0), j - i, (j - i) * 0.9, theta1=0, theta2=180, color=cols[i - 1], lw=2.2))
a1.scatter(range(1, n + 1), [0] * n, s=46, color='#1f3b63', zorder=3)
a1.axvline((n + 1) / 2, color='#b23a2e', lw=1.3, ls='--')
a1.text((n + 1) / 2, -1.25, 'center: the reading turns', ha='center', va='top', fontsize=8.5, color='#b23a2e',
        bbox=dict(facecolor='white', edgecolor='none', pad=2.0), zorder=4)
a1.text(3.5, -0.55, 'x', ha='center', fontsize=11, style='italic', color='#1f3b63')
a1.text(9.5, -0.55, 'x read backward', ha='center', fontsize=9, color='#1f3b63')
a1.set_xlim(0.2, n + 0.8); a1.set_ylim(-1.9, 5.7); a1.axis('off')
a1.set_title('every contact paired with its other reading', fontsize=9.5)

# right: read the register out in order; bits shared between what has left and what remains
k = np.arange(n + 1)
a2.plot(k, S[:, 0], color='#1f5fa8', lw=2, marker='o', ms=4, label='palindrome register')
a2.plot(k, S[:, 1], color='#7a7a7a', lw=1.3, ls='--', label='typical random state (Page)')
a2.axvline(n / 2, color='#b23a2e', lw=1.1, ls='--')
a2.set_xlabel('bits read out', fontsize=8.5); a2.set_ylabel('bits shared with what remains', fontsize=8.5)
a2.set_xticks(range(0, n + 1, 2)); a2.tick_params(labelsize=8)
for s in ('top', 'right'): a2.spines[s].set_visible(False)
a2.legend(fontsize=7.5, frameon=False, loc='upper right', bbox_to_anchor=(1.02, 1.12))
a2.text(2.6, 4.55, 'one face of\neach pair leaves', fontsize=7.5, ha='center', color='#444')
a2.text(9.4, 4.55, 'the other halves\nleave', fontsize=7.5, ha='center', color='#444')
fig.subplots_adjust(left=0.02, right=0.98, bottom=0.16, top=0.86, wspace=0.12)
fig.savefig('other_reading_register.png')
print('saved')
