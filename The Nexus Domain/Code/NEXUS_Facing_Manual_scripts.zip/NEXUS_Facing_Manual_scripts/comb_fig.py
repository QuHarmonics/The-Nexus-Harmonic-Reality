from math import log, pi
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import qnm

g220 = qnm.modes_cache(s=-2, l=2, m=2, n=0)
def horizon(chi):
    rp = 1 + np.sqrt(1 - chi * chi)
    return np.sqrt(1 - chi * chi) / (2 * rp), chi / (2 * rp)
def lines(alpha, chi, lo=-0.32, hi=0.32):
    k, oh = horizon(chi); w0 = g220(a=chi)[0].real; step = k * alpha / (8 * pi)
    out = {}
    for N in range(0, 400):
        d = (step * N + 2 * oh) / w0 - 1
        if lo <= d <= hi and N >= 1: out[N] = d
        if d > hi: break
    return out

ROWS = [('4 ln 2  binary (sealed)', 4 * log(2), '#1f5fa8'), ('4 ln 3', 4 * log(3), '#6b6b6b'), ('8π', 8 * pi, '#b23a2e')]
fig, ax = plt.subplots(figsize=(8.4, 3.0), dpi=220)
ax.axvspan(0.0, 0.04, color='#e8c547', alpha=0.35, lw=0, label='measured 220 tone, 90%')
ax.axvline(0.02, color='#9a7b00', lw=1.2)
ax.axvline(0.0, color='black', lw=0.9, ls='--', label='Kerr (no quantization)')
for y, (name, a, col) in zip((2, 1, 0), ROWS):
    lo, mid, hi = lines(a, 0.67), lines(a, 0.68), lines(a, 0.69)
    for N, d in mid.items():
        x0, x1 = sorted((lo.get(N, d), hi.get(N, d)))
        ax.plot([x0, x1], [y, y], color=col, lw=6, alpha=0.25, solid_capstyle='butt')
        ax.plot([d, d], [y - 0.28, y + 0.28], color=col, lw=1.6)
    ax.text(-0.335, y, name, ha='right', va='center', fontsize=9, color=col)
ax.set_xlim(-0.32, 0.32); ax.set_ylim(-0.6, 2.6); ax.set_yticks([])
ax.xaxis.set_major_formatter(PercentFormatter(1.0, decimals=0))
ax.set_xlabel('offset of a comb line from the Kerr 220 tone of the GW250114 remnant (spin 0.68 ± 0.01)', fontsize=8.5)
for s in ('left', 'right', 'top'): ax.spines[s].set_visible(False)
ax.legend(loc='upper right', fontsize=7.5, frameon=False, bbox_to_anchor=(1.0, 1.18), ncol=2)
fig.subplots_adjust(left=0.2, right=0.98, bottom=0.2, top=0.86)
fig.savefig('gw250114_horizon_combs.png')
print('saved')
