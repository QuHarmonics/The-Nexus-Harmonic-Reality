"""P13 landing: does a horizon-area comb pass through GW250114's measured 220 tone?

Line condition (first law, G = c = 1, hbar = l_P^2): omega_N = kappa * alpha * N / (8 pi) + m * Omega_H.
Measured (LVK, arXiv 2509.08099, pSEOBNR with 440): delta f_220 = 0.02 +0.02 -0.02 (90%) relative to Kerr
at the binary's own remnant; remnant spin chi_f = 0.68 +-0.01 (90%, arXiv 2509.08054).
Mass cancels: the test is delta_req(N, chi) = omega_N(chi) / omega_220(chi) - 1 against delta_obs.
"""
from math import log, pi
import numpy as np
import qnm

g220 = qnm.modes_cache(s=-2, l=2, m=2, n=0)
w0_check = g220(a=0.0)[0]
print(f'check Schwarzschild 220: {w0_check:.6f}  (literature 0.373672 - 0.088962i)')

def horizon(chi):
    rp = 1 + np.sqrt(1 - chi * chi)
    return np.sqrt(1 - chi * chi) / (2 * rp), chi / (2 * rp)      # kappa, Omega_H  (M = 1)

def w220(chi):
    return g220(a=float(chi))[0].real

ALPHA = {'4 ln 2  (binary, sealed)': 4 * log(2), '4 ln 3  (Hod)': 4 * log(3),
         '8 pi    (Maggiore)': 8 * pi, '15.6    (Laghi et al. fit)': 15.6}
D_OBS, S_OBS = 0.02, 0.02 / 1.645          # 90% half-width -> 1 sigma
CHI, S_CHI = 0.68, 0.01 / 1.645

print(f'\nKerr 220 at chi = 0.68: M*omega = {w220(0.68):.6f}')
print(f'Kerr itself (delta = 0) sits {(0 - D_OBS) / S_OBS:+.2f} sigma from the measured tone\n')
print(f'{"alpha":27s} {"spacing":>8s} {"N*":>6s} {"line N":>6s} {"delta_req":>9s} {"z":>6s}   z over chi in [0.67, 0.69]')
rng = np.random.default_rng(13)
chis_mc = rng.normal(CHI, S_CHI, 4000)
for name, a in ALPHA.items():
    out = []
    for chi in (0.67, 0.68, 0.69):
        k, oh = horizon(chi); w0 = w220(chi); step = k * a / (8 * pi)
        nstar = (w0 - 2 * oh) / step
        best = min(((N, (step * N + 2 * oh) / w0 - 1) for N in range(max(1, int(nstar) - 2), int(nstar) + 4)),
                   key=lambda t: abs(t[1] - D_OBS))
        out.append((chi, step / w0, nstar, best[0], best[1], (best[1] - D_OBS) / S_OBS))
    c = out[1]
    zs = ', '.join(f'{o[5]:+.2f}' for o in out)
    print(f'{name:27s} {c[1]:8.2%} {c[2]:6.2f} {c[3]:6d} {c[4]:+9.4f} {c[5]:+6.2f}   [{zs}]')
    # probability, over the spin posterior, that some line lies inside the measured 90% band
    hit = 0
    for chi in chis_mc[:800]:
        k, oh = horizon(chi); w0 = w220(chi); step = k * a / (8 * pi)
        nstar = (w0 - 2 * oh) / step
        hit += any(abs((step * N + 2 * oh) / w0 - 1 - D_OBS) <= 0.02 for N in range(max(1, int(nstar) - 2), int(nstar) + 4))
    print(f'{"":27s} share of spin posterior with a line inside the 90% band: {hit / 800:.2f}')
