NEXUS Carry Ownership Audit — 2026-11-03

Extract all ZIP members into the same directory.
Requires Python 3.10+ and NumPy.

python -m pip install -r requirements.txt
python NEXUS_Carry_Compiler_Certificate.py
python NEXUS_Carry_Representation_Gap.py

carry.py and predictions.txt are the original uploaded experiment inputs.
These are algebraic example tests, not additional random SAT samples.
