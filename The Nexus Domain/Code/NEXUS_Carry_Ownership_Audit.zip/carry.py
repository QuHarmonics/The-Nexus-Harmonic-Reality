"""Minimal carry (Myhill-Nerode class count) of random 3-SAT at every cut, in four reading orders.

Peak carry at a cut k of an order = number of distinct rows of the truth matrix whose row index is the
assignment of the first k variables in the order and whose columns are the assignments of the rest.
"""
import sys, math, time, random
import numpy as np

ALPHA = float(sys.argv[3]) if len(sys.argv) > 3 else 4.26

def reader_profile(n, clauses, order):
    """Carry of a reader that reads the clauses: distinct (alive, which crossing clauses are already satisfied)."""
    rank = {v: r for r, v in enumerate(order)}
    out = []
    for k in range(n + 1):
        K = 1 << k
        idx = np.arange(K, dtype=np.uint32)
        bit = {v: ((idx >> (k - 1 - rank[v])) & 1).astype(bool) for v in order[:k]}
        alive = np.ones(K, dtype=bool); cols = []
        for cl in clauses:
            inside = [(v, ng) for v, ng in cl if rank[v] < k]
            if not inside: continue
            s = np.zeros(K, dtype=bool)
            for v, ng in inside: s |= ~bit[v] if ng else bit[v]
            if len(inside) == 3: alive &= s
            else: cols.append(s)
        dead = int((~alive).any())
        if not alive.any(): out.append(dead); continue
        if not cols: out.append(1 + dead); continue
        M = np.stack(cols, axis=1)[alive]
        rows = np.ascontiguousarray(np.packbits(M, axis=1))
        out.append(len(np.unique(rows.view(np.dtype((np.void, rows.shape[1]))))) + dead)
    return out

def random_3sat(n, rng):
    m = round(ALPHA * n)
    return [tuple((v, rng.random() < 0.5) for v in rng.sample(range(n), 3)) for _ in range(m)], m

def truth_table(n, clauses, order):
    """order[r] = variable read at step r; step 0 is the most significant bit of the row index."""
    N = 1 << n
    idx = np.arange(N, dtype=np.uint32)
    rank = {v: r for r, v in enumerate(order)}
    bit = {v: ((idx >> (n - 1 - rank[v])) & 1).astype(bool) for v in range(n)}
    T = np.ones(N, dtype=bool)
    for cl in clauses:
        c = np.zeros(N, dtype=bool)
        for v, neg in cl:
            c |= ~bit[v] if neg else bit[v]
        T &= c
    return T

def mn_profile(T, n):
    out = []
    for k in range(n + 1):
        M = T.reshape(1 << k, 1 << (n - k))
        rows = np.packbits(M, axis=1)
        rows = np.ascontiguousarray(rows).view(np.dtype((np.void, rows.shape[1])))
        out.append(len(np.unique(rows)))
    return out

def mirror_order(n):
    o = []
    lo, hi = 0, n - 1
    while lo <= hi:
        o.append(lo)
        if hi != lo: o.append(hi)
        lo += 1; hi -= 1
    return o

def greedy_order(n, clauses):
    """Pick next the variable that leaves the fewest clauses crossing the cut."""
    placed, order = set(), []
    for _ in range(n):
        best = None
        for v in range(n):
            if v in placed: continue
            s = placed | {v}
            cross = sum(1 for cl in clauses if 0 < sum(x in s for x, _ in cl) < 3)
            if best is None or cross < best[0]: best = (cross, v)
        placed.add(best[1]); order.append(best[1])
    return order

def cutwidth(order, clauses):
    pos = {v: i for i, v in enumerate(order)}
    w = 0
    for k in range(1, len(order)):
        w = max(w, sum(1 for cl in clauses if min(pos[x] for x, _ in cl) < k <= max(pos[x] for x, _ in cl)))
    return w

def main():
    ns = [int(x) for x in sys.argv[1].split(',')]
    reps = int(sys.argv[2])
    rng = random.Random(20261103)
    print(f'alpha = {ALPHA}; orders: binary, mirror (ring outside-in), random, greedy (min crossing clauses)')
    print(f'{"n":>3} {"sat":>6} | median log2 peak carry over satisfiable instances | max cutwidth (greedy)')
    summary = {o: [] for o in ('binary', 'mirror', 'random', 'greedy')}
    rsum = {o: [] for o in summary}
    for n in ns:
        t0 = time.time()
        peaks = {o: [] for o in summary}; rd = {o: [] for o in summary}; sols = []; cws = []; sat = 0; unsat_ok = True
        for r in range(reps):
            clauses, m = random_3sat(n, rng)
            orders = {'binary': list(range(n)), 'mirror': mirror_order(n),
                      'random': rng.sample(range(n), n), 'greedy': greedy_order(n, clauses)}
            T0 = truth_table(n, clauses, orders['binary'])
            if not T0.any():
                unsat_ok &= max(mn_profile(T0, n)) == 1
                continue
            sat += 1
            sols.append(math.log2(int(T0.sum())))
            for o, order in orders.items():
                T = T0 if o == 'binary' else truth_table(n, clauses, order)
                peaks[o].append(math.log2(max(mn_profile(T, n))))
                rd[o].append(math.log2(max(reader_profile(n, clauses, order))))
            cws.append(cutwidth(orders['greedy'], clauses))
        med = {o: (float(np.median(v)) if v else float('nan')) for o, v in peaks.items()}
        rmed = {o: (float(np.median(v)) if v else float('nan')) for o, v in rd.items()}
        for o in summary: summary[o].append((n, med[o])); rsum[o].append((n, rmed[o]))
        print(f'      answer shape (log2 MN)  ' + '  '.join(f'{o} {med[o]:6.2f}' for o in summary) + f'   log2 #solutions {float(np.median(sols)) if sols else 0:5.2f}')
        print(f'      reader carry (log2)     ' + '  '.join(f'{o} {rmed[o]:6.2f}' for o in summary))
        print(f'{n:>3} {sat:>3}/{reps:<2} | ' + '  '.join(f'{o} {med[o]:6.2f}' for o in summary)
              + f' | {int(np.median(cws)) if cws else 0:>3}   unsat peak=1: {unsat_ok}   ({time.time() - t0:.0f}s)')
    for title, S in (('answer shape', summary), ('reader carry', rsum)):
      print(f'\nfitted slope, {title}: log2 peak = c n + b')
      for o, pts in S.items():
        x = np.array([p[0] for p in pts]); y = np.array([p[1] for p in pts])
        c, b = np.polyfit(x, y, 1)
        print(f'  {o:7s} c = {c:.3f}   b = {b:+.2f}')

if __name__ == '__main__':
    main()
