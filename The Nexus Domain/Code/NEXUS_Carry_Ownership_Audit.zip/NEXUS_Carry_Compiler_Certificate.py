"""Standalone exact ownership audit for 3-CNF clause-status vs residual memory.

Shows one explicit compiler route. Its proof tape stores exact source-clause indices
and resolution links, and reconstitutes the source pattern from its provider signature.
Does not imply a fast solution of unrestricted SAT.
"""
from itertools import product
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from carry import reader_profile, truth_table, mn_profile

# Literals are (variable_id, negated). Canonical clauses are frozensets of literals.
def lit(v,neg=False): return (v,neg)
def clause(*l): return frozenset(l)
def resolve(left,right,pivot):
    if lit(pivot,False) in left and lit(pivot,True) in right:
        pass
    elif lit(pivot,True) in left and lit(pivot,False) in right:
        left,right=right,left
    else:
        raise AssertionError('no opposite-polarity resolution pivot')
    out=(left-{lit(pivot,False)})|(right-{lit(pivot,True)})
    assert not any(lit(v,not neg) in out for v,neg in out), 'tautology'
    return frozenset(out)

def block(x,y,z):
    # The four clauses are all sign combinations on (y,z).
    return [clause(lit(x),lit(y,ny),lit(z,nz)) for ny,nz in product((False,True),repeat=2)]

def compile_block(x,y,z,source):
    assert len(source)==4 and set(source)==set(block(x,y,z))
    # Original order 00,01,10,11.
    a=resolve(source[0],source[1],z)      # x | y
    b=resolve(source[2],source[3],z)      # x | ~y
    c=resolve(a,b,y)                      # x
    assert c==clause(lit(x))
    certificate=[(0,1,z,a),(2,3,z,b),(4,5,y,c)]
    # Recheck that each derived clause follows only from registered providers.
    ledger=list(source)
    for i,j,p,expected in certificate:
        found=resolve(ledger[i],ledger[j],p)
        assert found==expected
        ledger.append(found)
    # The source clauses are exactly regenerated from the bound provider pattern.
    assert set(block(x,y,z))==set(source)
    return c,certificate

def build(m):
    clauses=[]
    for i in range(m):
        x,y,z=3*i,3*i+1,3*i+2
        clauses.extend(block(x,y,z))
        _,cert=compile_block(x,y,z,block(x,y,z))
        assert len(cert)==3
    bad=[j for i in range(m) for j in (3*i+1,3*i+2)]+[3*i for i in range(m)]
    good=[j for i in range(m) for j in (3*i+1,3*i+2,3*i)]
    old=[tuple(sorted(c)) for c in clauses]
    return old,bad,good

print('m  n  bad-cut carry  answer-at-cut  optimized-peak  overall-MN  proof steps')
for m in range(1,7):
    n=3*m
    formula,order,grouped=build(m)
    T=truth_table(n,formula,order)
    mn=mn_profile(T,n)
    r=reader_profile(n,formula,order)
    g=reader_profile(n,formula,grouped)
    assert r[2*m]==4**m
    assert mn[2*m]==1
    assert max(mn)==2
    assert max(g)<=5
    assert int(T.sum())==4**m
    print(f'{m:1d} {n:2d} {r[2*m]:>14d} {mn[2*m]:>14d} {max(g):>15d} {max(mn):>11d} {3*m:>11d}')
print('RUNS: 6 exact enumerations; certificates and inverse provider signatures verified, 0 mismatches.')
print('STANDS: for all m, 4m 3-clauses simplify to AND of m x_i in 3m resolution steps.')
