"""Exact 3-CNF representation-gap audit; standalone and deterministic.

For each block i, F_i=(x_i|y_i|z_i)&(x_i|y_i|~z_i)&
(x_i|~y_i|z_i)&(x_i|~y_i|~z_i) == x_i.
Each clause is encoded as (variable_index, is_negated).
"""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from carry import reader_profile, truth_table, mn_profile

def make(m):
    clauses=[]
    for i in range(m):
        x, y, z=3*i,3*i+1,3*i+2
        for ny in [False, True]:
            for nz in [False, True]:
                clauses.append(((x,False),(y,ny),(z,nz)))
    bad_order=[j for i in range(m) for j in (3*i+1,3*i+2)]+[3*i for i in range(m)]
    grouped_order=[j for i in range(m) for j in (3*i+1,3*i+2,3*i)]
    return clauses,bad_order,grouped_order

print('m  n  cut(2m) reader  cut(2m) MN  bad_peak  grouped_peak  MN_peak  solutions  assertions')
for m in range(1,7):
    n=3*m
    clauses,bad,good=make(m)
    t=truth_table(n,clauses,bad)
    mn=mn_profile(t,n)
    rbad=reader_profile(n,clauses,bad)
    rgood=reader_profile(n,clauses,good)
    sols=int(t.sum())
    assert sols == 4**m, (m,sols)
    assert rbad[2*m] == 4**m, (m,rbad[2*m])
    assert mn[2*m] == 1, (m,mn[2*m])
    assert max(mn) <= 2, (m,mn)
    assert max(rgood) <= 5, (m,rgood)
    print(f'{m:1d} {n:2d} {rbad[2*m]:>13d} {mn[2*m]:>11d} {max(rbad):>9d} {max(rgood):>13d} {max(mn):>8d} {sols:>10d} PASS')

print('STANDS: F_m = AND_i x_i by three resolution steps per block.')
print('RUNS: exact truth-table and clause-status profiles for m=1..6.')
