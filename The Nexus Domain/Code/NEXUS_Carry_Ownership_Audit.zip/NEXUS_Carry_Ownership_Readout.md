# NEXUS — Carry Is a Reader Representation, Not an Intrinsic Price

**Dean A. Kulik — QuHarmonics Research Group**  
ORCID: 0009-0003-3128-8828  
2026-11-03 · Exact independent audit

## The observed boundary

The reported per-instance optimal static route at random 3-SAT density 4.26 lowers the observed peak clause-status carry. The median log2 peak at n = 16 is 4.70, compared with 7.50 in binary order. The approximately 0.27 per-variable slope is a finite-window estimate, not an asymptotic lower bound. Optimizing over all variable-prefix subsets itself costs exponential work in the reported implementation.

Define separately (a) the minimum residual-function equivalence classes W_k; (b) retained clause-status states R_k of a particular reader; and (c) the work needed to derive an appropriate quotient or route from the formula. The experiment optimizes (b) over static orders, not (a) or (c).

## A sealed structural shape (algebraic derivation; no random search)

For each i, take the four 3-clauses

- (x_i OR y_i OR z_i)
- (x_i OR y_i OR NOT z_i)
- (x_i OR NOT y_i OR z_i)
- (x_i OR NOT y_i OR NOT z_i)

Their conjunction is **exactly x_i**: resolving z_i between the first two yields x_i OR y_i; resolving z_i between the second pair yields x_i OR NOT y_i; resolving y_i yields x_i. This is three checked resolution steps per block and can be inverted to regenerate the four source clauses from the bound (x_i,y_i,z_i) pattern.

Let F_m be the conjunction of m independent blocks, so F_m = AND_i x_i.

At a cut after reading every y_i and z_i but before reading any x_i:

- The raw clause-status reader retains 4^m distinct configurations (one of four satisfied/unsatisfied clause patterns for each block).
- Every partial y/z assignment leaves the **same** residual function AND_i x_i. The minimal answer quotient has one state at that cut.
- Across every cut the minimal residual-function width is at most two; the second state represents a prior x_i=0.
- A grouped route (y_i,z_i,x_i) per block has at most five clause-status states for all m>=2.

Therefore a reader can exhibit exponential apparent memory **even when the compiler has an O(m) exact simplification**. This is a representation cost. It cannot, without a separate lower-bound argument, be transferred to the problem itself or to every reader.

## Independent execution

The attached standalone script imports the uploaded `carry.py` and executes truth-table, residual-class and clause-status checks for m=1..6, n=3..18. It verifies all three clause resolutions per block and reconstructs the input clause signature from each provider.

| m | n | Reader states at bad cut | Minimal states at cut | Grouped reader peak | Resolution steps |
|---:|---:|---:|---:|---:|---:|
| 1 | 3 | 4 | 1 | 4 | 3 |
| 2 | 6 | 16 | 1 | 5 | 6 |
| 3 | 9 | 64 | 1 | 5 | 9 |
| 4 | 12 | 256 | 1 | 5 | 12 |
| 5 | 15 | 1024 | 1 | 5 | 15 |
| 6 | 18 | 4096 | 1 | 5 | 18 |

All tests passed. General algebra gives the same result for every m.

## Ledger

- **STANDS:** The four-clause block equals x_i; its certificate has three resolution steps; F_m is AND_i x_i; the bad-cut clause-status count is 4^m, minimal residual count is one, grouped reader carry is bounded by five.
- **RUNS:** Exact checks across m=1..6, n=3..18, including truth tables, clause-status profiles, and resolution certificates. Zero mismatches.
- **ELSEWHERE:** The claimed inherent computational cost belongs to a representation and an optimization procedure until independence of reader architecture is demonstrated.
- **OPEN:** A general bounded-cost compiler deriving the future-equivalence quotient from an arbitrary compact CNF, with a checkable route and inverse provenance.

The observed near-threshold 3-SAT data remain valid for their specified reader class. This construction isolates a different owner of cost; it does not establish that arbitrary 3-SAT is tractable.
