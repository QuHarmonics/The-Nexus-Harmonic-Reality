"""Integer-encoded ring operators shared by the audit scripts (a word of LEN n is an int, position 0 = MSB)."""


def J(x, n):
    return int(format(x, f'0{n}b')[::-1], 2)          # read backward


def C(x, n):
    return x ^ ((1 << n) - 1)                         # NOT every bit


def pal(x, n):
    return J(x, n) == x                               # reads the same both ways


def P(x, n):
    j = J(x, n)
    return j if j != x else C(x, n)                   # facing


def native_ring(n):
    """Native Binary Rings, eqs. 2-4."""
    N = 1 << n
    reps = sorted(x for x in range(N) if x < P(x, n))
    R = reps[:-1] + [P(reps[-1], n), reps[-1]] + [P(x, n) for x in reversed(reps[:-1])]
    assert sorted(R) == list(range(N))
    return R


def b(x, n):
    return format(x, f'0{n}b')
