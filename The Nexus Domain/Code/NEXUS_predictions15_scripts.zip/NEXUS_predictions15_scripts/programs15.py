"""predictions15: which programs are native to the ring (facing carries their transition table onto itself),
chains of native instructions, the native successor, and the twisted clock one LEN up."""
import os, sys
from itertools import permutations, product
from math import ceil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ringops import J, C, pal, P, native_ring, b

def table_native(f, n):
    """facing P_2n maps every transition x|f(x) onto a transition of f"""
    mask = (1 << n) - 1
    return all(f[P((x << n) | f[x], 2 * n) >> n] == P((x << n) | f[x], 2 * n) & mask for x in range(1 << n))
def criterion(f, n):
    N = 1 << n; finv = [0] * N
    for x in range(N): finv[f[x]] = x
    S = {x for x in range(N) if f[x] == J(x, n)}
    return all(J(f[J(x, n)], n) == finv[x] for x in range(N)) and all(C(x, n) in S for x in S)
def progs(n):
    N = 1 << n; R = native_ring(n); loc = {w: a for a, w in enumerate(R)}
    def gray_next(x):
        v, s = x, x >> 1
        while s: v ^= s; s >>= 1
        v = (v + 1) % N
        return v ^ (v >> 1)
    return {'NOT': [C(x, n) for x in range(N)],
            'rotation sigma': [((x << 1) & (N - 1)) | (x >> (n - 1)) for x in range(N)],
            'twisted clock tau': [((x << 1) & (N - 1)) | (1 ^ (x >> (n - 1))) for x in range(N)],
            'increment x+1': [(x + 1) % N for x in range(N)],
            'CNOT lsb->msb': [x ^ ((x & 1) << (n - 1)) for x in range(N)],
            'Gray counter': [gray_next(x) for x in range(N)],
            'native successor T': [R[(loc[x] + 1) % N] for x in range(N)]}

print('P15.1  table native  <=>  J f J = f^-1 and the self-reading set is closed under NOT')
for n in (2, 3):
    N = 1 << n; agree = native = 0; total = 0
    for f in permutations(range(N)):
        a, c = table_native(f, n), criterion(f, n)
        agree += a == c; native += a; total += 1
    assert agree == total
    print(f'  n={n}: {total:,} programs, criterion agrees on all; native programs: {native:,}')

print('\nP15.2  the tested programs, n = 1-12 (native = facing carries the table onto itself)')
rows = {}
for n in range(1, 13):
    for name, f in progs(n).items():
        rows.setdefault(name, []).append('Y' if table_native(f, n) else '.')
for name, r in rows.items():
    print(f'  {name:20s} n=1..12: {"".join(r)}')
for n in range(1, 13):
    N = 1 << n; tau = progs(n)['twisted clock tau']
    assert not any(tau[x] == J(x, n) for x in range(N))                          # §181: no self-reading transition
    assert not any(pal((x << 1) | (1 ^ (x >> (n - 1))), n + 1) for x in range(N))  # offset: no palindromic contact
print('  twisted clock: no self-reading transition in either contact model, n = 1-12')

print('\nP15.3  chains of NOT, rotation, twisted clock (all words of length <= 6)')
for n in (3, 4, 5):
    base = progs(n); ins = [base['NOT'], base['rotation sigma'], base['twisted clock tau']]
    N = 1 << n; checked = native = pal_words = 0
    for k in range(1, 7):
        for word in product(range(3), repeat=k):
            F = list(range(N))
            for i in word: F = [ins[i][y] for y in F]                 # execute the word left to right
            G = list(range(N))
            for i in reversed(word): G = [ins[i][y] for y in G]       # the word read backward
            nat = table_native(F, n)
            assert nat == (F == G)
            if word == word[::-1]: assert nat; pal_words += 1
            checked += 1; native += nat
    print(f'  n={n}: {checked} words; native <=> backward word computes the same map, on all; native {native}; '
          f'palindromic words {pal_words}, all native')

print('\nP15.4  native successor: transitions that facing carries onto transitions of T')
for n in range(3, 13):
    N = 1 << n; R = native_ring(n); loc = {w: a for a, w in enumerate(R)}
    T = [R[(loc[x] + 1) % N] for x in range(N)]; mask = N - 1
    good = {x for x in range(N) if T[P((x << n) | T[x], 2 * n) >> n] == P((x << n) | T[x], 2 * n) & mask}
    bad_pred = {x for x in range(N) if pal(x, n) or pal(T[x], n)} | {R[N // 2 - 1]}
    assert len(good) == N - 2 * 2 ** ceil(n / 2) and set(range(N)) - good == bad_pred
print('  n = 3-12: carried = 2^n - 2*2^ceil(n/2); the rest are exactly the edges touching a palindrome and the seam edge')

print('\nP15.5  the twisted clock one LEN up')
for n in range(2, 13):
    N, N1 = 1 << n, 1 << (n + 1)
    tau = lambda x, L: ((x << 1) & ((1 << L) - 1)) | (1 ^ (x >> (L - 1)))
    contact = lambda x: (x << 1) | (1 ^ (x >> (n - 1)))
    def orbit(x0, L):
        out, x = [], x0
        while True:
            out.append(x); x = tau(x, L)
            if x == x0: return out
    reads = [contact(x) for x in orbit(0, n)]
    nxt = [w for w in orbit(0, n + 1) if w not in (0, N1 - 1)]
    assert reads == nxt
    R1 = native_ring(n + 1); loc1 = {w: a for a, w in enumerate(R1)}
    a = [loc1[e] for e in reads]
    mono = all(a[i] < a[i + 1] for i in range(len(a) - 1))
    mirror = all(a[i] + a[2 * n - 1 - i] == N1 - 1 for i in range(n))
    assert mirror and (mono == (n >= 3))
    seen, other_orbits, ok = set(orbit(0, n)), 0, True
    for x0 in range(N):
        if x0 in seen: continue
        orb = orbit(x0, n); seen |= set(orb); other_orbits += 1
        dev = [tau(contact(x), n + 1) for x in orb if contact(tau(x, n)) != tau(contact(x), n + 1)]
        ok &= len(dev) > 0 and all(w not in (0, N1 - 1) for w in dev)
    assert ok
    if n <= 4 or n == 12:
        print(f'  n={n:2d}: principal reads = tau_{n+1} cycle minus poles; R_{n+1} addresses {a if n <= 4 else "..."}; '
              f'increasing {mono}, mirror {mirror}; {other_orbits} other orbits, each leaves tau_{n+1} through non-pole words')
print('  holds n = 2-12')

print('\nExternal table cells for the LFSR (feedback x0 xor x_{n-1}) that the notebook did not run:')
for n in (3, 4):
    N = 1 << n; m = N // 2; R = native_ring(n); loc = {w: a for a, w in enumerate(R)}
    f = [((x << 1) & (N - 1)) | (((x >> (n - 1)) ^ x) & 1) for x in range(N)]
    perm = [loc[f[R[a]]] for a in range(N)]
    seam = sum((a < m) != (perm[a] < m) for a in range(N))
    mask = N - 1
    pres = sum(f[P((x << n) | f[x], 2 * n) >> n] == P((x << n) | f[x], 2 * n) & mask for x in range(N))
    print(f'  n={n}: seam crossings {seam}/{N}; facing preserves §181 transitions {pres}/{N}')
print('\nALL CHECKS PASS')
