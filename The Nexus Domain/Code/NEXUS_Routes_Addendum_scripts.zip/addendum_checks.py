"""Checks for the addendum: (1) circular routes that are their own facing partner, (2) where the successor's
last-site share comes from."""
import os, sys
from math import ceil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ringops import J, C, pal, native_ring

def rot(x, L): return ((x << 1) & ((1 << L) - 1)) | (x >> (L - 1))
def canon(x, L):
    best = y = x
    for _ in range(L - 1):
        y = rot(y, L); best = min(best, y)
    return best
def tau(u, s): return ((u << 1) & ((1 << s) - 1)) | (1 ^ (u >> (s - 1)))

def formula(L):
    if L % 2: return 0
    a, k = 0, L
    while k % 2 == 0: a += 1; k //= 2
    return sum(2 ** (ceil((2 ** b) * k / 2) - 1) for b in range(a))

print('1a  brute force: necklaces of length L fixed by cyclic facing (achiral and self-complementary)')
row = []
for L in range(1, 19):
    seen, fixed = set(), 0
    for x in range(1 << L):
        c = canon(x, L)
        if c in seen: continue
        seen.add(c)
        if canon(J(c, L), L) == c and canon(C(c, L), L) == c: fixed += 1
    assert fixed == formula(L)
    row.append(fixed)
print('    L = 1..18:', row, ' = formula')

print('1b  per layer: achiral orbits of the twisted clock tau_s on s-bit half-words = 2^(ceil(s/2) - 1)')
for s in range(1, 19):
    N = 1 << s; seen = [False] * N; achiral = 0
    for u in range(N):
        if seen[u]: continue
        orb, v = [], u
        while not seen[v]: seen[v] = True; orb.append(v); v = tau(v, s)
        if J(u, s) in set(orb): achiral += 1
    assert achiral == 2 ** (ceil(s / 2) - 1), (s, achiral)
    # reflection fixed points: t-th reflection tau^t J fixes 0 words or 2^ceil(s/2) words, half and half
    counts = []
    for t in range(2 * s):
        fix = 0
        for u in range(N):
            v = J(u, s)
            for _ in range(t): v = tau(v, s)
            fix += v == u
        counts.append(fix)
    assert sorted(set(counts)) == [0, 2 ** ceil(s / 2)] and counts.count(0) == s
print('    s = 1..18: holds; each of the 2s reflections fixes 0 or 2^ceil(s/2) half-words, s of each')

print('1c  layers: each fixed necklace has one dyadic level b (complementing shift 2^b k), L even <= 18')
for L in range(2, 19, 2):
    a, k = 0, L
    while k % 2 == 0: a += 1; k //= 2
    seen, level_count = set(), [0] * a
    for x in range(1 << L):
        c = canon(x, L)
        if c in seen: continue
        seen.add(c)
        if canon(J(c, L), L) == c and canon(C(c, L), L) == c:
            levels = [b for b in range(a)                          # rotation by s = 2^b k turns c into its NOT
                      if (((c << (2 ** b * k)) | (c >> (L - 2 ** b * k))) & ((1 << L) - 1)) == C(c, L)]
            assert len(levels) == 1
            level_count[levels[0]] += 1
    assert level_count == [2 ** (ceil(2 ** b * k / 2) - 1) for b in range(a)]
print('    holds: layer b contributes 2^(ceil(2^b k / 2) - 1)')

print('\n2   successor step: which palindrome pairs carry the difference to a single site')
for n in range(5, 14, 2):
    k = n // 2; N = 1 << n
    R = native_ring(n); loc = {x: i for i, x in enumerate(R)}
    T = lambda x: R[(loc[x] + 1) % N]
    pals = [w for w in range(N) if pal(w, n)]
    by_site = {}
    for i, w in enumerate(pals):
        for v in pals[i + 1:]:
            d = T(w) ^ T(v)
            if d and d & (d - 1) == 0:                       # images differ in exactly one site
                site = n - 1 - (d.bit_length() - 1)
                cw, cv = (w >> (n - 1 - k)) & 1, (v >> (n - 1 - k)) & 1
                by_site.setdefault(site, []).append((format(w, f'0{n}b'), format(v, f'0{n}b'), cw != cv))
    center = by_site.get(k, []); last = by_site.get(n - 1, [])
    assert set(by_site) == {k, n - 1} and len(center) == 2 ** k - 1 and all(o for *_, o in center)
    assert len(last) == 1 and set(last[0][:2]) == {'0' * n, '1' * n} and last[0][2]
    print(f'    n={n:2d}: center site carried by {len(center)} center pairs; last site carried by the pole pair {last[0][0]} | {last[0][1]} '
          f'(images {format(T(0), f"0{n}b")} | {format(T(N - 1), f"0{n}b")})')
print('\nALL CHECKS PASS')
