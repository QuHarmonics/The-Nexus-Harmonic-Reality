"""Figure: the circular routes of length 8 that are their own facing partner, each (u | Cu)^(8/2s)."""
import math, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Arc, Circle

OUT = sys.argv[1] if len(sys.argv) > 1 else 'fixed_necklaces_L8.png'
NAVY, GOLD, BLUE, GRAY = '#1F3864', '#B08D2B', '#2E5597', '#7F7F7F'
cases = [('0000', 1), ('0110', 1), ('00', 2), ('0', 4)]          # (u, repetitions of u|Cu)
fig, axes = plt.subplots(1, 4, figsize=(7.2, 2.35))
for ax, (u, r) in zip(axes, cases):
    s = len(u); cu = ''.join('1' if c == '0' else '0' for c in u)
    w = (u + cu) * r; L = len(w)
    ang = [math.pi / 2 - 2 * math.pi * (i + 0.5) / L for i in range(L)]
    R = 1.0
    ax.add_patch(Circle((0, 0), R, fill=False, lw=0.8, color=GRAY))
    for blk in range(2 * r):                                    # arcs: gold over u-blocks, blue over Cu-blocks
        a0 = 90 - 360 * (blk * s) / L; a1 = 90 - 360 * ((blk + 1) * s) / L
        ax.add_patch(Arc((0, 0), 2.62, 2.62, theta1=a1 + 2.5, theta2=a0 - 2.5, lw=2.6,
                         color=GOLD if blk % 2 == 0 else BLUE))
    for i, bit in enumerate(w):
        x, y = R * math.cos(ang[i]), R * math.sin(ang[i])
        ax.add_patch(Circle((x, y), 0.17, color=NAVY if bit == '1' else 'white', ec=NAVY, lw=1.2, zorder=3))
    mid = math.pi / 2 - 2 * math.pi * (s / 2) / L                 # reading axis through the middle of the first u-block
    ax.plot([1.45 * math.cos(mid), -1.45 * math.cos(mid)], [1.45 * math.sin(mid), -1.45 * math.sin(mid)],
            ls=(0, (3, 2)), lw=0.9, color=GRAY, zorder=1)
    ax.set_xlim(-1.55, 1.55); ax.set_ylim(-1.55, 1.55); ax.set_aspect('equal'); ax.axis('off')
    ax.text(0, -1.95, f'u = {u},  Cu = {cu}', ha='center', va='center', fontsize=8.2, family='DejaVu Sans')
    ax.text(0, -2.38, f'({u}|{cu})' + (f'$^{r}$' if r > 1 else '') + f'   s = {s}', ha='center', va='center',
            fontsize=8.2, family='DejaVu Sans', color='#404040')
    ax.set_ylim(-2.6, 1.55)
fig.subplots_adjust(left=0.01, right=0.99, top=0.98, bottom=0.02, wspace=0.08)
fig.savefig(OUT, dpi=220)
print('wrote', OUT)
