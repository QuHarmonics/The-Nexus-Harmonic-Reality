"""predictions17: the reading direction as one address bit of the native ring."""
import os, sys
from math import ceil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ringops import J, C, pal, P, native_ring

print('P17.1-P17.2  top address bit against the reading direction; comparator energy on the top bit')
R1 = native_ring(1)
print(f'  n= 1: R_1 = {R1[0]}|{R1[1]}: the seam exchange takes the only pair, so the palindrome clause of P17.1 FAILS at n = 1 as sealed')
assert R1 == [1, 0]
for n in range(2, 21):
    N, m = 1 << n, 1 << (n - 1); p = 2 ** ceil(n / 2)
    R = native_ring(n)
    rstar = int('1' * (n // 2 - 1) + '0' + '1' * ceil(n / 2), 2) if n >= 2 else None
    top_g = 0; energy = 0
    for a, x in enumerate(R):
        top = a >= m
        jx = J(x, n)
        if jx == x:
            assert top == bool(x >> (n - 1))                         # palindrome: its first bit
            c = 0
        else:
            larger = x > jx
            seam = x in (rstar, J(rstar, n))
            assert top == (larger != seam)                           # direction, exchanged only at the seam
            c = -1 if larger else 1
        top_g += c * (1 if a < m else -1); energy += c * c
    if True:
        assert top_g == N - p - 4 and energy == N - p
        share = top_g ** 2 / (N * energy)
        if n in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20):
            print(f'  n={n:2d}: top-bit coefficient (N-p-4)/N = {top_g}/{N}; share of energy {share:.5f}')
print('  P17.1 holds n = 2-20 on every word; P17.2 holds n = 2-20')

print('\nP17.3  the LEN-2 ring lists each word at the address of its reversal')
assert native_ring(2) == [J(a, 2) for a in range(4)]
assert native_ring(1) != [J(a, 1) for a in range(2)] and native_ring(1) == [C(a, 1) for a in range(2)]
print('  R_1 = C_1, not J_1: the clause "R_1 = J_1 trivially" FAILS as sealed')
for n in range(3, 13):
    assert native_ring(n) != [J(a, n) for a in range(1 << n)]
print('  R_2 =', [format(w, '02b') for w in native_ring(2)], '= J_2 of 00, 01, 10, 11; fails at every n = 3-12')

print('\nP17.4  step signs under facing')
def steps(x, n): return [((x >> (n - 2 - i)) & 1) - ((x >> (n - 1 - i)) & 1) for i in range(n - 1)]
for n in range(2, 15):
    fails = 0
    for x in range(1 << n):
        s, sp = steps(x, n), steps(P(x, n), n)
        refl = all(sp[i] == -s[n - 2 - i] for i in range(n - 1))
        if pal(x, n):
            assert all(sp[i] == -s[i] == s[n - 2 - i] for i in range(n - 1))
            fails += not refl
            assert refl == (x in (0, (1 << n) - 1))
        else:
            assert refl
    assert fails == 2 ** ceil(n / 2) - 2
print('  n = 2-14: reversal-and-negation on words that read differently backward; negation in place on palindromes;')
print('  the reflected identity fails on exactly the 2^ceil(n/2) - 2 non-constant palindromes')
print('\nALL PREDICTIONS17 CHECKS PASS')
