"""predictions16: native feedback shift programs x -> x1..x(n-1) (x0 + h(x1..x(n-1)))."""
import os, sys
from math import floor
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ringops import J, C, pal, P

def shift_prog(h, n):                        # h: list over words v of LEN n-1 (v = x1..x(n-1) as an integer)
    N = 1 << n; vm = (1 << (n - 1)) - 1
    return [((x << 1) & (N - 1)) | ((x >> (n - 1)) ^ h[x & vm]) for x in range(N)]
def native(f, n):                             # facing P_2n carries every transition x|f(x) onto a transition of f
    mask = (1 << n) - 1
    return all(f[P((x << n) | f[x], 2 * n) >> n] == P((x << n) | f[x], 2 * n) & mask for x in range(1 << n))
def predicted(h, n):
    L = n - 1
    return all(h[J(v, L)] == h[v] for v in range(1 << L)) and all(h[C(v, L)] == h[v] for v in range(1 << L) if pal(v, L))

print('P16.1-P16.2  every h at n = 2-5')
for n in range(2, 6):
    L = n - 1; count = 0
    for code in range(1 << (1 << L)):
        h = [(code >> v) & 1 for v in range(1 << L)]
        f = shift_prog(h, n)
        assert sorted(f) == list(range(1 << n))                 # reversible
        nat = native(f, n)
        assert nat == predicted(h, n), (n, h)
        count += nat
    assert count == 2 ** (2 ** (n - 2))
    print(f'  n={n}: {1 << (1 << L):,} feedback functions; criterion agrees on all; native {count} = 2^(2^{n - 2})')
f1 = [[0, 1], [1, 0]]                                            # n = 1: identity and NOT
assert all(native(f, 1) for f in f1)
print('  n=1: identity and NOT, both native')

print('\nP16.3-P16.4  affine and linear feedback, n = 2-10')
def charpoly_has_root_1(f, n):                # x + 1 divides the characteristic polynomial iff A has a nonzero fixed word
    return any(f[x] == x for x in range(1, 1 << n))
def max_length(f, n):                         # one cycle through all nonzero words
    x, steps = 1, 0
    while True:
        x = f[x]; steps += 1
        if x == 1: return steps == (1 << n) - 1
for n in range(2, 11):
    L = n - 1; aff_native = []
    for c in range(1 << L):                    # taps c on v = x1..x(n-1); bit j of c taps v-position L-1-j
        for c0 in (0, 1):
            h = [(bin(c & v).count('1') + c0) & 1 for v in range(1 << L)]
            f = shift_prog(h, n)
            nat = native(f, n)
            sym_even = J(c, L) == c and bin(c).count('1') % 2 == 0
            assert nat == sym_even, (n, c, c0)
            if nat:
                aff_native.append((c, c0))
                if c0 == 0:
                    assert f[(1 << n) - 1] == (1 << n) - 1 and charpoly_has_root_1(f, n) and not max_length(f, n)
            elif c0 == 0 and max_length(f, n):
                pass                                            # maximal-length registers: all non-native
    assert len(aff_native) == 2 ** (floor((n - 1) / 2) + 1)
    lf = [((x << 1) & ((1 << n) - 1)) | (((x >> (n - 1)) ^ x) & 1) for x in range(1 << n)]
    assert not native(lf, n)
    ml = sum(1 for c in range(1 << L) if max_length(shift_prog([bin(c & v).count('1') & 1 for v in range(1 << L)], n), n))
    print(f'  n={n:2d}: native affine registers {len(aff_native):3d} = 2^(floor((n-1)/2)+1); every native linear one fixes 1^n; '
          f'maximal-length linear registers {ml:3d}, none native; x0+x(n-1) not native')
n3 = [h for h in ([(code >> v) & 1 for v in range(4)] for code in range(16)) if native(shift_prog(h, 3), 3)]
print('\n  n=3 native feedback h(x1 x2) over v = 00, 01, 10, 11:', n3)
print('\nALL PREDICTIONS16 CHECKS PASS')
