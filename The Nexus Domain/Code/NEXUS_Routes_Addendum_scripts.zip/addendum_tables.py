"""Every table in the addendum, computed and asserted in one run. Writes tables.json for the builder.
Sections: A closed routes, B circular routes, C LEN-4 catalog, D center motion, E programs, F twisted clock one LEN up."""
import json, os, sys
from math import ceil, comb
from collections import Counter, defaultdict
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ringops import J, C, pal, P, native_ring, b

OUT = {}
def bits(x, n): return format(x, f'0{n}b')

# ======================================================================= A  closed routes of B(n)
def rank(rows):
    piv, r = {}, 0
    for x in rows:
        while x:
            h = x.bit_length() - 1
            if h in piv: x ^= piv[h]
            else: piv[h] = x; r += 1; break
    return r

print('A  closed routes of the wheel B(n) under reversal and contact-wise facing')
rowsA = []
for n in range(1, 11):
    V, E = 1 << n, 1 << (n + 1)
    p, q, ev = 2 ** ceil(n / 2), 2 ** ceil((n + 1) / 2), int(n % 2 == 0)
    def bd(img):
        rows = [0] * V
        for e in range(E):
            f = img(e); rows[f >> 1] ^= 1 << e; rows[f & (V - 1)] ^= 1 << e
        return rows
    D, DP = bd(lambda e: e), bd(lambda e: P(e, n + 1))
    IJ = [(1 << e) | (1 << J(e, n + 1)) for e in range(E) if J(e, n + 1) != e]
    IP = [(1 << e) | (1 << P(e, n + 1)) for e in range(E)]
    dZ, dZJ = E - rank(D), E - rank(D + IJ)
    rJ = dZ - dZJ; tJ = dZJ - rJ
    dZP, dZPP = E - rank(D + DP), E - rank(D + DP + IP)
    rP = dZP - dZPP; tP = dZPP - rP
    assert (dZ, dZJ, tJ, rJ) == (V + 1, (V + p + q) // 2, p + q - 1, (V + 2 - p - q) // 2)
    assert (dZP, tP, rP) == (V - q // 2 + 2 + ev, p + q // 2 - 2 - ev, rJ + 1 + ev)
    rowsA.append([n, dZ, p, q, dZJ, tJ, rJ, q // 2 - 1 - ev, dZP, tP, rP])
    print('  ', rowsA[-1])
OUT['A'] = rowsA
for n in range(1, 19):                        # the wheel stays connected without its palindromic contacts
    V = 1 << n; par = list(range(V))
    def fd(a):
        while par[a] != a: par[a] = par[par[a]]; a = par[a]
        return a
    for e in range(1 << (n + 1)):
        if not pal(e, n + 1):
            a_, c_ = fd(e >> 1), fd(e & (V - 1))
            if a_ != c_: par[a_] = c_
    assert len({fd(v) for v in range(V)}) == 1, n
print('   the wheel without its palindromic contacts is connected, n = 1-18')

# ======================================================================= B  circular routes (necklaces)
def rot(x, L): return ((x << 1) & ((1 << L) - 1)) | (x >> (L - 1))
def fixed_formula(L):
    if L % 2: return 0
    a, k = 0, L
    while k % 2 == 0: a += 1; k //= 2
    return sum(2 ** (ceil(2 ** bb * k / 2) - 1) for bb in range(a))

print('\nB  necklaces: reversal, seams, cyclic facing, fixed necklaces')
rowsB, examplesB = [], {}
for L in range(1, 19):
    mask = (1 << L) - 1
    seen = bytearray(1 << L)
    neck = ach = seam = hinge = fixed = 0
    by_level = Counter()
    a, k = 0, L
    while k % 2 == 0: a += 1; k //= 2
    for x in range(1 << L):                    # the first word met in each class is its smallest rotation
        if seen[x]: continue
        rs, y = [], x
        for _ in range(L):
            rs.append(y); seen[y] = 1; y = rot(y, L)
        S = set(rs); neck += 1
        if J(x, L) not in S: continue
        ach += 1
        pals = {r for r in S if J(r, L) == r}
        if pals: seam += 1
        else: hinge += 1
        if L % 2: assert len(pals) == 1                         # odd L: one palindromic rotation
        if C(x, L) not in S: continue
        fixed += 1
        d = next(t for t in range(1, L) if rs[t % L] == C(x, L))  # smallest complementing shift = half period
        lev = (d & -d).bit_length() - 1                       # dyadic level b of the half period
        s = (1 << lev) * k
        assert lev < a and rs[s % L] == C(x, L)                # the level's shift 2^b k complements
        # a rotation whose first s bits read the same both ways, followed by their NOT, repeated
        hits = []
        for r in rs:
            u = r >> (L - s)
            if J(u, s) == u:
                blk = (u << s) | C(u, s); w = 0
                for _ in range(L // (2 * s)): w = (w << (2 * s)) | blk
                assert w == r
                hits.append(u)
        assert set(hits) and all(C(u, s) in set(hits) for u in hits) and len(set(hits)) == 2   # exactly {u, Cu}
        by_level[lev] += 1
        if L <= 8: examplesB.setdefault(L, []).append((bits(min(hits), s), bits(max(hits), s), bits(x, L)))
    p, q = 2 ** ceil(L / 2), 2 ** ceil((L + 1) / 2)
    assert ach == (p + q) // 2 and fixed == fixed_formula(L)
    if L % 2: assert hinge == 0
    assert [by_level[bb] for bb in range(a)] == [2 ** (ceil(2 ** bb * k / 2) - 1) for bb in range(a)]
    rowsB.append([L, neck, ach, seam, hinge, fixed, ' + '.join(str(by_level[bb]) for bb in range(a)) or '—'])
    print('  ', rowsB[-1])
OUT['B'] = rowsB
OUT['B_examples'] = {str(k_): v for k_, v in examplesB.items()}
print('   fixed necklaces, L <= 8 (u, Cu, smallest rotation):', examplesB)

# ======================================================================= C  LEN-4 affine catalog
def gl_tables(L):
    N = 1 << L; out = []
    def rec(cols, span):
        if len(cols) == L:
            tab = [0] * N
            for x in range(N):
                v, i, y = 0, 0, x
                while y:
                    if y & 1: v ^= cols[i]
                    y >>= 1; i += 1
                tab[x] = v
            out.append(tuple(tab)); return
        for c in range(1, N):
            if c not in span: rec(cols + [c], span | {s ^ c for s in span})
    rec([], {0}); return out
def cycle_type(perm):
    seen, out = [False] * len(perm), []
    for i in range(len(perm)):
        if not seen[i]:
            c, j = 0, i
            while not seen[j]: seen[j] = True; j = perm[j]; c += 1
            out.append(c)
    return tuple(sorted(out, reverse=True))
def pmul(a, c):                                  # polynomials over F2 as bit masks
    r = 0
    while c:
        if c & 1: r ^= a
        a <<= 1; c >>= 1
    return r
def charpoly(tab, L):                            # det(xI + A); column j of A is tab[1 << j]
    M = [[(tab[1 << j] >> i) & 1 for j in range(L)] for i in range(L)]
    E = [[M[i][j] ^ (2 if i == j else 0) for j in range(L)] for i in range(L)]
    def det(rows, cols):
        if not rows: return 1
        i, acc = rows[0], 0
        for t, j in enumerate(cols):
            if E[i][j]: acc ^= pmul(E[i][j], det(rows[1:], cols[:t] + cols[t + 1:]))
        return acc
    return det(list(range(L)), list(range(L)))
def ptxt(m):
    terms = []
    for d in range(m.bit_length() - 1, -1, -1):
        if m >> d & 1: terms.append('1' if d == 0 else ('x' if d == 1 else f'x^{d}'))
    return '+'.join(terms)
def apply_poly(poly, tab, L):                    # table of poly(A)
    N = 1 << L; res = [0] * N; powk = list(range(N))
    for d in range(poly.bit_length()):
        if poly >> d & 1: res = [res[x] ^ powk[x] for x in range(N)]
        powk = [tab[powk[x]] for x in range(N)]
    return res
def kdim(t): return sum(v == 0 for v in t).bit_length() - 1
Q, C1, C2 = 0b111, 0b1011, 0b1101               # x^2+x+1, x^3+x+1, x^3+x^2+1
def gl_label(tab, L=4):
    cp = charpoly(tab, L); X1 = 0b11
    if cp == pmul(pmul(X1, X1), pmul(X1, X1)):
        seq = [kdim(apply_poly(X1, tab, L)), kdim(apply_poly(pmul(X1, X1), tab, L)),
               kdim(apply_poly(pmul(pmul(X1, X1), X1), tab, L))]
        blocks = {(4, 4, 4): '[1,1,1,1]', (3, 4, 4): '[2,1,1]', (2, 4, 4): '[2,2]', (2, 3, 4): '[3,1]', (1, 2, 3): '[4]'}[tuple(seq)]
        return blocks, cp
    if cp == pmul(pmul(X1, X1), Q):
        return ('q+[1,1]' if kdim(apply_poly(X1, tab, L)) == 2 else 'q+[2]'), cp
    if cp == pmul(Q, Q):
        return ('q+q' if kdim(apply_poly(Q, tab, L)) == 4 else 'q²'), cp
    if cp == pmul(X1, C1): return 'c₁+[1]', cp
    if cp == pmul(X1, C2): return 'c₂+[1]', cp
    return ptxt(cp), cp

print('\nC  LEN-4 affine catalog (union-find over conjugation by generators)')
L4, N4 = 4, 16
mats = gl_tables(L4); M = len(mats); mid = {t: i for i, t in enumerate(mats)}
inv = [None] * M
for i, t in enumerate(mats):
    iv = [0] * N4
    for x in range(N4): iv[t[x]] = x
    inv[i] = mid[tuple(iv)]
gens = []                                        # elementary transvections: column j gains e_i
for i in range(L4):
    for j in range(L4):
        if i != j:
            cols = [1 << kk for kk in range(L4)]; cols[j] ^= 1 << i
            tab = []
            for x in range(N4):
                v = 0
                for kk in range(L4):
                    if (x >> kk) & 1: v ^= cols[kk]
                tab.append(v)
            gens.append(mid[tuple(tab)])
parent = list(range(M * N4))
def find(a):
    while parent[a] != a:
        parent[a] = parent[parent[a]]; a = parent[a]
    return a
def union(a, c):
    a, c = find(a), find(c)
    if a != c: parent[a] = c
conj = []
for h in gens:
    H, Hi = mats[h], mats[inv[h]]
    conj.append([mid[tuple(H[A[Hi[x]]] for x in range(N4))] for A in mats])
for m in range(M):
    A = mats[m]
    for bb in range(N4):
        g = m * N4 + bb
        for kk, h in enumerate(gens): union(g, conj[kk][m] * N4 + mats[h][bb])
        union(g, m * N4 + (A[1] ^ bb ^ 1))
cls = defaultdict(list)
for g in range(M * N4): cls[find(g)].append(g)
assert len(cls) == 25 and sum(len(v) for v in cls.values()) == 322560

def named_l4():
    n, N = 4, 16; R = native_ring(n); loc = {w: a for a, w in enumerate(R)}
    sig = lambda x: ((x << 1) & (N - 1)) | (x >> (n - 1))
    tau = lambda x: ((x << 1) & (N - 1)) | (1 ^ (x >> (n - 1)))
    lfsr = lambda x: ((x << 1) & (N - 1)) | (((x >> (n - 1)) ^ x) & 1)
    def inverse(f):
        t = [0] * N
        for x in range(N): t[f(x)] = x
        return lambda x: t[x]
    def gray(x):
        v, s = x, x >> 1
        while s: v ^= s; s >>= 1
        v = (v + 1) % N; return v ^ (v >> 1)
    return {'identity': lambda x: x, 'NOT C': lambda x: C(x, n), 'reversal J': lambda x: J(x, n),
            'NOT after reversal CJ': lambda x: C(J(x, n), n), 'rotation σ': sig, 'σ⁻¹': inverse(sig),
            'half turn σ²': lambda x: sig(sig(x)), 'σJ': lambda x: sig(J(x, n)),
            'twisted clock τ': tau, 'τ⁻¹': inverse(tau), 'τ²': lambda x: tau(tau(x)), 'τJ': lambda x: tau(J(x, n)),
            'CNOT (lsb → msb)': lambda x: x ^ ((x & 1) << (n - 1)), 'LFSR (x₀ ⊕ x₃)': lfsr, 'LFSR⁻¹': inverse(lfsr),
            'facing P₄': lambda x: P(x, n), 'native successor T₄': lambda x: R[(loc[x] + 1) % N],
            'increment x+1': lambda x: (x + 1) % N, 'Gray counter': gray}
placed = defaultdict(list); not_affine = []
for name, f in named_l4().items():
    t = [f(x) for x in range(N4)]; b0 = t[0]; A = tuple(v ^ b0 for v in t)
    if A not in mid: not_affine.append(name); continue
    placed[find(mid[A] * N4 + b0)].append(name)
_glc = {}
def gl_cached(mm):
    if mm not in _glc: _glc[mm] = gl_label(mats[mm])
    return _glc[mm]
rowsC = []
for root, members in cls.items():
    m, bb = divmod(members[0], N4)
    A = mats[m]; g = tuple(A[x] ^ bb for x in range(N4))
    order, h = 1, g
    while h != tuple(range(N4)): h = tuple(g[h[x]] for x in range(N4)); order += 1
    inv_root = find(inv[m] * N4 + mats[inv[m]][bb])
    labels = {gl_cached(x // N4) for x in members}
    assert len(labels) == 1
    lab, cp = labels.pop()
    fixed = sum(g[x] == x for x in range(N4))
    rowsC.append(dict(size=len(members), order=order, fixed=fixed, vc=cycle_type(g), dc=cycle_type(A),
                      gl=lab, cp=ptxt(cp), translated=fixed == 0, twin=inv_root != root, names=placed.get(root, [])))
rowsC.sort(key=lambda r: (r['order'], -r['fixed'], r['vc'], r['dc'], r['cp']))
sig = Counter((r['vc'], r['dc']) for r in rowsC); vsig = Counter(r['vc'] for r in rowsC)
assert len(sig) == 22 and len(vsig) == 19 and sum(r['twin'] for r in rowsC) == 6
keyset = Counter((r['vc'], r['dc'], r['cp']) for r in rowsC)
assert len(keyset) == 25                                    # adding the characteristic polynomial separates the twins
def ctxt(t):
    c = Counter(t); return ' '.join(f'{k_}^{{{v}}}' if v > 1 else f'{k_}' for k_, v in sorted(c.items(), reverse=True))
outC = []
for i, r in enumerate(rowsC):
    outC.append([str(i), f"{r['size']:,}", str(r['order']), str(r['fixed']), ctxt(r['vc']), ctxt(r['dc']),
                 r['gl'], 'yes' if r['translated'] else 'no', ', '.join(r['names']) or '—',
                 'twin' if r['twin'] else ''])
    print('  ', outC[-1])
print('   not affine at LEN 4:', not_affine)
OUT['C'] = outC; OUT['C_not_affine'] = not_affine

# ======================================================================= D  the center under ring motions
print('\nD  center motion: single-site trace distance from opposite-center pairs')
def site_td(n, perm):
    k = n // 2; pals = [w for w in range(1 << n) if pal(w, n)]
    cnt = Counter()
    for i, w in enumerate(pals):
        for v in pals[i + 1:]:
            d = perm[w] ^ perm[v]
            if d and d & (d - 1) == 0 and ((w ^ v) >> (n - 1 - k)) & 1:
                cnt[n - 1 - (d.bit_length() - 1)] += 1
    return {s: c / 2 ** k for s, c in cnt.items()}
try:
    import numpy as np
    def numeric_td(n, perm):
        k = n // 2; out = []
        def reg(sign):
            v = np.zeros(1 << n)
            for x in range(1 << n):
                if pal(x, n): v[x] = -1.0 if (sign < 0 and (x >> (n - 1 - k)) & 1) else 1.0
            return v / np.linalg.norm(v)
        a, c = np.zeros(1 << n), np.zeros(1 << n)
        a[np.asarray(perm)] = reg(1); c[np.asarray(perm)] = reg(-1)
        for i in range(n):
            ta = np.moveaxis(a.reshape([2] * n), i, 0).reshape(2, -1); tc = np.moveaxis(c.reshape([2] * n), i, 0).reshape(2, -1)
            out.append(0.5 * np.abs(np.linalg.eigvalsh(ta @ ta.T - tc @ tc.T)).sum())
        return out
except ImportError:
    numeric_td = None
rowsD = []
for n in range(3, 14, 2):
    k, N = n // 2, 1 << n; R = native_ring(n); loc = {w: a for a, w in enumerate(R)}
    T = [R[(loc[x] + 1) % N] for x in range(N)]
    td = site_td(n, T)
    if numeric_td and n <= 11:
        num = numeric_td(n, T)
        assert all(abs(num[i] - td.get(i, 0)) < 1e-9 for i in range(n))
    ek = 1 << (n - 1 - k)
    moved = {w: T[w] ^ T[w | ek] for w in range(N) if pal(w, n) and not w & ek}
    kept = sum(d == ek for d in moved.values()); disturbed = [(w, d) for w, d in moved.items() if d != ek]
    tau = [((x << 1) & (N - 1)) | (1 ^ (x >> (n - 1))) for x in range(N)]
    cur = list(range(N))
    for t in range(1, n + 1):
        cur = [tau[y] for y in cur]
        assert site_td(n, cur) == {(k - t) % n: 1.0}
    for f in ([C(x, n) for x in range(N)], [P(x, n) for x in range(N)], [J(x, n) for x in range(N)]):
        assert site_td(n, f) == {k: 1.0}
    if n >= 5:
        assert kept == 2 ** k - 1 and td == {k: 1 - 2 ** -k, n - 1: 2 ** -k}
        (w0, d0), = disturbed
        assert {w0, w0 | ek} == {int('1' * k + '0' + '1' * k, 2), N - 1} and d0 == int('1' * k + '0' * (k + 1), 2)
        rowsD.append([n, k, 2 ** k, kept, f'{1 - 2 ** -k:.4f}', f'{2 ** -k:.4f}',
                      f'{bits(w0, n)} | {bits(w0 | ek, n)}', bits(d0, n), f'{bits(T[0], n)} | {bits(T[N - 1], n)}'])
    else:
        rowsD.append([n, k, 2 ** k, kept, ', '.join(f'site {s}: {v:.2f}' for s, v in sorted(td.items())), '', '', '', ''])
    print('  ', rowsD[-1])
OUT['D'] = rowsD

# ======================================================================= E  programs
print('\nE  programs on the ring')
def progs(n):
    N = 1 << n; R = native_ring(n); loc = {w: a for a, w in enumerate(R)}
    def gray_next(x):
        v, s = x, x >> 1
        while s: v ^= s; s >>= 1
        v = (v + 1) % N; return v ^ (v >> 1)
    return {'NOT C': ([C(x, n) for x in range(N)], None),
            'rotation σ': ([((x << 1) & (N - 1)) | (x >> (n - 1)) for x in range(N)], lambda x: x >> (n - 1)),
            'twisted clock τ': ([((x << 1) & (N - 1)) | (1 ^ (x >> (n - 1))) for x in range(N)], lambda x: 1 ^ (x >> (n - 1))),
            'LFSR (x₀ ⊕ x_{n−1})': ([((x << 1) & (N - 1)) | (((x >> (n - 1)) ^ x) & 1) for x in range(N)],
                                   lambda x: ((x >> (n - 1)) ^ x) & 1),
            'increment x+1': ([(x + 1) % N for x in range(N)], None),
            'CNOT (lsb → msb)': ([x ^ ((x & 1) << (n - 1)) for x in range(N)], None),
            'Gray counter': ([gray_next(x) for x in range(N)], None),
            'native successor T': ([R[(loc[x] + 1) % N] for x in range(N)], None)}
def carried181(f, n):
    mask = (1 << n) - 1
    return sum(f[P((x << n) | f[x], 2 * n) >> n] == P((x << n) | f[x], 2 * n) & mask for x in range(1 << n))
def criterion(f, n):
    N = 1 << n; finv = [0] * N
    for x in range(N): finv[f[x]] = x
    S = {x for x in range(N) if f[x] == J(x, n)}
    return all(J(f[J(x, n)], n) == finv[x] for x in range(N)), len(S), all(C(x, n) in S for x in S)
native_rows = defaultdict(str)
for n in range(1, 13):
    for name, (f, _) in progs(n).items():
        if sorted(f) != list(range(1 << n)):
            native_rows[name] += '–'; continue
        nat = carried181(f, n) == (1 << n)
        jj, s, closed = criterion(f, n)
        assert nat == (jj and closed)
        native_rows[name] += 'Y' if nat else '·'
rowsE = []
for name in progs(3):
    cells = []
    for n in (3, 4):
        N = 1 << n; m = N // 2; R = native_ring(n); loc = {w: a for a, w in enumerate(R)}
        f, g = progs(n)[name]
        seam = sum((a < m) != (loc[f[R[a]]] < m) for a in range(N))
        jj, s, closed = criterion(f, n)
        if g is not None:
            contacts = {(x << 1) | g(x) for x in range(N)}
            off = sum(P(e, n + 1) in contacts for e in contacts); palc = sum(pal(e, n + 1) for e in contacts)
        else:
            off = palc = None
        cells.append((seam, carried181(f, n), off, palc, jj, s, closed))
    (s3, c3, o3, p3, j3, S3, k3), (s4, c4, o4, p4, j4, S4, k4) = cells
    rowsE.append([name, f'{s3}/8, {s4}/16', f'{c3}/8, {c4}/16', '—' if o3 is None else f'{o3}/8, {o4}/16',
                  '—' if p3 is None else f'{p3}/8, {p4}/16', 'yes' if j4 else 'no', f'{S4}' + ('' if k4 else ' (not closed)'),
                  native_rows[name]])
    print('  ', rowsE[-1])
lf3 = rowsE[[r[0] for r in rowsE].index('LFSR (x₀ ⊕ x_{n−1})')]
assert lf3[1] == '6/8, 10/16'
OUT['E'] = rowsE
dfact = lambda m: 1 if m <= 0 else m * dfact(m - 2)
counts = {n: sum(comb(2 ** (n - 1), j) * dfact(2 ** n - 2 * j - 1) for j in range(2 ** (n - 1) + 1)) for n in range(1, 6)}
assert counts[1] == 2 and counts[2] == 6 and counts[3] == 188
OUT['E_counts'] = {str(k_): v for k_, v in counts.items()}
print('   native programs (involutions g = J f with NOT-closed fixed set):', counts)
# the native successor's carried transitions and the reason for each failure
for n in range(3, 13):
    N = 1 << n; R = native_ring(n); loc = {w: a for a, w in enumerate(R)}
    T = [R[(loc[x] + 1) % N] for x in range(N)]
    touching = [x for x in range(N) if pal(x, n) or pal(T[x], n)]
    both = [x for x in range(N) if pal(x, n) and pal(T[x], n)]
    selfread = [x for x in range(N) if T[x] == J(x, n)]
    assert both == [N - 1] and selfread == [R[N // 2 - 1]] and len(touching) == 2 * 2 ** ceil(n / 2) - 1
    assert carried181(T, n) == N - 2 * 2 ** ceil(n / 2)
print('   native successor, n = 3-12: one palindrome-to-palindrome edge (1^n -> 0^n), one self-reading edge (the seam)')

# ======================================================================= F  the twisted clock one LEN up
print('\nF  twisted clock: contact(tau_n x) = tau_{n+1}(contact x) exactly when x0 = x1')
rowsF = []
for n in range(2, 13):
    N, N1 = 1 << n, 1 << (n + 1)
    tau = lambda x, L_: ((x << 1) & ((1 << L_) - 1)) | (1 ^ (x >> (L_ - 1)))
    contact = lambda x: (x << 1) | (1 ^ (x >> (n - 1)))
    for x in range(N):
        same = contact(tau(x, n)) == tau(contact(x), n + 1)
        x0, x1 = x >> (n - 1), (x >> (n - 2)) & 1
        assert same == (x0 == x1)
    if n <= 6:
        Rn, R1 = native_ring(n), native_ring(n + 1)
        ln, l1 = {w: a for a, w in enumerate(Rn)}, {w: a for a, w in enumerate(R1)}
        orb, x = [], 0
        while True:
            orb.append(x); x = tau(x, n)
            if x == 0: break
        rowsF.append([n, ' '.join(bits(x, n) for x in orb), ', '.join(str(ln[x]) for x in orb),
                      ', '.join(str(l1[contact(x)]) for x in orb)])
        print('  ', rowsF[-1])
OUT['F'] = rowsF

with open(os.path.join(HERE, 'tables.json'), 'w') as fh: json.dump(OUT, fh, ensure_ascii=False, indent=1)
print('\nALL TABLES ASSERTED; wrote tables.json')
