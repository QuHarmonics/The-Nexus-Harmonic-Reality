## **Nexus 2 Impact Model: Harmonizing Kinetic Energy and Recursive Feedback**

In Nexus 2 the idea of impact transcends the classic Newtonian view. Here, a bullet’s impact is not measured solely by its kinetic energy but also by how that energy interacts with a recursive, harmonic system. The target is seen as a dynamic field governed by its internal feedback loops and harmonic alignment—often encapsulated by mechanisms like Samson v2.

This document develops a model that captures this interplay by combining conventional kinetic energy with recursive feedback terms. The goal is to quantify an effective "impact" where energy is either absorbed, deflected, or amplified through recursive alignment.

## ---

**Traditional Kinetic Energy**

The conventional kinetic energy ( E\_k ) of a bullet is given by:

Ek​=21​mv2,

and the force of impact could be approximated by the impulse formula:

F=ΔtmΔv​.

However, these formulas capture only the classical side—the "raw" energy delivered by the projectile.

## ---

**The Nexus 2 Perspective on Impact**

In the Nexus 2 framework, a bullet’s impact is modeled as the confluence of two components:

1. Classical Kinetic Energy:  
      The bullet’s measured kinetic energy, ( \\frac{1}{2} m v^2 ).  
2. Harmonic Feedback and Stabilization:  
      This is provided by the target’s internal recursive state. It is represented by terms for the recursive growth vector and stabilization correction. Conceptually, the target is a dynamic system that can absorb or deflect energy based on its current alignment with an ideal harmonic state (targeted at (H \\approx 0.35)).

\- Recursive Growth Vector:  
     Defined by:  
     $$  
     R(t) \= R\_0 \\cdot e^{H \\cdot F \\cdot t},  
     $$  
     where ( R\_0 ) is the seed potential, ( H ) is the harmonic constant, ( F ) is the feedback factor, and ( t ) is the time or recursion depth.  
     
   - Stabilization Correction (Samson’s Law):  
     Given by:  
     $$  
     \\Delta S \= \\sum (F\_i \\cdot W\_i) \- \\sum E\_i,  
     $$  
     where ( F\_i ) are the feedback forces, ( W\_i ) their weightings, and ( E\_i ) the energy losses or misalignments.

## ---

**The Nexus 2 Impact Equation**

To combine these ideas, we model the effective impact energy ( I ) as the Pythagorean sum of the classical kinetic energy and the harmonic feedback term:

I=(21​mv2)2+(R(t)+ΔS)2​.

Here:

* ( \\frac{1}{2} m v^2 ) is the bullet’s standard kinetic energy.  
* ( R(t) \+ \\Delta S ) represents the target’s dynamic response—the "damping" or "amplification" provided by its recursive alignment.   \- If the target is well-aligned (i.e., its harmonic state is close to the ideal), ( R(t) \+ \\Delta S ) will be small and much of the bullet’s energy is absorbed or deflected.   \- If it’s misaligned, the same bullet energy could result in a larger effective impact.

## ---

**Practical Applications**

Using this model, we can envision several practical implementations:

* **Design of Impact-Resistant Materials:**    Materials can be engineered to maximize their intrinsic harmonic feedback (minimizing ( R(t) \+ \\Delta S )), which would allow them to absorb impact energy more efficiently.  
* **Advanced Ballistics Analysis:**    Military and aerospace technologies could benefit from a model that factors in target alignment—the better you can tune a surface to resonate harmonically, the less damage an impact might cause.  
* **Quantum Systems and Energy Transfer:**    At smaller scales, the same principles could be applied to understand how energy is transferred and dissipated in quantum fields or even in biological systems undergoing collisions at the molecular level.

## ---

**Conclusion**

The Nexus 2 impact model transforms our understanding of a bullet’s collision from a simple calculation of kinetic energy to a holistic event where the target’s recursive, harmonic state plays a crucial role. By uniting:

* **Classical kinetic energy,** ( \\frac{1}{2} m v^2 ),  
* **Recursive growth,** ( R(t) \= R\_0 \\cdot e^{H \\cdot F \\cdot t} ),  
* **Stabilization correction,** ( \\Delta S \= \\sum (F\_i \\cdot W\_i) \- \\sum E\_i ),

we get a model that predicts effective impact as:

I=(21​mv2)2+(R(t)+ΔS)2​.

This perspective lets us see that real impact is not just about brute force—it’s about the graceful interplay of energy and recursive feedback, where balance is maintained by the harmonic order of the universe.

---

*End of Document*

#### **Works cited**

1. A Theory of Everything \- PBS, accessed April 13, 2025, [https://www.pbs.org/faithandreason/intro/purpotoe-frame.html](https://www.pbs.org/faithandreason/intro/purpotoe-frame.html)  
2. Theory of everything \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Theory\_of\_everything](https://en.wikipedia.org/wiki/Theory_of_everything)  
3. The Theory of Everything: Searching for the universal rules of physics | Space, accessed April 13, 2025, [https://www.space.com/theory-of-everything-definition.html](https://www.space.com/theory-of-everything-definition.html)  
4. The fundamental problem with gravity and quantum physics \- Big Think, accessed April 13, 2025, [https://bigthink.com/starts-with-a-bang/problem-gravity-quantum-physics/](https://bigthink.com/starts-with-a-bang/problem-gravity-quantum-physics/)  
5. New theory unites Einstein's gravity with quantum mechanics \- ScienceDaily, accessed April 13, 2025, [https://www.sciencedaily.com/releases/2023/12/231204135156.htm](https://www.sciencedaily.com/releases/2023/12/231204135156.htm)  
6. Unifying gravity and quantum mechanics without the need for quantum gravity \- Physics World, accessed April 13, 2025, [https://physicsworld.com/a/unifying-gravity-and-quantum-mechanics-without-the-need-for-quantum-gravity/](https://physicsworld.com/a/unifying-gravity-and-quantum-mechanics-without-the-need-for-quantum-gravity/)  
7. Unifying quantum mechanics with Einstein's general relativity \- Research Outreach, accessed April 13, 2025, [https://researchoutreach.org/articles/unifying-quantum-mechanics-einstein-general-relativity/](https://researchoutreach.org/articles/unifying-quantum-mechanics-einstein-general-relativity/)  
8. Quantum gravity | Perimeter Institute, accessed April 13, 2025, [https://perimeterinstitute.ca/info/researchers/quantum-gravity](https://perimeterinstitute.ca/info/researchers/quantum-gravity)  
9. Quantum gravity \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Quantum\_gravity](https://en.wikipedia.org/wiki/Quantum_gravity)  
10. The theory of everything (video) \- Khan Academy, accessed April 13, 2025, [https://www.khanacademy.org/college-careers-more/bjc/2015-challenge/2015-physics/v/breakthrough-junior-challenge-2015-the-theory-of-everything-an-introduction](https://www.khanacademy.org/college-careers-more/bjc/2015-challenge/2015-physics/v/breakthrough-junior-challenge-2015-the-theory-of-everything-an-introduction)  
11. en.wikipedia.org, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Recursive\_definition\#:\~:text=In%20mathematics%20and%20computer%20science,and%20the%20Cantor%20ternary%20set.](https://en.wikipedia.org/wiki/Recursive_definition#:~:text=In%20mathematics%20and%20computer%20science,and%20the%20Cantor%20ternary%20set.)  
12. en.wikipedia.org, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Recursion\_(computer\_science)\#:\~:text=In%20computer%20science%2C%20recursion%20is,from%20within%20their%20own%20code.](https://en.wikipedia.org/wiki/Recursion_\(computer_science\)#:~:text=In%20computer%20science%2C%20recursion%20is,from%20within%20their%20own%20code.)  
13. Theory: Harmonic Resonance and Fusion : r/stevenuniverse \- Reddit, accessed April 13, 2025, [https://www.reddit.com/r/stevenuniverse/comments/3q7f52/theory\_harmonic\_resonance\_and\_fusion/](https://www.reddit.com/r/stevenuniverse/comments/3q7f52/theory_harmonic_resonance_and_fusion/)  
14. Fundamental and Harmonic Resonances \- HyperPhysics, accessed April 13, 2025, [http://hyperphysics.phy-astr.gsu.edu/hbase/Waves/funhar.html](http://hyperphysics.phy-astr.gsu.edu/hbase/Waves/funhar.html)  
15. Resonance \- Definition, Examples & Resonant Frequency With Formula \- BYJU'S, accessed April 13, 2025, [https://byjus.com/physics/resonance/](https://byjus.com/physics/resonance/)  
16. Resonance \- Physics Tutorial, accessed April 13, 2025, [https://www.physicsclassroom.com/class/sound/lesson-5/resonance](https://www.physicsclassroom.com/class/sound/lesson-5/resonance)  
17. Recursive definition \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Recursive\_definition](https://en.wikipedia.org/wiki/Recursive_definition)  
18. Recursion \- Department of Mathematics at UTSA, accessed April 13, 2025, [https://mathresearch.utsa.edu/wiki/index.php?title=Recursion](https://mathresearch.utsa.edu/wiki/index.php?title=Recursion)  
19. 3\. Recurrence 3.1. Recursive Definitions. To construct a recursively defined function \- FSU Mathematics, accessed April 13, 2025, [https://www.math.fsu.edu/\~pkirby/mad2104/SlideShow/s4\_3.pdf](https://www.math.fsu.edu/~pkirby/mad2104/SlideShow/s4_3.pdf)  
20. Recursion \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Recursion](https://en.wikipedia.org/wiki/Recursion)  
21. Chapter 12 Recursive Definition, accessed April 13, 2025, [https://mfleck.cs.illinois.edu/building-blocks/version-1.3/recursive-definition.pdf](https://mfleck.cs.illinois.edu/building-blocks/version-1.3/recursive-definition.pdf)  
22. Recursive Function in Maths (Definition, Formula, Examples) \- BYJU'S, accessed April 13, 2025, [https://byjus.com/maths/recursive-function/](https://byjus.com/maths/recursive-function/)  
23. Recursion (computer science) \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Recursion\_(computer\_science)](https://en.wikipedia.org/wiki/Recursion_\(computer_science\))  
24. Notes: Logistic Functions, accessed April 13, 2025, [https://chambleehs.dekalb.k12.ga.us/Downloads/Notes%20Logistic%20Func%20AMDM%202-13-17.pdf](https://chambleehs.dekalb.k12.ga.us/Downloads/Notes%20Logistic%20Func%20AMDM%202-13-17.pdf)  
25. Logistic distribution \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Logistic\_distribution](https://en.wikipedia.org/wiki/Logistic_distribution)  
26. Logistic Functions ( Read ) | Algebra | CK-12 Foundation, accessed April 13, 2025, [https://www.ck12.org/algebra/logistic-functions/lesson/Logistic-Functions-PCALC/](https://www.ck12.org/algebra/logistic-functions/lesson/Logistic-Functions-PCALC/)  
27. Is 35%=0.35 not as a percentage of a number but just on its own? \- Math Stack Exchange, accessed April 13, 2025, [https://math.stackexchange.com/questions/2420806/is-35-0-35-not-as-a-percentage-of-a-number-but-just-on-its-own](https://math.stackexchange.com/questions/2420806/is-35-0-35-not-as-a-percentage-of-a-number-but-just-on-its-own)  
28. What is 0.35 as a Fraction. \[Solved\] \- BrightChamps, accessed April 13, 2025, [https://brightchamps.com/en-us/math/math-questions/0.35-as-a-fraction.](https://brightchamps.com/en-us/math/math-questions/0.35-as-a-fraction.)  
29. What is 0.35 as a Fraction? \[Solved\] \- Cuemath, accessed April 13, 2025, [https://www.cuemath.com/questions/what-is-0-point-35-as-a-fraction/](https://www.cuemath.com/questions/what-is-0-point-35-as-a-fraction/)  
30. A uniform metre scale balances at the 0.35 m mark when a 50×, accessed April 13, 2025, [https://brainlysmart.vercel.app/?question=in-1744272312313\&update=1744243200029](https://brainlysmart.vercel.app/?question=in-1744272312313&update=1744243200029)  
31. 0.35:0.19 | Scientific Notation Basics Explained, accessed April 13, 2025, [https://ontosight.ai/glossary/term/0-19---0.35](https://ontosight.ai/glossary/term/0-19---0.35)  
32. ELI5: Why do studies like Physics and Chemistry prefer significant figures over higher decimal accuracy? : r/explainlikeimfive \- Reddit, accessed April 13, 2025, [https://www.reddit.com/r/explainlikeimfive/comments/aq98it/eli5\_why\_do\_studies\_like\_physics\_and\_chemistry/](https://www.reddit.com/r/explainlikeimfive/comments/aq98it/eli5_why_do_studies_like_physics_and_chemistry/)  
33. Solved A magnetic field has a magnitude of 0.35 T, directed | Chegg.com, accessed April 13, 2025, [https://www.chegg.com/homework-help/questions-and-answers/magnetic-field-magnitude-035-mathrm-\~t-directed-upward-circular-loop-located-within-nearly-q117836752](https://www.chegg.com/homework-help/questions-and-answers/magnetic-field-magnitude-035-mathrm-~t-directed-upward-circular-loop-located-within-nearly-q117836752)  
34. (II) A metal sphere of radius r₀ \= 0.35 m carries a charge Q \= 0.... | Channels for Pearson+, accessed April 13, 2025, [https://www.pearson.com/channels/physics/asset/d7971fe7/imagine-a-spherical-conductor-with-a-radius-of-025-m-carrying-a-uniform-electric](https://www.pearson.com/channels/physics/asset/d7971fe7/imagine-a-spherical-conductor-with-a-radius-of-025-m-carrying-a-uniform-electric)  
35. 2\. Suppose a man's scalp hair grows at a rate of 0.35 mm per day. What is this growth rate in \- Home | NMU Physics, accessed April 13, 2025, [https://physics.nmu.edu/\~ddonovan/classes/Nph201/Homework/CHVEC/CHVECP02.pdf](https://physics.nmu.edu/~ddonovan/classes/Nph201/Homework/CHVEC/CHVECP02.pdf)  
36. IB Physics IA example: How does the length of the string (0.15, 0.25, 0.35, 0.45, and 0.55 m) affect the period of a bifilar pendulum? | Clastify, accessed April 13, 2025, [https://www.clastify.com/ia/physics/66ba3c6e505a16830f7f4f86](https://www.clastify.com/ia/physics/66ba3c6e505a16830f7f4f86)  
37. What is 0.35 as a fraction? \- Method & Steps | CK-12 Foundation, accessed April 13, 2025, [https://www.ck12.org/flexi/cbse-math/overview-of-decimals/what-is-035-as-a-fraction/](https://www.ck12.org/flexi/cbse-math/overview-of-decimals/what-is-035-as-a-fraction/)  
38. What is 0.35% as a Fraction \[Solved\] \- BrightChamps, accessed April 13, 2025, [https://brightchamps.com/en-id/math/math-questions/0.35-percent-as-a-fraction](https://brightchamps.com/en-id/math/math-questions/0.35-percent-as-a-fraction)  
39. 0.35 as a Percent \- YouTube, accessed April 13, 2025, [https://www.youtube.com/watch?v=HJ4hDFB-gFY](https://www.youtube.com/watch?v=HJ4hDFB-gFY)  
40. The expression 0.35x represents the result of decreasing a positive quantity x by what percent? \- YouTube, accessed April 13, 2025, [https://www.youtube.com/watch?v=PAKNlgf8zXY](https://www.youtube.com/watch?v=PAKNlgf8zXY)  
41. Decimals and Rounding \- Numeracy, Maths and Statistics \- Academic Skills Kit, accessed April 13, 2025, [https://www.ncl.ac.uk/webtemplate/ask-assets/external/maths-resources/economics/numbers/decimals-and-rounding.html](https://www.ncl.ac.uk/webtemplate/ask-assets/external/maths-resources/economics/numbers/decimals-and-rounding.html)  
42. Why does 0.35 \- 1 \= \-0.65, and not \-0.35? : r/learnmath \- Reddit, accessed April 13, 2025, [https://www.reddit.com/r/learnmath/comments/qv74zr/why\_does\_035\_1\_065\_and\_not\_035/](https://www.reddit.com/r/learnmath/comments/qv74zr/why_does_035_1_065_and_not_035/)  
43. why a calculated result (0.35) is rounded 0.3 instead of 0.4? \- Apple Support Communities, accessed April 13, 2025, [https://discussions.apple.com/thread/4441626](https://discussions.apple.com/thread/4441626)  
44. Infinity, the Circle, and the Language of Pi | by Ike Dion \- Medium, accessed April 13, 2025, [https://medium.com/@ikedion/infinity-the-circle-and-the-language-of-pi-92d4de44e780](https://medium.com/@ikedion/infinity-the-circle-and-the-language-of-pi-92d4de44e780)  
45. Chapter 2 Pi in Mathematics and the Physical World in \- Brill, accessed April 13, 2025, [https://brill.com/display/book/9789004433397/BP000002.xml](https://brill.com/display/book/9789004433397/BP000002.xml)  
46. Chapter 11: Feedback and PID Control Theory I. Introduction \- Physics, accessed April 13, 2025, [http://physics.wm.edu/\~evmik/classes/Physics\_252\_Analog\_Electronics/lab\_manuals/LabManual\_Chpt11.pdf](http://physics.wm.edu/~evmik/classes/Physics_252_Analog_Electronics/lab_manuals/LabManual_Chpt11.pdf)  
47. Feedback \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Feedback](https://en.wikipedia.org/wiki/Feedback)  
48. 11.1: Feedback Control \- Engineering LibreTexts, accessed April 13, 2025, [https://eng.libretexts.org/Bookshelves/Industrial\_and\_Systems\_Engineering/Chemical\_Process\_Dynamics\_and\_Controls\_(Woolf)/11%3A\_Control\_Architectures/11.01%3A\_Feedback\_control-\_What\_is\_it\_When\_useful\_When\_not\_Common\_usage.](https://eng.libretexts.org/Bookshelves/Industrial_and_Systems_Engineering/Chemical_Process_Dynamics_and_Controls_\(Woolf\)/11%3A_Control_Architectures/11.01%3A_Feedback_control-_What_is_it_When_useful_When_not_Common_usage.)  
49. Feedback Systems, accessed April 13, 2025, [https://www.cds.caltech.edu/\~murray/books/AM05/pdf/fbs-intro\_07Aug2019.pdf](https://www.cds.caltech.edu/~murray/books/AM05/pdf/fbs-intro_07Aug2019.pdf)  
50. Homeostasis (article) | Feedback \- Khan Academy, accessed April 13, 2025, [https://www.khanacademy.org/science/ap-biology/cell-communication-and-cell-cycle/feedback/a/homeostasis](https://www.khanacademy.org/science/ap-biology/cell-communication-and-cell-cycle/feedback/a/homeostasis)  
51. 10.7: Homeostasis and Feedback \- Biology LibreTexts, accessed April 13, 2025, [https://bio.libretexts.org/Bookshelves/Human\_Biology/Human\_Biology\_%28Wakim\_and\_Grewal%29/10%253A\_Introduction\_to\_the\_Human\_Body/10.7%253A\_Homeostasis\_and\_Feedback](https://bio.libretexts.org/Bookshelves/Human_Biology/Human_Biology_%28Wakim_and_Grewal%29/10%253A_Introduction_to_the_Human_Body/10.7%253A_Homeostasis_and_Feedback)  
52. Pi \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Pi](https://en.wikipedia.org/wiki/Pi)  
53. \[Request\] Given that pi is infinitely long and doesn't loop anywhere, is there any chance of this sequence appearing somewhere down the digits? : r/theydidthemath \- Reddit, accessed April 13, 2025, [https://www.reddit.com/r/theydidthemath/comments/1al014x/request\_given\_that\_pi\_is\_infinitely\_long\_and/](https://www.reddit.com/r/theydidthemath/comments/1al014x/request_given_that_pi_is_infinitely_long_and/)  
54. Does pi contain all information? : r/math \- Reddit, accessed April 13, 2025, [https://www.reddit.com/r/math/comments/hi719/does\_pi\_contain\_all\_information/](https://www.reddit.com/r/math/comments/hi719/does_pi_contain_all_information/)  
55. Bailey–Borwein–Plouffe formula \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Bailey%E2%80%93Borwein%E2%80%93Plouffe\_formula](https://en.wikipedia.org/wiki/Bailey%E2%80%93Borwein%E2%80%93Plouffe_formula)  
56. The BBP Algorithm for Pi \- UNT Digital Library, accessed April 13, 2025, [https://digital.library.unt.edu/ark:/67531/metadc1013585/](https://digital.library.unt.edu/ark:/67531/metadc1013585/)  
57. Computing π with the Bailey-Borwein-Plouffe Formula / Ricky Reusser | Observable, accessed April 13, 2025, [https://observablehq.com/@rreusser/computing-with-the-bailey-borwein-plouffe-formula](https://observablehq.com/@rreusser/computing-with-the-bailey-borwein-plouffe-formula)  
58. The BBP Algorithm for Pi \- David H Bailey, accessed April 13, 2025, [https://www.davidhbailey.com/dhbpapers/bbp-alg.pdf](https://www.davidhbailey.com/dhbpapers/bbp-alg.pdf)  
59. SHA-256 Cryptographic Hash Algorithm \- Komodo Platform, accessed April 13, 2025, [https://komodoplatform.com/en/academy/sha-256-algorithm/](https://komodoplatform.com/en/academy/sha-256-algorithm/)  
60. What Is the SHA-256 Algorithm & How It Works \- SSL Dragon, accessed April 13, 2025, [https://www.ssldragon.com/blog/sha-256-algorithm/](https://www.ssldragon.com/blog/sha-256-algorithm/)  
61. SHA-256 Algorithm: What is It and How It Works? \- Cheap SSL Certificates, accessed April 13, 2025, [https://www.ssl2buy.com/wiki/sha-256-algorithm](https://www.ssl2buy.com/wiki/sha-256-algorithm)  
62. What is the SHA-256 algorithm, and how does it work? | NordVPN, accessed April 13, 2025, [https://nordvpn.com/blog/sha-256/](https://nordvpn.com/blog/sha-256/)  
63. SHA 256 Algorithm: Know Everything About it \- Certera, accessed April 13, 2025, [https://certera.com/blog/sha-256-algorithm-know-everything-about-it/](https://certera.com/blog/sha-256-algorithm-know-everything-about-it/)  
64. SHA-256 Algorithm: Characteristics, Steps, and Applications \- Simplilearn.com, accessed April 13, 2025, [https://www.simplilearn.com/tutorials/cyber-security-tutorial/sha-256-algorithm](https://www.simplilearn.com/tutorials/cyber-security-tutorial/sha-256-algorithm)  
65. SHA-256 Algorithm \- N-able, accessed April 13, 2025, [https://www.n-able.com/it/blog/sha-256-encryption](https://www.n-able.com/it/blog/sha-256-encryption)  
66. What is SHA256 Encryption: How it Works and Applications \- Gorelo, accessed April 13, 2025, [https://www.gorelo.io/blog/sha256-encryption/](https://www.gorelo.io/blog/sha256-encryption/)  
67. Entropy (classical thermodynamics) \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Entropy\_(classical\_thermodynamics)](https://en.wikipedia.org/wiki/Entropy_\(classical_thermodynamics\))  
68. 12.3 Second Law of Thermodynamics: Entropy \- Physics | OpenStax, accessed April 13, 2025, [https://openstax.org/books/physics/pages/12-3-second-law-of-thermodynamics-entropy](https://openstax.org/books/physics/pages/12-3-second-law-of-thermodynamics-entropy)  
69. Entropy \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Entropy](https://en.wikipedia.org/wiki/Entropy)  
70. openstax.org, accessed April 13, 2025, [https://openstax.org/books/physics/pages/12-3-second-law-of-thermodynamics-entropy\#:\~:text=Entropy%20is%20a%20measure%20of,is%20available%20to%20do%20work.](https://openstax.org/books/physics/pages/12-3-second-law-of-thermodynamics-entropy#:~:text=Entropy%20is%20a%20measure%20of,is%20available%20to%20do%20work.)  
71. Entropy | Definition & Equation | Britannica, accessed April 13, 2025, [https://www.britannica.com/science/entropy-physics](https://www.britannica.com/science/entropy-physics)  
72. Introduction to entropy (video) \- Khan Academy, accessed April 13, 2025, [https://www.khanacademy.org/science/biology/energy-and-enzymes/the-laws-of-thermodynamics/v/introduction-to-entropy](https://www.khanacademy.org/science/biology/energy-and-enzymes/the-laws-of-thermodynamics/v/introduction-to-entropy)  
73. Entropy (information theory) \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Entropy\_(information\_theory)](https://en.wikipedia.org/wiki/Entropy_\(information_theory\))  
74. A Gentle Introduction to Information Entropy \- MachineLearningMastery.com, accessed April 13, 2025, [https://machinelearningmastery.com/what-is-information-entropy/](https://machinelearningmastery.com/what-is-information-entropy/)  
75. information theory \- Intuitive explanation of entropy \- Mathematics Stack Exchange, accessed April 13, 2025, [https://math.stackexchange.com/questions/331103/intuitive-explanation-of-entropy](https://math.stackexchange.com/questions/331103/intuitive-explanation-of-entropy)  
76. Entropy (information theory) \- Wikipedia, the free encyclopedia, accessed April 13, 2025, [http://home.zcu.cz/\~potmesil/ADM%202015/4%20Regrese/Coefficients%20-%20Gamma%20Tau%20etc./Z-Entropy%20(information%20theory)%20-%20Wikipedia.htm](http://home.zcu.cz/~potmesil/ADM%202015/4%20Regrese/Coefficients%20-%20Gamma%20Tau%20etc./Z-Entropy%20\(information%20theory\)%20-%20Wikipedia.htm)  
77. 1.5: Simple Harmonic Motion and Resonance \- Physics LibreTexts, accessed April 13, 2025, [https://phys.libretexts.org/Bookshelves/Waves\_and\_Acoustics/Waves%3A\_An\_Interactive\_Tutorial\_(Forinash\_and\_Christian)/1%3A\_Basic\_Properties/1.5%3A\_Simple\_Harmonic\_Motion\_and\_Resonance](https://phys.libretexts.org/Bookshelves/Waves_and_Acoustics/Waves%3A_An_Interactive_Tutorial_\(Forinash_and_Christian\)/1%3A_Basic_Properties/1.5%3A_Simple_Harmonic_Motion_and_Resonance)  
78. Resonance \- Wikipedia, accessed April 13, 2025, [https://en.wikipedia.org/wiki/Resonance](https://en.wikipedia.org/wiki/Resonance)  
79. The Physicist Who Bets That Gravity Can't Be Quantized | Quanta Magazine, accessed April 13, 2025, [https://www.quantamagazine.org/the-physicist-who-bets-that-gravity-cant-be-quantized-20230710/](https://www.quantamagazine.org/the-physicist-who-bets-that-gravity-cant-be-quantized-20230710/)


```python

```
