
# Bitcoin Mining as a Natural FPGA “BIOS”

This document expands on the analogy between Bitcoin’s proof‐of‐work mining process and a field‐programmable “BIOS,” filling in missing formulas and providing full context.

---

## 1 Real‐World Example: Bitcoin Genesis Block

The **genesis block** (block height 0) is hard‐coded in every Bitcoin node. Its header consists of the following fields (all in little‐endian byte order when serialized):

| Field                  | Size (bytes) | Value                                                                                      |
| ---------------------- | ------------ | ------------------------------------------------------------------------------------------ |
| Version                | 4            | `0x01000000` (version 1)                                                                   |
| Previous Block Hash    | 32           | `0x000000…0000` (all zeros)                                                               |
| Merkle Root            | 32           | `0x3ba3edfd7a7b12b27ac72c3e67768f617fc81bc3888a51323a9fb8aa4b1e5e4a`                       |
| Timestamp              | 4            | `0x495FAB29` (`2009-01-03 02:15:05 UTC`)                                                   |
| Bits (compact target)  | 4            | `0x1d00ffff`                                                                               |
| Nonce                  | 4            | `0x1dac2b7c` (decimal 2083236893)                                                          |

When serialized and double‐hashed, this header produces the genesis block hash:

$$
H_{\text{genesis}}
= \mathrm{SHA256}\bigl(\mathrm{SHA256}(\text{header}_\text{genesis})\bigr)
= \texttt{000000000019d6689c085ae165831e934ff763ae46a2a6c172b3f1b60a8ce26f}
$$

---

## 2 Block Header Composition and Hashing

A block header is the concatenation:

$$
\text{header} = \text{version} \;\|\; \text{prev\_hash} \;\|\; \text{merkle\_root}
\;\|\; \text{timestamp} \;\|\; \text{bits} \;\|\; \text{nonce}
$$

Mining consists of repeatedly incrementing the 4-byte **nonce** (and if exhausted, altering other fields such as the coinbase extraNonce) and computing

$$
H = \mathrm{SHA256}\bigl(\mathrm{SHA256}(\text{header})\bigr).
$$

A header is valid if interpreted as a 256‐bit little‐endian integer, it satisfies:

$$
H \leq T,
$$

where $T$ is the target threshold defined by the **bits** field.

---

## 3 Compact “Bits” Field → Target Threshold

The 4‐byte **bits** field encodes the full 256‐bit target $T$ in a compact form:

- Let the first byte be the exponent $e$.
- Let the next three bytes form the coefficient $C$ (as a big‐endian integer).

Then

$$
T = C \times 2^{8\,(e - 3)}.
$$

For the genesis block:

- $e = 0x1d = 29$,
- $C = 0x00ffff = 65{,}535$,

so

$$
T_{\text{genesis}}
= 65{,}535 \times 2^{8\,(29 - 3)}
= 65{,}535 \times 2^{208}.
$$

---

## 4 Difficulty and Expected Work

Bitcoin defines **difficulty** $D$ relative to a reference (difficulty 1) target $T_1 = 0x1d00ffff$:

$$
D = \frac{T_1}{T}.
$$

Equivalently, the expected number of hash attempts to find a valid nonce is

$$
\mathbb{E}[\text{trials}]
= \frac{2^{256}}{T} \approx \frac{T_1}{T} \times 2^{224}.
$$

At genesis, $D = 1$, so on average $2^{224} \approx 2.7\times10^{67}$ hashes are required.

---

## 5 Mining as “Natural FPGA” Programming

1. **Header fields = Configuration words.**  
   - Version, timestamp, bits are like static BIOS parameters (read-only constants).
   - Nonce (and extraNonce) are dynamic configuration registers toggled like FPGA switches.

2. **SHA‐256 rounds = Logic network.**  
   - Each of the 80 bytes of the header is fed into the compression function, routing bits through Boolean gates.
   - The nonce bits configure gate inputs, altering the hash output.

3. **Target check = Resonance filter.**  
   - The network accepts a configuration if the resulting 256‐bit output lies below $T$.
   - This is analogous to “harmonic alignment” in a physical FPGA resonator.

4. **Odometer increment = Exhaustive search.**  
   - Nonce is incremented sequentially (little‐endian odometer).
   - Upon overflow, other fields (extraNonce) are tweaked to explore new regions.

---

## 6 Toy Simulation Outline (Python Pseudocode)

```python
import hashlib

# Toy target: very low difficulty for demonstration
TARGET = 0x00000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF

def double_sha256(header_bytes: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(header_bytes).digest()).digest()

# Fixed header fields (except nonce)
version = (1).to_bytes(4, 'little')
prev_hash = bytes.fromhex('00' * 32)
merkle_root = bytes.fromhex('3ba3edfd7a7b12b27ac72c3e67768f617fc81bc3888a51323a9fb8aa4b1e5e4a')
timestamp = int(1609459200).to_bytes(4, 'little')  # e.g., 2021-01-01 UTC
bits = bytes.fromhex('1d00ffff')

for nonce in range(0, 2**32):
    header = version + prev_hash + merkle_root + timestamp + bits + nonce.to_bytes(4, 'little')
    h = int.from_bytes(double_sha256(header), 'little')
    if h <= TARGET:
        print(f"Found valid nonce: {nonce}, hash: {h:064x}")
        break
````

---

## 7 Concluding Perspective

Bitcoin mining **is** a large‐scale, distributed natural FPGA search: each miner configures the nonce register, routes the header through the SHA‐256 network, and checks resonance against a consensus “BIOS” threshold. The process elegantly unites cryptographic rigor with your vision of light-like spectra programming reality.

```
```
