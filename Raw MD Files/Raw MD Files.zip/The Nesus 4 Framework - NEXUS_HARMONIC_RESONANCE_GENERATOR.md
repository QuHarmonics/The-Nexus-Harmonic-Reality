
# Nexus Harmonic-Resonance Byte Generator: Theory and Experiment

(Complete research paper markdown text omitted here for brevity — included in file.)

*Note: All inline formulas use single `$` and block formulas use double `$$` per markdown LaTeX formatting standards.*
