
# 🌀 Recursive Harmonic Tone Analysis

## 🎼 Emergent Harmonic Scale

This document captures the harmonic analysis of tones generated from a golden-step recursive resonance formula:

### 📐 Harmonic Formula

The recursive tone curve is governed by the exponential harmonic function:

$$
R(t) = e^{H \cdot F \cdot t}
$$

Where:
- $H$ = Harmonic constant (≈ 0.35)
- $F$ = Folding factor
- $t$ = Time, stepped in golden increments: $t = n \cdot \phi$, where $\phi ≈ 0.618$

Each $R$ is then scaled by a base frequency:

$$
f = R(t) \cdot f_0
$$

With:
- $f_0 = 220$ Hz (A3), the fundamental base tone

---

## 🎹 Generated Tones and Notes

| Step | $t$ (golden-stepped) | $R(t)$ | Frequency (Hz) | Note |
|------|----------------------|--------|----------------|------|
| 0    | 0.000                | 1.000  | 220.0          | A3   |
| 1    | 0.618                | 1.241  | 273.0          | C4   |
| 2    | 1.236                | 1.541  | 339.0          | E4   |
| 3    | 1.854                | 1.914  | 421.1          | G4   |
| 4    | 2.472                | 2.376  | 522.8          | B4   |
| 5    | 3.090                | 2.949  | 648.8          | D#5  |
| 6    | 3.708                | 3.661  | 805.4          | G5   |
| 7    | 4.326                | 4.546  | 1000.1         | A#5  |
| 8    | 4.944                | 5.643  | 1241.4         | D6   |
| 9    | 5.562                | 7.006  | 1541.3         | F#6  |

---

## 🧠 Emergent Scale Identity

### 💎 Named Mode: **Recursive Synthetic Mode I (RSM-I)**

- Foundation: A3 → C4 → E4 → G4 → B4  
- Expansion: D#5 → G5 → A#5 → D6 → F#6

This scale is not diatonic. It emerges from **recursive harmonic growth**, showing characteristics of:

- Minor 9th chord stacking
- Tritone leaps
- Recursive feedback intervals
- A balance of tension and release

It is **not found in classical modal theory** — this is a **natural mode of recursive systems**.

---

## 🔄 Harmonic Spiral Plot Summary

Each tone grows exponentially and maps to musical notes because Western pitch intervals are logarithmic.

- Recursive exponential growth:  
  $$ R(t) = e^{H \cdot F \cdot t} $$
- Western tuning:  
  $$ f_n = f_0 \cdot 2^{\frac{n}{12}} $$

This harmonic resonance naturally **intersects musical scale intervals** — not by design, but by emergence.

---

## 🎶 Implications

- This recursive system **generates tonal scales organically**
- It creates **non-human scales** that feel musical
- The tones are **symbolic reflections** — phase-matched states interpreted as sound

---

## 🧠 Philosophical Note

> *This isn't music made by a musician.*  
> *It's music made by recursion.*  
> *And interpreted by intelligence.*  

---

## 📝 Formula Summary

- Harmonic reflection:  
  $$ R(t) = e^{H \cdot F \cdot t} $$

- Frequency mapping:  
  $$ f = R \cdot f_0 $$

- Golden time stepping:  
  $$ t_n = n \cdot \phi,\ \text{where } \phi = \frac{1 + \sqrt{5}}{2} $$

- Western pitch intervals (for comparison):  
  $$ f_n = f_0 \cdot 2^{\frac{n}{12}} $$

---

## 📎 Metadata

- System: Nexus 2 Recursive Harmonic Engine
- Source: emit_harmonic_tone()
- Base Frequency: 220 Hz (A3)
- Generator: Recursive exponential harmonic tone curve
