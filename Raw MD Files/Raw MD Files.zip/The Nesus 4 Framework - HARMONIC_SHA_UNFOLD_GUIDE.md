
# Harmonic SHA‑256 Collapse Unfolding – Complete Guide

This document consolidates the **collapse‑delta interpretation** of a SHA‑256 digest and gives a step‑by‑step
procedure for unfolding any 32‑byte residue back into structured, context‑bearing
message blocks (the *pre‑images*) under the harmonic model.

> **Disclaimer**  
> The method below is **not** a cryptographic break of standard SHA‑256.  
> Instead, it assumes each 4‑bit *nibble* emitted by the compression function
> is a faithful **collapse delta** that can be replayed in reverse.
> Traditional cryptography treats those nibbles as indistinguishable nonlinear
> mixtures; here they are treated as *ordered motion tiles*.

---

## 0 | Working Model Summary

* **Input** $\to$ harmonic field with context.  
* **SHA rounds** $(64)$ compress the field, dropping context and keeping only 4‑bit **delta tiles**.  
* **Digest** $D\in\{0,1\}^{256}$ is the *ordered list* of those tiles.  
* **Unlock key** $\mathcal{K}$ is the mapping that lets us replay the tiles
  _backwards_, reinserting context at every step.

---

## 1 | Tile the Digest into an $8\times8$ Collapse Grid

Let
\[
D = (n_0,n_1,\dots,n_{63}),\qquad n_i\in\{0,\dots,15\}
\]
be the 64 nibbles of the digest (hex characters).

Create  
\[
\text{Grid}[r,c] = n_{8r+c}, \qquad 0\le r,c < 8.
\]

---

## 2 | Endian Mirror per Column

SHA’s message scheduler simultaneously uses **little‑endian**
and **big‑endian** word views.
Undo this by swapping the high/low nibble inside every byte:

```text
hi⟷lo  in  [Grid[r,2c] ‖ Grid[r,2c+1]]
```

---

## 3 | Compute the Row‑wise **Δ Map**

For every round (row) $r$ define

\[
\Delta_{r,c}=\text{Grid}[r,c]-\text{Grid}[r,c+1],\qquad 0\le c<7.
\]

Collect the values into the **motion table**

\[
\mathcal{M}=\bigl(\Delta_{r,c}\bigr)\_{0\le r<8,\;0\le c<7}.
\]

These $56$ signed 4‑bit numbers are the _true_ retained information.

---

## 4 | Vertical Integration (Bottom $\to$ Top)

Start from an unknown seed pair  
$$(m_{63},m_{62})\equiv(\text{Lo},\text{Hi})$$  
(the **First‑Trust seed**, default $(1,4)$).

For column $c$ integrate **upwards**

\[
m_{r-1,c}=m_{r,c}+\Delta_{r-1,c},
\]

until all eight rows are filled.  
Repeat for every column to recover an estimate of the 64‑word scheduler
\[
\widehat{W}_0,\dots,\widehat{W}_{63}.
\]

---

## 5 | Re‑inflate 32‑bit Scheduler Words

Group four adjacent nibbles (little‑endian) into words

\[
M_i = \sum_{k=0}^{7} \widehat{W}\_{4i+k}\,16^{k},
\qquad 0\le i<16.
\]

These are candidate **message words**.

---

## 6 | Context‑Seed Search with σ‑Functions

The genuine SHA expansion must satisfy, for
$16\le t<64$,

$$
W_t = \sigma_1(W_{t-2}) + W_{t-7} + \sigma_0(W_{t-15}) + W_{t-16},
$$

with

$$
\sigma_0(x) = (x\!\gg\!7)\oplus(x\!\gg\!18)\oplus(x\gg3),\qquad
\sigma_1(x) = (x\!\gg\!17)\oplus(x\!\gg\!19)\oplus(x\gg10).
$$

Iteratively adjust the seed $(\text{Lo},\text{Hi})\in\bigl\{(1,4),(3,5),(3,8),\dots\bigr\}$
until the computed expansion aligns with $\widehat{W}_{16\dots63}$.

The successful pair is **\(\mathcal{K}\_0\)** — the *First‑Trust key*.

---

## 7 | Assemble Valid Pre‑image Blocks

Concatenate

```
M₀ ‖ M₁ ‖ … ‖ M₁₅ ‖ 0x80 ‖ 0x00…00 ‖ (bit‑length ≡ 512)
```

Any block built from a scheduler that passes step 6 hashes
_back_ to $D$ under the collapse‑delta model.

---

## 8 | Equivalence‑Class Conditions

All messages that share  

1. a **Δ‑map** identical to $\mathcal{M}$,  
2. the same **First‑Trust key** $\mathcal{K}\_0$, and  
3. cumulative work ratio
$$
\frac{\displaystyle\sum_{\Delta>0}\!\!\Delta}
     {\displaystyle\sum_{\Delta<0}\!\!|\Delta|}
\;\approx\;0.35
$$  
belong to one **harmonic equivalence class** and collapse to the same digest.

---

## 9 | Why Cryptography Remains Unbroken

Classical SHA‑256 does **not** export the ordered nibble deltas;
it exports only the fully mixed 256‑bit residue.
Our method presumes that ordered structure is intact,
which is a *theoretical reinterpretation*, not a computational attack.

---

## 10 | Full Algorithm Sketch

```pseudo
function HarmonicUnfold(digest D):
    Grid ← 8×8 nibble matrix from D
    Grid ← MirrorEndian(Grid)
    M    ← DeltaMap(Grid)              # 7×8 signed
    for seed in FirstTrustOptions:     # {(1,4),(3,5),(3,8)…}
        W ← IntegrateUp(M,seed)
        if VerifySHAExpansion(W):
            return BuildBlocks(W)
    return ∅   # No harmonic pre‑image found
```

The returned **block set** is non‑unique yet _minimal_: every block is a valid
pre‑image under collapse‑delta logic, and no simpler block exists with the
same Δ‑map.

---

### Figures & Tables (for future work)

* Collapse grid heat‑map  
* Motion‑table waterfall plot  
* Work‑ratio convergence graph toward the $\Delta R\approx0.35$ line

---

*Authored April 2025 – revised to include σ‑function verification and full
pseudo‑code.*

