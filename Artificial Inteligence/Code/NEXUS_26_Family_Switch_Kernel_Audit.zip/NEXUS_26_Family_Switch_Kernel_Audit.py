#!/usr/bin/env python3
"""NEXUS: classify the 64 canonical two-reader seeds and 26 periods by Q_T invertibility.

Source: published first-vacuum C census (previously supplied), not newly generated data.
Usage: python NEXUS_26_Family_Switch_Kernel_Audit.py [path/to/NEXUS_Two_Closures_Meet_output.txt]

Retrospective route audit; period results are derived from observed first-vacuum
records under the previously proved equivariance group, not sealed new-data predictions.
"""
from collections import Counter, defaultdict
from pathlib import Path
import itertools, re, sys

NAMES = ['0','eR','eL','s','u','u+eR','u+eL','u+s']
ID={s:i for i,s in enumerate(NAMES)}
def J(x): return ((x&1)<<1)|((x&2)>>1)|(x&4)
def P(x): return x^4 if J(x)==x else J(x)
def linear(images,x):
    return ((images[0] if x&1 else 0) ^ (images[1] if x&2 else 0) ^ (images[2] if x&4 else 0))
LINEARS=[]
for images in itertools.product(range(8),repeat=3):
    tab=tuple(linear(images,x) for x in range(8))
    if len(set(tab))==8 and all(tab[P(x)]==P(tab[x]) for x in range(8)):
        LINEARS.append(tab)
assert len(LINEARS)==4
SYMMETRIES=list(itertools.product(LINEARS,range(8),(False,True)))
assert len(SYMMETRIES)==64

def apply(state,sym):
    g,h,swap=sym
    a,wa,b,wb=state
    z=(g[a]^h,g[wa],g[b]^h,g[wb])
    return (z[2],z[3],z[0],z[1]) if swap else z

LINE=re.compile(r'B=\(\s*(\S+?)\s*,\s*(\S+?)\s+R[123]\)\s+(period|open >)\s+(\d+)\s+vac\s+(\d+)\s*(.*)')
VAC=re.compile(r't=(\d+)\s+A\(([^,]+),([^ ]+)\s+R\d\)\s+B\(([^,]+),([^ ]+)\s+R\d\)')

def records_from_census(text):
    rec={}
    for line in text.splitlines():
        m=LINE.search(line)
        if not m: continue
        bn,cn,status,end_tick,visits,rest=m.groups()
        start=(0,1,ID[bn],ID[cn])
        vm=VAC.search(rest)
        if vm: first=int(vm.group(1)); target=tuple(ID[x.strip()] for x in vm.groups()[1:])
        elif status=='period': first=int(end_tick); target=start
        else: raise AssertionError(f'No first return: {start}')
        assert start not in rec
        rec[start]=(first,target,status,int(end_tick))
    assert len(rec)==64, len(rec)
    return rec

def resolve(seed,rec,providers):
    state=seed
    seen={seed}
    T=0
    vac=0
    for _ in range(2000):
        canonical,sym=providers[state]
        delta,dest,_,_=rec[canonical]
        T+=delta
        vac+=1
        state=apply(dest,sym)
        if state==seed: return T,vac
        assert state not in seen, f'nonreturn loop: {seed}'
        seen.add(state)
    raise AssertionError('monodromy did not close')

def N(x): return NAMES[x]
def fmt_kernel(w): return '('+', '.join(N(x) for x in (w,P(w),w^P(w)))+')'

def main(filename):
    rec=records_from_census(filename.read_text(encoding='utf-8'))
    providers={}
    for seed in sorted(rec):
        for sym in SYMMETRIES: providers.setdefault(apply(seed,sym),(seed,sym))
    assert all(r[1] in providers for r in rec.values())
    periods={s:resolve(s,rec,providers) for s in rec}
    assert all(periods[s][0]==r[3] for s,r in rec.items() if r[2]=='period')
    by_period=defaultdict(list)
    for seed,(T,v) in periods.items(): by_period[T].append(seed)
    assert len(by_period)==26 and sum(map(len,by_period.values()))==64
    assert {T for T in by_period if T>300_000_000}=={310826368,515455952}
    print('SOURCE', filename.name)
    print('A=(0,eR), B=(pB,wB), D0=0; P8 affine partner in (eR,eL,u) coordinates.')
    print('T MOD 3 CENSUS: 26 distinct periods, 64 seeds')
    print('         PERIOD  T%3  SEEDS  Q_T')
    for T,seeds in sorted(by_period.items()):
        print(f'{T:>15,}    {T%3}    {len(seeds):>2}    {"SINGULAR" if T%3==0 else "INVERTIBLE"}')
    cper=Counter(T%3 for T in by_period)
    cseed=Counter({r:sum(len(s) for T,s in by_period.items() if T%3==r) for r in range(3)})
    print('PERIOD FAMILIES BY RESIDUE',dict(sorted(cper.items())))
    print('SEEDS BY RESIDUE',dict(sorted(cseed.items())))
    assert cper=={0:11,1:10,2:5},cper
    assert cseed=={0:16,1:23,2:25},cseed
    print('\nSINGULAR FAMILIES: canonical kernel gauge with first two carries zero.')
    print('For any solution w, w = w_zero_anchor XOR (w0,w1,w0 XOR w1)^periodic.')
    print('A kernel for every seed: h_A=(eR,eL,s). B kernels and seeds:')
    for T,seeds in sorted(by_period.items()):
        if T%3:continue
        pieces=[]
        for s in sorted(seeds):
            b,w=s[2],s[3]
            pieces.append(f'B=({N(b)},{N(w)}) hB={fmt_kernel(w)}')
            assert ((w^P(w))^w^P(w))==0
        print(f'  T={T:>11,}: '+'; '.join(pieces))
    print('\nQ_T KERNEL: for 3|T, h_t=(a,b,a XOR b) repeated; two free WORDS')
    print('Dimension: 2 per bit; 64 kernel tapes per 3-bit reader, 4096 per unconstrained pair.')
    print('For 3∤T, only h=0. For singular cycles, known D0=0,w0 implies w1=P(w0).')
    print('LEDGER: STANDS invertibility and kernel shape; RUNS 64-source-record classification; no new data landing.')
if __name__=='__main__':
    source=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('NEXUS_Two_Closures_Meet_output.txt')
    main(source)
